// scripts/restore.js
// --------------------------------------------------------------------------
// SEGURIDAD (Fase B-14): restauración desde un respaldo creado por backup.js.
// Uso:  node scripts/restore.js backups/respaldo-<fecha>  [--si]
//   --si  confirma la sobrescritura (sin preguntar)
// Detiene la aplicación antes de restaurar. Copia ventas.db (+WAL) y uploads.
// --------------------------------------------------------------------------
'use strict';
const fs = require('fs');
const path = require('path');
const readline = require('readline');

const ROOT = path.join(__dirname, '..');
const DATA_DIR = process.env.DATA_DIR || path.join(DATA_DIR_OF('data'));
function DATA_DIR_OF(x) { return path.join(ROOT, x); }
const DB_PATH = process.env.DB_PATH || path.join(DATA_DIR, 'ventas.db');
const UPLOAD_DIR = process.env.UPLOAD_DIR || path.join(ROOT, 'uploads');

async function principal() {
  const args = process.argv.slice(2);
  const origen = args[0];
  const confirmado = args.includes('--si');

  if (!origen || !fs.existsSync(origen)) {
    console.error('ERROR: indica una carpeta de respaldo válida.');
    console.error('Ejemplo: node scripts/restore.js backups/respaldo-2026-01-15-10-30-00 --si');
    process.exit(1);
  }
  const dbRespaldo = path.join(origen, 'ventas.db');
  if (!fs.existsSync(dbRespaldo)) {
    console.error('ERROR: la carpeta indicada no contiene ventas.db');
    process.exit(1);
  }

  if (!confirmado) {
    const rl = readline.createInterface({ input: process.stdin, output: process.stdout });
    const resp = await new Promise((res) => rl.question('Esto SOBREESCRIBIRÁ la base actual y los comprobantes. ¿Continuar? (escribe "si"): ', res));
    rl.close();
    if (resp.trim().toLowerCase() !== 'si') {
      console.log('Cancelado. No se modificó nada.');
      process.exit(0);
    }
  }

  fs.mkdirSync(path.dirname(DB_PATH), { recursive: true });
  fs.copyFileSync(dbRespaldo, DB_PATH);
  if (fs.existsSync(dbRespaldo + '-wal')) fs.copyFileSync(dbRespaldo + '-wal', DB_PATH + '-wal');
  else if (fs.existsSync(DB_PATH + '-wal')) fs.rmSync(DB_PATH + '-wal');

  const uploadsRespaldo = path.join(origen, 'uploads');
  if (fs.existsSync(uploadsRespaldo)) {
    fs.rmSync(UPLOAD_DIR, { recursive: true, force: true });
    fs.cpSync(uploadsRespaldo, UPLOAD_DIR, { recursive: true });
  }

  console.log('Restauración completada desde: ' + origen);
  console.log('Vuelve a iniciar la aplicación con: npm start');
}

principal().catch((e) => { console.error('ERROR: ' + e.message); process.exit(1); });

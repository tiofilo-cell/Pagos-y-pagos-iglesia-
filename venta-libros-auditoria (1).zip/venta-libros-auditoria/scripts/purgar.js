// scripts/purgar.js
// --------------------------------------------------------------------------
// Fase B-15: los registros se eliminan de forma LÓGICA (recuperables).
// Este script purga físicamente los eliminados hace más de DIAS_PURGA días
// (30 por defecto) y borra también sus comprobantes.
// Uso: node scripts/purgar.js [--si]   (detén la app antes de purgar)
// --------------------------------------------------------------------------
'use strict';
const fs = require('fs');
const path = require('path');

const ROOT = path.join(__dirname, '..');
const DATA_DIR = process.env.DATA_DIR || path.join(ROOT, 'data');
const DB_PATH = process.env.DB_PATH || path.join(DATA_DIR, 'ventas.db');
const UPLOAD_DIR = process.env.UPLOAD_DIR || path.join(ROOT, 'uploads');
const DIAS = parseInt(process.env.DIAS_PURGA || '30', 10);

function principal() {
  const confirmado = process.argv.includes('--si');
  if (!fs.existsSync(DB_PATH)) { console.error('ERROR: no existe la base de datos.'); process.exit(1); }
  if (!confirmado) {
    console.log('Esto eliminará FÍSICAMENTE los registros con borrado lógico de más de ' + DIAS + ' días.');
    console.log('Ejecuta de nuevo con --si para confirmar.');
    process.exit(0);
  }

  const Database = require('better-sqlite3');
  const db = new Database(DB_PATH);
  db.pragma('busy_timeout = 5000');

  const limite = new Date(Date.now() - DIAS * 24 * 3600 * 1000).toISOString().slice(0, 19).replace('T', ' ');
  const filas = db.prepare("SELECT id, comprobante FROM registros WHERE eliminado = 1 AND eliminado_en IS NOT NULL AND eliminado_en <= ?").all(limite);

  let archivosBorrados = 0;
  const borrar = db.transaction(() => {
    for (const f of filas) {
      if (f.comprobante) {
        const ruta = path.join(UPLOAD_DIR, f.comprobante);
        if (ruta.startsWith(UPLOAD_DIR + path.sep) && fs.existsSync(ruta)) {
          fs.unlinkSync(ruta);
          archivosBorrados++;
        }
      }
      db.prepare('DELETE FROM registros WHERE id = ?').run(f.id);
    }
  });
  borrar();
  db.close();

  console.log(`Purga completada: ${filas.length} registro(s) eliminado(s) físicamente, ${archivosBorrados} comprobante(s) borrado(s).`);
}

principal();

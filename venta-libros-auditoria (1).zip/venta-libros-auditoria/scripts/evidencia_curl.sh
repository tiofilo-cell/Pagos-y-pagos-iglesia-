#!/usr/bin/env bash
# scripts/evidencia_curl.sh
# --------------------------------------------------------------------------
# Reproduce las pruebas MANUALES de seguridad con curl contra un servidor
# en marcha y guarda la salida real en evidencia/.
# Uso:  bash scripts/evidencia_curl.sh http://127.0.0.1:3100
# (levantar antes:  PORT=3100 ... npm start  — ver LEEME.md)
# --------------------------------------------------------------------------
set -u
BASE="${1:-http://127.0.0.1:3100}"
DIR="$(cd "$(dirname "$0")/.." && pwd)"
EV="$DIR/evidencia"
JAR="$(mktemp -d)"
CSRF=""

paso() { echo; echo "## $*"; }

mkdir -p "$EV"

# ---------- 02: acceso y cookies ----------
paso "GET /api/registros SIN sesión (debe ser 401)"
curl -s -i "$BASE/api/registros" | head -n 1
curl -s "$BASE/api/registros" | head -c 200; echo
{ echo "\$ curl -i http://127.0.0.1:3100/api/registros   (sin cookie)"; curl -s -i "$BASE/api/registros"; } > "$EV/02_acceso_sin_sesion.txt" 2>&1

paso "Login con contraseña INCORRECTA (401)"
curl -s -i -X POST "$BASE/api/login" -H 'Content-Type: application/json' \
  -d '{"usuario":"tesorero","password":"clave-mala-123"}' | head -n 1

paso "Login CORRECTO (200) — ver cookies Set-Cookie"
{ echo "\$ curl -i -X POST $BASE/api/login -H 'Content-Type: application/json' -d '{...}'"; \
  curl -s -i -X POST "$BASE/api/login" -H 'Content-Type: application/json' \
  -c "$JAR/cookies.txt" -d '{"usuario":"tesorero","password":"DemoTesorero2026!"}'; } > "$EV/02_login_y_cookies.txt" 2>&1
curl -s -c "$JAR/cookies.txt" -X POST "$BASE/api/login" -H 'Content-Type: application/json' \
  -d '{"usuario":"tesorero","password":"DemoTesorero2026!"}' > "$JAR/login.json"
CSRF="$(node -e "process.stdout.write(JSON.parse(require('fs').readFileSync('$JAR/login.json','utf8')).csrf||'')" 2>/dev/null || python3 -c "import json;print(json.load(open('$JAR/login.json'))['csrf'])")"
echo "CSRF obtenido: ${CSRF:0:12}… (ver evidencia/02_login_y_cookies.txt)"
echo "--- Set-Cookie (resumen) ---"
grep -i 'set-cookie' "$EV/02_login_y_cookies.txt" | head -n 2

paso "GET /api/session con cookie (200)"
curl -s "$BASE/api/session" -b "$JAR/cookies.txt"; echo

# ---------- 03: CSRF ----------
paso "POST /api/registros SIN cabecera x-csrf-token (debe ser 403)"
{ echo "\$ curl -i -X POST $BASE/api/registros -b cookies (SIN x-csrf-token)"; \
  curl -s -i -X POST "$BASE/api/registros" -b "$JAR/cookies.txt" \
    -H 'Content-Type: application/json' \
    -d '{"fecha":"2026-11-01","nombre":"Sin CSRF","entregados":1,"sobro":0,"total":10,"metodo_pago":"efectivo"}'; } > "$EV/03_csrf_rechazado.txt" 2>&1
head -n 1 "$EV/03_csrf_rechazado.txt"

paso "POST /api/registros CON CSRF (201) — pago mixto, efectivo se calcula solo"
curl -s -X POST "$BASE/api/registros" -b "$JAR/cookies.txt" -H "x-csrf-token: $CSRF" \
  -H 'Content-Type: application/json' \
  -d '{"fecha":"2026-11-01","nombre":"Rosa Quispe","entregados":12,"sobro":3,"total":45.5,"metodo_pago":"mixto","yape_monto":25}'; echo

paso "Datos ilegales: sobro>entregados, total negativo, nombre con solo espacios (400)"
curl -s -X POST "$BASE/api/registros" -b "$JAR/cookies.txt" -H "x-csrf-token: $CSRF" \
  -H 'Content-Type: application/json' \
  -d '{"fecha":"2026-02-31","nombre":"   ","entregados":-5,"sobro":9,"total":-3,"metodo_pago":"mixto","yape_monto":999}'; echo

# ---------- 04: SQLi ----------
paso "SQLi en búsqueda (q) — nada se ejecuta, devuelve listas vacías"
{ for Q in "' OR '1'='1" "'; DROP TABLE registros;--" "' UNION SELECT 1,2,3,4,5,6,7,8,9,10,11,12,13,14--"; do
    echo "\$ q=$(printf '%s' "$Q")"
    curl -s -G "$BASE/api/registros" --data-urlencode "q=$Q" -b "$JAR/cookies.txt" | head -c 220; echo; echo
  done
  echo "\$ mes=2026-01'--"
  curl -s -G "$BASE/api/registros" --data-urlencode "mes=2026-01'--" -b "$JAR/cookies.txt"; echo
} > "$EV/04_sqli.txt" 2>&1
cat "$EV/04_sqli.txt"

paso "SQLi en login (parametrizado) — 401"
curl -s -X POST "$BASE/api/login" -H 'Content-Type: application/json' \
  -d "{\"usuario\":\"' OR '1'='1' --\",\"password\":\"x\"}"; echo

# ---------- 05: XSS + cabeceras ----------
paso "XSS almacenado: nombre con <script> se guarda como TEXTO"
curl -s -X POST "$BASE/api/registros" -b "$JAR/cookies.txt" -H "x-csrf-token: $CSRF" \
  -H 'Content-Type: application/json' \
  -d '{"fecha":"2026-11-02","nombre":"<script>alert(1)</script><img src=x onerror=alert(1)>","entregados":1,"sobro":0,"total":9,"metodo_pago":"efectivo"}' | head -c 300; echo
{ echo "\$ Búsqueda del payload XSS — se devuelve como TEXTO (JSON), nunca se ejecuta:"; \
  curl -s -G "$BASE/api/registros" --data-urlencode "q=<script>" -b "$JAR/cookies.txt" | head -c 400; echo; \
  echo; echo "\$ Cabeceras de seguridad de GET /:"; \
  curl -s -I "$BASE/" | grep -Ei 'content-security|x-content-type|x-frame|referrer-policy|x-powered|strict-transport|cross-origin'; } > "$EV/05_xss_y_cabeceras.txt" 2>&1

# ---------- 06: uploads ----------
paso "Upload de un .exe renombrado a .jpg (magic bytes) → 400"
printf 'MZ\x90\x00AAAAABB' > "$JAR/falso.jpg"
curl -s -X POST "$BASE/api/registros" -b "$JAR/cookies.txt" -H "x-csrf-token: $CSRF" \
  -F "fecha=2026-11-03" -F "nombre=Trampa Exe" -F "entregados=1" -F "sobro=0" \
  -F "total=9" -F "metodo_pago=yape" -F "comprobante=@$JAR/falso.jpg;type=image/jpeg" ; echo

paso "Upload de PNG real → 201 con nombre generado por el servidor"
printf 'iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAYAAAAfFcSJAAAADUlEQVR42mP8z8BQDwAEhQGAhKmMIQAAAABJRU5ErkJggg==' | base64 -d > "$JAR/real.png"
RESP_UP="$(curl -s -X POST "$BASE/api/registros" -b "$JAR/cookies.txt" -H "x-csrf-token: $CSRF" \
  -F "fecha=2026-11-03" -F "nombre=Comprobante Real" -F "entregados=4" -F "sobro=1" \
  -F "total=18.9" -F "metodo_pago=yape" -F "comprobante=@$JAR/real.png;type=image/png")"
echo "$RESP_UP" | head -c 400; echo
ARCHIVO="$(node -e "try{process.stdout.write(JSON.parse(process.argv[1]).registro.comprobante||'')}catch(e){}" "$RESP_UP")"
ID_REG="$(node -e "try{process.stdout.write(String(JSON.parse(process.argv[1]).registro.id))}catch(e){}" "$RESP_UP")"

paso "El archivo NO es accesible como estático (uploads/ privado) → 404"
curl -s -o /dev/null -w "GET /uploads/$ARCHIVO  ->  %{http_code}\n" "$BASE/uploads/$ARCHIVO"

paso "Ver el comprobante REQUIERE sesión: sin cookie 401, con cookie 200"
curl -s -o /dev/null -w "sin cookie  -> %{http_code}\n" "$BASE/api/comprobantes/$ID_REG"
curl -s -o /dev/null -w "con cookie  -> %{http_code}  content-type: %{content_type}\n" "$BASE/api/comprobantes/$ID_REG" -b "$JAR/cookies.txt"
{ echo "## Resumen de la prueba de comprobantes privados"; \
  echo "GET /uploads/$ARCHIVO sin sesión -> $(curl -s -o /dev/null -w '%{http_code}' "$BASE/uploads/$ARCHIVO")"; \
  echo "GET /api/comprobantes/$ID_REG sin cookie -> $(curl -s -o /dev/null -w '%{http_code}' "$BASE/api/comprobantes/$ID_REG")"; \
  echo "GET /api/comprobantes/$ID_REG con cookie -> $(curl -s -o /dev/null -w '%{http_code} %{content_type}' "$BASE/api/comprobantes/$ID_REG" -b "$JAR/cookies.txt")"; \
  echo; echo "## Upload de .exe disfrazado de .jpg (rechazado por magic bytes)"; \
  curl -s -X POST "$BASE/api/registros" -b "$JAR/cookies.txt" -H "x-csrf-token: $CSRF" \
    -F "fecha=2026-11-03" -F "nombre=Trampa Exe" -F "entregados=1" -F "sobro=0" \
    -F "total=9" -F "metodo_pago=yape" -F "comprobante=@$JAR/falso.jpg;type=image/jpeg"; echo; } > "$EV/06_comprobantes_y_uploads.txt" 2>&1

# ---------- 07: exportar Excel + anti-fórmulas ----------
paso "Insertar nombre malicioso =HIPERVINCULO(...) y exportar el mes"
curl -s -X POST "$BASE/api/registros" -b "$JAR/cookies.txt" -H "x-csrf-token: $CSRF" \
  -H 'Content-Type: application/json' \
  -d '{"fecha":"2026-11-04","nombre":"=HIPERVINCULO(\"http://evil.com\";\"clic\")","entregados":2,"sobro":0,"total":12,"metodo_pago":"efectivo"}' | head -c 200; echo
curl -s -G "$BASE/api/exportar" --data-urlencode "mes=2026-11" -b "$JAR/cookies.txt" -o "$JAR/ventas-2026-11.xlsx"
{ echo "## Cell dentro del .xlsx (xl/sharedStrings.xml): debe empezar con apóstrofe"; \
  unzip -p "$JAR/ventas-2026-11.xlsx" xl/sharedStrings.xml | grep -o "['-=+@][^<]*HIPERVINCULO[^<]*" | head -n 3; \
  echo; echo "## Archivo exportado:"; ls -la "$JAR/ventas-2026-11.xlsx"; } > "$EV/07_export_anti_formulas.txt" 2>&1
cat "$EV/07_export_anti_formulas.txt"

# ---------- 08: auditoría ----------
{ echo "## GET /api/auditoria (solo tesorero) — últimos eventos reales"; \
  curl -s "$BASE/api/auditoria" -b "$JAR/cookies.txt" | head -c 1500; echo; } > "$EV/08_auditoria.txt" 2>&1

echo
echo "Listo. Evidencia en: $EV"
rm -rf "$JAR"

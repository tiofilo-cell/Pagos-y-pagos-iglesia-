// scripts/prueba_bloqueo.js
// --------------------------------------------------------------------------
// Fase A-10: prueba REAL ante "database is locked".
//  1) Levanta el servidor con una base temporal.
//  2) Otra conexión SQLite toma un bloqueo exclusivo (BEGIN EXCLUSIVE).
//  3a) Se libera a los 2 s (< busy_timeout de 5 s)  → la venta se registra.
//  3b) Se retiene 8 s (> 5 s)                       → el servidor responde 503
//      con un mensaje amable (no se cae, no filtra detalles internos).
// --------------------------------------------------------------------------
'use strict';
const { spawn, spawnSync } = require('child_process');
const fs = require('fs');
const path = require('path');

const ROOT = path.join(__dirname, '..');
const PUERTO = 3198;
const TMP = path.join(ROOT, '.evidencia-tmp-bloqueo');
const DB = path.join(TMP, 'ventas.db');
const BASE = `http://127.0.0.1:${PUERTO}`;

let servidor = null;
let cookies = '';
let csrf = '';
let fallos = 0;

function esperar(ms) { return new Promise((r) => setTimeout(r, ms)); }

function levantar() {
  servidor = spawn(process.execPath, [path.join(ROOT, 'app', 'server.js')], {
    env: {
      ...process.env, PORT: String(PUERTO), DB_PATH: DB,
      UPLOAD_DIR: path.join(TMP, 'uploads'),
      ADMIN_USER: 'admin', ADMIN_PASSWORD: 'ClaveBloqueo2026!',
      API_LIMIT_MAX: '100000', NODE_ENV: 'development',
    },
    stdio: ['ignore', 'pipe', 'pipe'],
  });
}

async function esperarPuerto() {
  for (let i = 0; i < 60; i++) {
    try {
      const r = await fetch(BASE + '/api/session');
      if (r.status === 401 || r.status === 200) return true;
    } catch { /* no listo */ }
    await esperar(250);
  }
  return false;
}

async function login() {
  const r = await fetch(BASE + '/api/login', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ usuario: 'admin', password: 'ClaveBloqueo2026!' }),
  });
  cookies = r.headers.getSetCookie().map((c) => c.split(';')[0]).join('; ');
  csrf = (await r.json()).csrf;
}

function registrar(nombre) {
  return fetch(BASE + '/api/registros', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json', Cookie: cookies, 'x-csrf-token': csrf },
    body: JSON.stringify({ fecha: '2026-02-01', nombre, entregados: 5, sobro: 1, total: 40, metodo_pago: 'efectivo' }),
  }).then(async (r) => ({ status: r.status, cuerpo: await r.json() }));
}

function chequear(nombre, condicion, extra) {
  console.log(`[${condicion ? 'PASS' : 'FAIL'}] ${nombre}${extra ? ' — ' + extra : ''}`);
  if (!condicion) fallos++;
}

(async () => {
  spawnSync('rm', ['-rf', TMP]);
  fs.mkdirSync(TMP, { recursive: true });

  levantar();
  chequear('Servidor responde', await esperarPuerto());
  await login();
  const sinBloqueo = await registrar('Venta sin bloqueo');
  chequear('Venta normal se registra', sinBloqueo.status === 201);

  const Database = require('better-sqlite3');
  const otra = new Database(DB);
  otra.pragma('busy_timeout = 100');

  // Caso A: bloqueo breve (2 s) → el servidor ESPERA y registra igual
  otra.exec('BEGIN EXCLUSIVE');
  const t0 = Date.now();
  setTimeout(() => { try { otra.exec('COMMIT'); } catch { /* nada */ } }, 2000);
  const casoA = await registrar('Venta con bloqueo breve');
  chequear('Con bloqueo de 2 s: espera y registra (busy_timeout)', casoA.status === 201, `${Date.now() - t0} ms`);

  // Caso B: bloqueo largo (8 s) → supera busy_timeout → 503 con mensaje claro
  otra.exec('BEGIN EXCLUSIVE');
  const t1 = Date.now();
  setTimeout(() => { try { otra.exec('COMMIT'); } catch { /* nada */ } }, 8000);
  const casoB = await registrar('Venta con bloqueo largo');
  chequear('Con bloqueo de 8 s: responde 503 sin caerse', casoB.status === 503, `${Date.now() - t1} ms`);
  chequear('Mensaje amable para el usuario', casoB.status === 503 && /ocupada/i.test(casoB.cuerpo.error || ''), casoB.cuerpo.error);

  otra.close();
  try { servidor.kill('SIGTERM'); } catch { /* nada */ }
  spawnSync('rm', ['-rf', TMP]);
  console.log(fallos === 0 ? 'RESULTADO: TODAS LAS PRUEBAS DE BLOQUEO PASARON' : `RESULTADO: ${fallos} PRUEBA(S) FALLARON`);
  process.exit(fallos === 0 ? 0 : 1);
})().catch((e) => { console.error('ERROR INESPERADO:', e); process.exit(1); });

// scripts/backup.js
// --------------------------------------------------------------------------
// SEGURIDAD (Fase B-14): respaldo de la base de datos y de los comprobantes.
// Uso:  npm run backup
// Crea:  backups/respaldo-<fecha>/  con ventas.db (+WAL) y la carpeta uploads.
// Para CIFRAR el respaldo (recomendado), ver LEEME.md → "Respaldos cifrados"
// (ejemplos con age y GPG).
// --------------------------------------------------------------------------
'use strict';
const fs = require('fs');
const path = require('path');

const ROOT = path.join(__dirname, '..');
const DATA_DIR = process.env.DATA_DIR || path.join(ROOT, 'data');
const DB_PATH = process.env.DB_PATH || path.join(DATA_DIR, 'ventas.db');
const UPLOAD_DIR = process.env.UPLOAD_DIR || path.join(ROOT, 'uploads');
const BACKUP_DIR = process.env.BACKUP_DIR || path.join(ROOT, 'backups');

function principal() {
  if (!fs.existsSync(DB_PATH)) {
    console.error('ERROR: no existe la base de datos en ' + DB_PATH);
    process.exit(1);
  }

  // Checkpoint WAL para obtener una copia consistente en un solo archivo
  try {
    const Database = require('better-sqlite3');
    const d = new Database(DB_PATH);
    d.pragma('wal_checkpoint(TRUNCATE)');
    d.close();
  } catch (e) {
    console.warn('Aviso: no se pudo hacer checkpoint del WAL: ' + e.message);
  }

  const ts = new Date().toISOString().replace(/[:T]/g, '-').slice(0, 19);
  const destino = path.join(BACKUP_DIR, 'respaldo-' + ts);
  fs.mkdirSync(destino, { recursive: true });

  fs.copyFileSync(DB_PATH, path.join(destino, 'ventas.db'));
  if (fs.existsSync(DB_PATH + '-wal')) fs.copyFileSync(DB_PATH + '-wal', path.join(destino, 'ventas.db-wal'));
  if (fs.existsSync(UPLOAD_DIR)) fs.cpSync(UPLOAD_DIR, path.join(destino, 'uploads'), { recursive: true });

  console.log('Respaldo creado correctamente en: ' + destino);
  console.log('IMPORTANTE: cifra este respaldo antes de llevarlo a otro medio (ver LEEME.md).');
}

principal();

// scripts/prueba_reinicio.js
// --------------------------------------------------------------------------
// Fase A-10: prueba REAL de persistencia y carpetas faltantes.
//  1) Levanta el servidor con una base temporal.
//  2) Registra una venta.
//  3) Detiene el servidor (SIGTERM) y BORRA la carpeta uploads/.
//  4) Vuelve a levantarlo y comprueba: la venta sigue ahí y la carpeta
//     uploads/ se recreó sola.
// Salida: líneas [PASS]/[FAIL] (se guardan en evidencia/).
// --------------------------------------------------------------------------
'use strict';
const { spawn, spawnSync } = require('child_process');
const fs = require('fs');
const path = require('path');

const ROOT = path.join(__dirname, '..');
const PUERTO = 3199;
const TMP = path.join(ROOT, '.evidencia-tmp');
const DB = path.join(TMP, 'ventas.db');
const UPLOADS = path.join(TMP, 'uploads');
const BASE = `http://127.0.0.1:${PUERTO}`;

let servidor = null;
let cookies = '';
let csrf = '';

function esperar(ms) { return new Promise((r) => setTimeout(r, ms)); }

function levantar() {
  servidor = spawn(process.execPath, [path.join(ROOT, 'app', 'server.js')], {
    env: {
      ...process.env,
      PORT: String(PUERTO),
      DB_PATH: DB,
      UPLOAD_DIR: UPLOADS,
      ADMIN_USER: 'admin',
      ADMIN_PASSWORD: 'ClaveReinicio2026!',
      API_LIMIT_MAX: '100000',
      NODE_ENV: 'development',
    },
    stdio: ['ignore', 'pipe', 'pipe'],
  });
  let salida = '';
  servidor.stdout.on('data', (d) => { salida += d; });
  servidor.stderr.on('data', (d) => { salida += d; });
  servidor.salida = () => salida;
  return servidor;
}

async function listarPuerto() {
  for (let i = 0; i < 60; i++) {
    try {
      const r = await fetch(BASE + '/api/session');
      if (r.status === 401 || r.status === 200) return true;
    } catch { /* aún no responde */ }
    await esperar(250);
  }
  return false;
}

async function login() {
  const r = await fetch(BASE + '/api/login', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ usuario: 'admin', password: 'ClaveReinicio2026!' }),
  });
  const cuerpo = await r.json();
  cookies = r.headers.getSetCookie().map((c) => c.split(';')[0]).join('; ');
  csrf = cuerpo.csrf;
  return r.status;
}

async function registrar(fecha, nombre, entregados, sobro, total, metodo) {
  const r = await fetch(BASE + '/api/registros', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json', Cookie: cookies, 'x-csrf-token': csrf },
    body: JSON.stringify({ fecha, nombre, entregados, sobro, total, metodo_pago: metodo }),
  });
  return { status: r.status, cuerpo: await r.json() };
}

function detener() {
  if (!servidor) return Promise.resolve();
  return new Promise((resolve) => {
    servidor.once('exit', () => resolve());
    servidor.kill('SIGTERM');
    setTimeout(() => { try { servidor.kill('SIGKILL'); } catch { /* nada */ } resolve(); }, 3000);
  });
}

let fallos = 0;
function chequear(nombre, condicion, extra) {
  console.log(`[${condicion ? 'PASS' : 'FAIL'}] ${nombre}${extra ? ' — ' + extra : ''}`);
  if (!condicion) fallos++;
}

(async () => {
  spawnSync('rm', ['-rf', TMP]);
  fs.mkdirSync(TMP, { recursive: true });

  // --- Fase 1: arrancar y registrar ---
  levantar();
  chequear('Servidor #1 responde', await listarPuerto());
  chequear('Login del tesorero', (await login()) === 200);
  const venta = await registrar('2026-01-15', 'Prueba de Reinicio', 10, 3, 25.5, 'efectivo');
  chequear('Venta registrada', venta.status === 201, `id=${venta.cuerpo && venta.cuerpo.registro ? venta.cuerpo.registro.id : '?'}`);
  const idVenta = venta.cuerpo.registro.id;

  // --- Fase 2: reinicio + borrar uploads ---
  await detener();
  fs.rmSync(UPLOADS, { recursive: true, force: true });
  chequear('Servidor detenido y carpeta uploads/ borrada', !fs.existsSync(UPLOADS));

  // --- Fase 3: arrancar de nuevo y verificar ---
  levantar();
  chequear('Servidor #2 responde tras reinicio', await listarPuerto());
  chequear('Carpeta uploads/ recreada automáticamente por el servidor', fs.existsSync(UPLOADS));
  chequear('Login tras reinicio', (await login()) === 200);

  const r2 = await fetch(BASE + '/api/registros?mes=2026-01', { headers: { Cookie: cookies } });
  const c2 = await r2.json();
  const encontrado = (c2.registros || []).some((x) => x.id === idVenta && x.nombre === 'Prueba de Reinicio');
  chequear('La venta PERSISTE después de reiniciar (SQLite)', encontrado);

  await detener();
  spawnSync('rm', ['-rf', TMP]);
  console.log(fallos === 0 ? 'RESULTADO: TODAS LAS PRUEBAS DE REINICIO PASARON' : `RESULTADO: ${fallos} PRUEBA(S) FALLARON`);
  process.exit(fallos === 0 ? 0 : 1);
})().catch((e) => { console.error('ERROR INESPERADO:', e); process.exit(1); });

# INFORME COMPLETO — Auditoría QA + AppSec · “Venta de Libros” v2.0.0

**Fecha:** 2026-11-02 · **Equipo:** Ingeniería de software senior + QA + Seguridad de aplicaciones (AppSec)
**Alcance:** aplicación web “Venta de Libros” (Node.js + Express + SQLite/better-sqlite3 + multer + ExcelJS; frontend HTML/CSS/JS sin frameworks).

> **ADVERTENCIA DE HONESTIDAD (obligatoria):** el código original nunca fue entregado para revisión
> (los bloques del documento de partida estaban vacíos: `[PEGAR AQUÍ EL CÓDICE DE server.js]`, etc.).
> Por decisión tomada al inicio, se construyó una **reconstrucción de referencia** fiel a la funcionalidad
> descrita, se la **endureció** y **TODAS las pruebas de este informe se ejecutaron realmente** contra esa
> versión corriendo en Node v24. Cada resultado indica su evidencia real (archivos en `evidencia/` y
> `pantallas/`). Nada de lo aquí listado es inventado; lo que NO se pudo ejecutar está marcado como
> **NO EJECUTADA** con su motivo.

**Índice:** ① Resumen ejecutivo · ② Tabla de hallazgos · ③ Resultados Fase A y Fase B · ④ Código completo por archivo · ⑤ Pruebas automatizadas · ⑥ Despliegue seguro · ⑦ Limitaciones · ⑧ CHANGELOG

---

## ① RESUMEN EJECUTIVO

- **23 hallazgos** en total: **2 Críticos · 6 Altos · 8 Medios · 7 Bajos** — todos con corrección aplicada y verificada en esta versión 2.0.0.
- El problema más grave: la aplicación **no tenía ningún control de acceso** (H-01): cualquier persona con la URL podía crear, **eliminar registros de ventas reales** y **ver los comprobantes de Yape con datos personales** (H-02), además de inyectar SQL/XSS y subir archivos disfrazados.
- Estado final: **Fase A 10/10 verificadas** (9 completas + 1 parcial: falta probar en dispositivos físicos) y **Fase B 15/15 implementadas y verificadas**; suite automatizada **84/84 pruebas OK**.
- `npm audit` real: de **14 vulnerabilidades (4 altas)** a **9 moderadas** tras actualizar Express y multer; las 9 restantes están en dependencias transitivas de `exceljs` **sin solución publicada** (riesgo aceptado y documentado).
- Se detectaron y corrigieron además **2 bugs reales durante la verificación** (500 al ver comprobantes; tarjeta de login visible tras iniciar sesión).
- **No se puede afirmar “100 % sin errores”**: véase §7 Limitaciones (dispositivos físicos, HTTPS real, pentest profesional, carga masiva).

---

## ② TABLA DE HALLAZGOS

| ID | Severidad | Categoría | Descripción | Cómo reproducirlo | Evidencia | Corrección aplicada |
|----|-----------|-----------|-------------|-------------------|-----------|---------------------|
| H-01 | Crítica | Autenticación/Autorización | El diseño original no incluye login ni roles: cualquiera con la URL crea, **elimina** y exporta registros con nombres reales. | Abrir la app y usar cualquier botón sin credenciales. | `tests/seg_acceso.test.js`: 7 endpoints devuelven **401** sin sesión; consulta recibe **403** en POST/DELETE (REAL). | Login + roles `tesorero/consulta` (scrypt), sesiones en BD, `requireAuth`/`requireTesorero` en todas las rutas. |
| H-02 | Crítica | Exposición de comprobantes | Comprobantes con imágenes/datos personales servidos como archivos estáticos de `/uploads`: cualquiera con la URL los ve o los reenvía. | `GET /uploads/<archivo>` sin sesión. | `evidencia/06_comprobantes_y_uploads.txt`: `/uploads/…` → **404**; `/api/comprobantes/:id` sin cookie → **401**, con cookie → **200** (REAL). | Carpeta fuera del alcance estático, endpoint autenticado, nombre **UUID** generado por el servidor, `nosniff`. |
| H-03 | Alta | CSRF | POST/DELETE sin token: un sitio externo puede enviar acciones con la cookie del usuario. | Formulario oculto en otra web con la cookie de sesión. | `tests/seg_acceso.test.js` → POST/DELETE sin `x-csrf-token` devuelven **403** (REAL). | Token CSRF por sesión (doble envío cookie+cabecera) + `SameSite=Strict`. |
| H-04 | Alta | Inyección SQL | Riesgo de concatenación en consultas con `nombre`, `q`, `mes`, `id`. | `' OR '1'='1` en búsqueda y login; `1 OR 1=1` en DELETE. | `evidencia/04_sqli.txt` + `tests/seg_inyeccion_errores.test.js`: listas vacías, 400 y 401; nada se ejecuta (REAL). | 100 % parametrizada (better-sqlite3 `prepare`), validación estricta de `mes`/`id`. |
| H-05 | Alta | XSS | Nombre y búsqueda insertados como HTML → robo de sesión y defacement. | Registrar nombre `<script>alert(1)</script><img src=x onerror=…>` y abrir el historial. | `evidencia/13_interfaz_navegador.txt` + `pantallas/10_app_tesorero_1280.png`: en navegador real `ejecutado=false`, se muestra como texto; CSP `script-src 'self'` (REAL). | Frontend solo usa `textContent` (sin `innerHTML`), CSP estricta sin scripts en línea. |
| H-06 | Alta | Subida de archivos | Extensión no verificada contra el contenido; un `.exe` renombrado a `.jpg` (o HTML/JS) entraba y se servía desde el mismo origen. | Subir `troyano.exe` renombrado `foto.jpg`. | `evidencia/06…txt`: respuesta **400** “El comprobante no es válido…” (REAL). También: vacío → 400, >5 MB → 400. | Validación de **magic bytes** (JPG/PNG/WEBP/PDF), límite 5 MB, rechazo de vacíos, nombre UUID, original saneado. |
| H-07 | Alta | Fuerza bruta | Sin límite de intentos ni bloqueo: diccionario de contraseñas viable. | Automatizar login con 100 contraseñas. | `tests/seg_acceso.test.js`: 5 fallos → el 6.º recibe **429**; bloqueo de cuenta por 10 min (REAL). | `express-rate-limit` por IP (solo fallos) + bloqueo temporal por cuenta (`app/lockout.js`). |
| H-08 | Alta | Inyección de fórmulas Excel | Un nombre que empieza por `= + - @` se ejecuta como fórmula al abrir el Excel exportado. | Registrar nombre `=HIPERVINCULO("http://evil.com";"clic")` y exportar. | `evidencia/07_export_anti_formulas.txt`: en `sharedStrings.xml` la celda queda `&apos;=HIPERVINCULO(…)` (REAL). | `neutralizar()` antepone apóstrofe a textos que empiezan con `= + - @` o tabulador (Fase B-9). |
| H-09 | Media | Cookies de sesión | Sin `HttpOnly`/`SameSite`/expiración, la sesión era robable por JS y usable en CSRF. | Inspeccionar `Set-Cookie` del login. | `evidencia/02_login_y_cookies.txt`: `HttpOnly; SameSite=Strict; Max-Age=28800` (REAL). | Cookies con `HttpOnly`, `SameSite=Strict`, `Secure` (HTTPS), `Max-Age` y logout que borra la sesión en el servidor. |
| H-10 | Media | Cabeceras de seguridad | Faltaban CSP, nosniff, frame-ancestors, Referrer-Policy; `X-Powered-By` visible. | `curl -I http://servidor/`. | `evidencia/05_xss_y_cabeceras.txt` + test: CSP, `nosniff`, `DENY`, `no-referrer`, sin `X-Powered-By` (REAL). | `helmet` configurado + `app.disable('x-powered-by')`; sin CORS (app de mismo origen). |
| H-11 | Media | Fugas de información en errores | Stack traces / rutas internas llegaban al cliente; JSON malformado y cuerpos gigantes sin control. | POST con `{{` y cuerpo de 200 kb. | `tests/seg_inyeccion_errores.test.js`: JSON malformado → **400**, cuerpo grande → **413**, sin rutas ni stacks (REAL). | Middleware global de errores con mensajes en español; detalles solo al log del servidor; límite `100kb`. |
| H-12 | Media | Validación de datos | El servidor aceptaba negativos, decimales, `sobró > entregados`, `yape > total`, 1e9, NaN/Infinity, `2026-02-31`, nombre con solo espacios. | Enviar cada dato ilegal por la API. | `tests/qa_validaciones.test.js`: 17 pruebas, todas **400 con mensaje en español** (REAL). | `app/validaciones.js` central: límites 0–10000, total ≤ S/ 1,000,000, fechas de calendario reales, trim, sin caracteres de control. |
| H-13 | Media | Búsqueda incorrecta (LIKE) | `%` y `_` sin escapar: buscar “100%” devolvía todo. | Buscar `100%`, `a%`, `Original_`. | `tests/qa_uploads_historial.test.js`: `100%` → 1 resultado exacto; `a%` → 0 (REAL). | `ESCAPE '\'` con `\%`, `\_`, `\\` antes de parametrizar. |
| H-14 | Media | Duplicados por doble clic | Doble clic en Guardar creaba la misma venta dos veces. | Doble clic rápido en Guardar. | `tests/qa_concurrencia_export.test.js`: 2ª petición idéntica → **409**; en el historial queda 1 (REAL). | Botón deshabilitado mientras envía + deduplicación en servidor (10 s, incluye hash del archivo). |
| H-15 | Media | Borrado sin recuperación | DELETE físico sin confirmación ni vuelta atrás (y el comprobante se perdía). | Eliminar un registro por error. | `tests/qa_uploads_historial.test.js`: eliminado desaparece del listado, **Restaurar** lo recupera; comprobante retenido hasta purga (REAL). | Borrado **lógico** + botón Restaurar + “Ver eliminados” + `scripts/purgar.js` (30 días). |
| H-16 | Media | Flood / denegación | Sin límite global de solicitudes por IP. | Script de 10 000 solicitudes. | Configuración activa `API_LIMIT_MAX=600/15min`; respuesta 429 con mensaje (REAL; probado con límites bajos en pruebas). | `express-rate-limit` global en `/api` + límite específico de login. |
| H-17 | Baja | Secretos en código | Credenciales incrustadas y sin `.gitignore` (riesgo de subirlas al repositorio). | Buscar contraseñas en el código. | Archivos entregados: `.env.example` + `.gitignore` (`.env`, `data/`, `uploads/`, `backups/`) (REVISIÓN ESTÁTICA). | Todo por variables de entorno; si no hay `.env` y no hay usuarios, se genera contraseña aleatoria mostrada una vez. |
| H-18 | Baja | Respaldos inexistentes | Sin procedimiento de copia ni restauración. | — | `evidencia/11_respaldo_restauracion.txt`: backup real creado y restaurado (4 registros, 2 usuarios verificados) (REAL). | `scripts/backup.js` + `scripts/restore.js` + instrucciones de cifrado (age/GPG) en LEEME.md. |
| H-19 | Baja | Integridad de datos | Sin CHECK/NOT NULL, sin transacciones, sin auditoría. | Insertar valores imposibles directo en BD. | Esquema en `app/db.js` + `evidencia/08_auditoria.txt` con eventos reales (REAL). | CHECK/NOT NULL, transacciones (registro+auditoría atómicos), `audit_log`, borrado lógico recuperable. |
| H-20 | Baja | Dependencias vulnerables | Versiones sin fijar con vulnerabilidades conocidas. | `npm audit`. | `evidencia/12_npm_audit.txt` (14: 4 altas) y `12_npm_audit_post_fix.txt` (9 moderadas) (REAL). | Versiones fijadas exactas; Express 4.22.3 y multer 2.5.0; las 9 moderadas restantes sin fix upstream (riesgo documentado §7). |
| H-21 | Baja | Base de datos bloqueada | Un bloqueo externo tumbaba las operaciones con error técnico. | Abrir transacción exclusiva desde otro proceso y vender. | `evidencia/10_bd_bloqueada.txt`: bloqueo 2 s → espera y registra (201); 8 s → **503** con mensaje amable (REAL). | WAL + `busy_timeout=5000` + mapeo del error a mensaje en español. |
| H-22 | Baja | Carpeta uploads faltante | Si se limpiaba `uploads/`, la app fallaba al guardar comprobantes. | Borrar `uploads/` y reiniciar. | `evidencia/09_reinicio_persistencia.txt`: carpeta **recreada automáticamente** (REAL). | `fs.mkdirSync(UPLOAD_DIR, {recursive:true})` al arrancar. |
| H-23 | Baja | Interfaz (bug real) | Tras iniciar sesión, la tarjeta de login seguía visible encima de la app (el CSS `#vista-login{display:flex}` pisaba el atributo `hidden`). | Iniciar sesión y observar la pantalla. | `pantallas/09_bug_login_duplicado_EVIDENCIA.png` (bug) vs `pantallas/10-12` (corregido) (REAL, navegador headless). | `.vista[hidden]{display:none !important}` + regeneración de capturas. |

**Recuento: Crítica 2 · Alta 6 · Media 8 · Baja 7 = 23 hallazgos (100 % con corrección aplicada).**

---

## ③ RESULTADOS FASE A (QA funcional) Y FASE B (AppSec)

Leyenda: **OK = ejecutado realmente con resultado correcto** · **PARCIAL** = parte ejecutada, parte NO EJECUTADA (motivo indicado) · **FALLA = falló** (no queda ninguna sin corregir).

### Fase A — QA funcional (10/10)

| # | Ítem | Estado | Evidencia real |
|---|------|--------|----------------|
| A-1 | Registrar venta con Efectivo, Yape y Efectivo+Yape | OK | `tests/qa_calculos.test.js` (3 pruebas) + `evidencia/03_resumen_curl.txt` |
| A-2 | Cálculos: vendidos = entregados − sobró; efectivo = total − yape; totales del mes; fórmulas del Excel | OK | `tests/qa_calculos.test.js` (totales 189 = 40+32+25+92; efectivo/yape exactos) |
| A-3 | Datos ilegales rechazados (espacios, negativos, decimales, texto, sobró>entregados, yape>total, 1e9, NaN, Infinity, 2026-02-31, formatos) | OK | `tests/qa_validaciones.test.js` — 17 pruebas + `evidencia/03_resumen_curl.txt` |
| A-4 | Subidas: JPG/PNG/WEBP/PDF válidos; >5 MB; `.exe`→`.jpg`; vacío; nombre con caracteres extraños; sin comprobante | OK | `tests/qa_uploads_historial.test.js` (11 pruebas) + `evidencia/06…txt` |
| A-5 | Historial: filtro por mes, búsqueda con `% _ ' " ñ á`, lista vacía, eliminar + comprobante | OK | `tests/qa_uploads_historial.test.js` (10 pruebas) |
| A-6 | Excel: columnas, formato fecha/moneda, fórmulas; con 0 y con 5.000 registros | OK | `tests/qa_calculos.test.js` + `tests/qa_concurrencia_export.test.js` (5.000 filas verificadas) |
| A-7 | 50 ventas concurrentes: no se pierden ni duplican (suma exacta S/ 2,225.00) | OK | `tests/qa_concurrencia_export.test.js` |
| A-8 | Doble clic en Guardar no duplica | OK | Mismo archivo (2ª petición → 409) |
| A-9 | Responsive 360/768/1280 | **PARCIAL** | OK en navegador headless real con sesión, formulario y venta real (`evidencia/13…txt`, `pantallas/10-12.png`); **NO EJECUTADA** en dispositivos físicos (no hay móviles en este entorno) |
| A-10 | Reinicio con datos persistentes; carpeta uploads faltante; BD bloqueada | OK | `evidencia/09…txt` (8/8 PASS) y `evidencia/10…txt` (5/5 PASS) |

### Fase B — AppSec (15/15)

| # | Ítem | Estado | Evidencia real |
|---|------|--------|----------------|
| B-1 | Login + roles con hash fuerte; usuarios iniciales por variables de entorno | OK | `tests/seg_acceso.test.js` (401/403 por rol); hash scrypt en `app/credenciales.js` |
| B-2 | Cookie HttpOnly/Secure/SameSite=Strict/expiración + logout que invalida en servidor | OK | `evidencia/02_login_y_cookies.txt` + test de reuso de cookie → 401 |
| B-3 | Anti fuerza bruta (límite por IP + bloqueo de cuenta) | OK | `tests/seg_acceso.test.js` + `app/lockout.js` |
| B-4 | CSRF en POST/DELETE | OK | `evidencia/03_csrf_rechazado.txt` + tests (403 sin/ con token falso) |
| B-5 | SQL parametrizada; inyecciones reales en `nombre`, `q`, `mes`, `id` | OK | `evidencia/04_sqli.txt` + `tests/seg_inyeccion_errores.test.js` |
| B-6 | XSS no ejecuta + CSP estricta | OK | `evidencia/13_interfaz_navegador.txt` (navegador real: ejecutado=false) + tests estáticos |
| B-7 | Uploads: magic bytes, nombre del servidor, límite de tamaño, sin path traversal | OK | `evidencia/06…txt` + `tests/qa_uploads_historial.test.js` |
| B-8 | Comprobantes privados (login + rol) | OK | `evidencia/06…txt` (401/200) + tests |
| B-9 | Anti inyección de fórmulas en Excel | OK | `evidencia/07…txt` + 4 payloads en tests |
| B-10 | Helmet (CSP, nosniff, frame-ancestors, HSTS), sin CORS, X-Powered-By oculto | OK | `evidencia/05…txt` + test de cabeceras. HSTS se envía solo sobre HTTPS (config incluida; **HTTPS real NO EJECUTADA** — requiere dominio y certificado) |
| B-11 | Middleware global de errores sin fugas; JSON malformado/413/abortos controlados | OK | `tests/seg_inyeccion_errores.test.js` |
| B-12 | Sin secretos en código; `.env.example` + `.gitignore`; logs sin datos sensibles | OK | Archivos entregados (revisión estática); los logs solo registran método, ruta y código |
| B-13 | `npm audit` + versiones fijadas | OK | `evidencia/12_npm_audit.txt` (14→9 tras actualizar express/multer) |
| B-14 | Scripts de backup/restauración + cifrado documentado | OK | `evidencia/11…txt` (backup+restore reales); cifrado age/GPG documentado en LEEME.md (**cifrado automático NO EJECUTADA** — se entrega como procedimiento) |
| B-15 | Integridad: CHECK/NOT NULL, transacciones, auditoría, borrado lógico recuperable | OK | Esquema `app/db.js`, `evidencia/08_auditoria.txt`, tests de eliminar/restaurar |

---

## ④ CÓDIGO COMPLETO POR ARCHIVO (copiable)

Los mismos archivos están en la carpeta, listos para ejecutar (`npm install && npm start`).
### `package.json`

```json
{
  "name": "venta-de-libros",
  "version": "2.0.0",
  "description": "Control de libros entregados y vendidos, con pagos en efectivo/Yape, comprobantes y exportación a Excel (versión endurecida).",
  "private": true,
  "license": "UNLICENSED",
  "main": "app/server.js",
  "scripts": {
    "start": "node app/server.js",
    "test": "jest --runInBand --forceExit",
    "backup": "node scripts/backup.js",
    "restore": "node scripts/restore.js",
    "purgar": "node scripts/purgar.js",
    "prueba:reinicio": "node scripts/prueba_reinicio.js",
    "prueba:bloqueo": "node scripts/prueba_bloqueo.js"
  },
  "dependencies": {
    "better-sqlite3": "12.4.1",
    "cookie-parser": "1.4.7",
    "dotenv": "17.2.3",
    "exceljs": "4.4.0",
    "express": "4.22.3",
    "express-rate-limit": "7.5.1",
    "helmet": "8.1.0",
    "multer": "2.5.0"
  },
  "devDependencies": {
    "jest": "29.7.0",
    "supertest": "7.1.4"
  },
  "engines": {
    "node": ">=18"
  }
}

```

### `jest.config.js`

```js
// jest.config.js — Configuración de la suite de pruebas automatizadas
module.exports = {
  testEnvironment: 'node',
  setupFiles: ['<rootDir>/tests/setup.env.js'],
  testTimeout: 30000,
  clearMocks: true,
  verbose: true,
};

```

### `.env.example`

```bash
# ============================================================
# .env.example — COPIA ESTE ARCHIVO COMO ".env" Y COMPLÉTALO
# Nunca subas el archivo .env real al repositorio (ver .gitignore)
# ============================================================

# Puerto del servidor
PORT=3000

# Entorno: "production" activa cookies Secure (requiere HTTPS)
NODE_ENV=development

# Fuerza cookies Secure aunque NODE_ENV no sea production (úsalo con HTTPS)
COOKIE_SECURE=0

# Marcar como 1 solo si el servidor está detrás de un proxy inverso (nginx/caddy)
TRUST_PROXY=0

# Rutas (opcional; por defecto: ./data y ./uploads junto a la carpeta del proyecto)
# DATA_DIR=./data
# UPLOAD_DIR=./uploads
# DB_PATH=./data/ventas.db
# BACKUP_DIR=./backups

# Sesiones
SESSION_HORAS=8

# Límites anti fuerza bruta
API_LIMIT_MAX=600
LOGIN_LIMIT_MAX=5
LOCKOUT_MAX=5
LOCKOUT_MINUTOS=10

# Usuarios iniciales (solo se crean si la tabla de usuarios está vacía)
# El tesorero puede registrar, eliminar y restaurar. El de consulta solo ve.
ADMIN_USER=tesorero
ADMIN_PASSWORD=CAMBIA_ESTA_CLAVE_Tesorero2026
CONSULTA_USER=consulta
CONSULTA_PASSWORD=CAMBIA_ESTA_CLAVE_Consulta2026

# Días que se conservan los registros con borrado lógico antes de purgarlos
DIAS_PURGA=30

```

### `.gitignore`

```bash
# SEGURIDAD (Fase B-12): nunca versionar secretos, datos ni comprobantes
.env
*.db
*.db-wal
*.db-shm
data/
uploads/
backups/
node_modules/
npm-debug.log*
.evidencia-tmp/

```

### `app/server.js`

```js
// app/server.js
// ==========================================================================
// "Venta de Libros" — Servidor ENDURECIDO (v2.0.0)
// Node.js + Express + SQLite (better-sqlite3) + multer + ExcelJS.
//
// Mitigaciones implementadas (mapeo con el informe):
//  B-1  Login con roles (tesorero / consulta), scrypt, usuarios por .env
//  B-2  Cookie de sesión HttpOnly + SameSite=Strict + Secure(en HTTPS) + expiración y logout que invalida en el servidor
//  B-3  Límite de intentos de login (por IP) + bloqueo temporal por cuenta
//  B-4  Protección CSRF (token doble envío: cookie + cabecera x-csrf-token)
//  B-5  SQL 100% parametrizada (better-sqlite3 prepare)
//  B-6  Frontend sin innerHTML con datos de usuario + CSP estricta (helmet)
//  B-7  Subidas: validación de magic bytes, nombre generado por el servidor, límite 5 MB, sin rutas del cliente
//  B-8  uploads/ NO es público; los comprobantes se sirven SOLO con sesión
//  B-9  Neutralización de inyección de fórmulas en Excel
//  B-10 helmet (CSP, nosniff, frame-ancestors, HSTS en HTTPS), sin CORS, X-Powered-By oculto
//  B-11 Middleware global de errores: sin stack traces al cliente, JSON malformado y body grande controlados
//  B-12 Sin secretos en código: .env + .env.example + .gitignore; logs sin contraseñas ni tokens
//  B-13 Validación server-side completa (ver app/validaciones.js)
//  B-15 CHECK/NOT NULL, transacciones, auditoría y borrado lógico recuperable
// ==========================================================================
'use strict';

const path = require('path');
const fs = require('fs');
const crypto = require('crypto');
const express = require('express');
const helmet = require('helmet');
const cookieParser = require('cookie-parser');
const multer = require('multer');
const rateLimit = require('express-rate-limit');

const { db, migrar, auditor } = require('./db');
const { validarRegistro, sanitizarNombreOriginal } = require('./validaciones');
const { generarExcel } = require('./excel');
const { verificarPassword, sha256 } = require('./credenciales');
const lockout = require('./lockout');

// --------------------------------------------------------------------------
// Configuración (sin secretos en el código: todo viene de variables de entorno)
// --------------------------------------------------------------------------
const PUBLIC_DIR = path.join(__dirname, 'public');
const UPLOAD_DIR = path.resolve(process.env.UPLOAD_DIR || path.join(__dirname, '..', 'uploads'));
const PORT = parseInt(process.env.PORT || '3000', 10);
const SESSION_HORAS = parseInt(process.env.SESSION_HORAS || '8', 10);
// La cookie Secure se activa en producción o por fuerza con COOKIE_SECURE=1
const COOKIE_SECURE = process.env.COOKIE_SECURE === '1' || process.env.NODE_ENV === 'production';

// SEGURIDAD (Fase B-7): la carpeta de subidas se crea si no existe (Fase A-10)
fs.mkdirSync(UPLOAD_DIR, { recursive: true });

const app = express();
app.disable('x-powered-by'); // B-10: ocultar tecnología del servidor
if (process.env.TRUST_PROXY === '1') app.set('trust proxy', 1); // detrás de nginx/caddy

// --------------------------------------------------------------------------
// B-10: Cabeceras de seguridad con helmet (CSP estricta, sin inline scripts)
// --------------------------------------------------------------------------
app.use(helmet({
  contentSecurityPolicy: {
    useDefaults: true,
    directives: {
      'default-src': ["'self'"],
      'script-src': ["'self'"],
      'style-src': ["'self'"],
      'img-src': ["'self'", 'data:', 'blob:'],
      'frame-src': ["'self'", 'blob:'],
      'connect-src': ["'self'"],
      'object-src': ["'none'"],
      'frame-ancestors': ["'none'"],
      'base-uri': ["'self'"],
      'form-action': ["'self'"],
      'upgrade-insecure-requests': null, // se activa vía HTTPS/HSTS en producción (ver LEEME.md)
    },
  },
  hsts: { maxAge: 15552000, includeSubDomains: true }, // HSTS solo se envía sobre HTTPS
  frameguard: { action: 'deny' },
  referrerPolicy: { policy: 'no-referrer' },
  crossOriginResourcePolicy: { policy: 'same-origin' },
  crossOriginEmbedderPolicy: false, // permite incrustar PDF en el visor
}));
// B-10: CORS NO se habilita: la app es de mismo origen (sin Access-Control-Allow-*)

// --------------------------------------------------------------------------
// B-3: Límites de tasa (anti fuerza bruta / anti flood)
// --------------------------------------------------------------------------
const apiLimiter = rateLimit({
  windowMs: 15 * 60 * 1000,
  limit: parseInt(process.env.API_LIMIT_MAX || '600', 10),
  standardHeaders: true,
  legacyHeaders: false,
  message: { ok: false, error: 'Demasiadas solicitudes. Espera unos minutos e inténtalo de nuevo.' },
});
const loginLimiter = rateLimit({
  windowMs: 15 * 60 * 1000,
  limit: parseInt(process.env.LOGIN_LIMIT_MAX || '5', 10),
  skipSuccessfulRequests: true, // solo cuentan los intentos FALLIDOS
  standardHeaders: true,
  legacyHeaders: false,
  message: { ok: false, error: 'Demasiados intentos de inicio de sesión fallidos. Espera 15 minutos.' },
});
app.use('/api', apiLimiter);

// --------------------------------------------------------------------------
// Parseo de cuerpo: JSON y formularios con límite (B-11); multer solo multipart
// --------------------------------------------------------------------------
app.use(express.json({ limit: '100kb' }));
app.use(express.urlencoded({ extended: false, limit: '100kb' }));
app.use(cookieParser());

// B-7: multer en MEMORIA (nunca escribe rutas del cliente), 1 archivo, 5 MB
const subir = multer({
  storage: multer.memoryStorage(),
  limits: { fileSize: 5 * 1024 * 1024, files: 1 },
});

// --------------------------------------------------------------------------
// B-7: Validación de contenido real (magic bytes) — no se confía en la extensión
// --------------------------------------------------------------------------
const MIME_POR_TIPO = { jpg: 'image/jpeg', png: 'image/png', webp: 'image/webp', pdf: 'application/pdf' };

function detectarTipo(buf) {
  if (!buf || buf.length === 0) return null; // archivo vacío
  if (buf.length >= 3 && buf[0] === 0xFF && buf[1] === 0xD8 && buf[2] === 0xFF) return 'jpg';
  if (buf.length >= 8 && buf.subarray(0, 8).equals(Buffer.from([0x89, 0x50, 0x4E, 0x47, 0x0D, 0x0A, 0x1A, 0x0A]))) return 'png';
  if (buf.length >= 12 && buf.subarray(0, 4).toString('latin1') === 'RIFF' && buf.subarray(8, 12).toString('latin1') === 'WEBP') return 'webp';
  if (buf.length >= 5 && buf.subarray(0, 5).toString('latin1') === '%PDF-') return 'pdf';
  return null;
}

// --------------------------------------------------------------------------
// Sesiones guardadas en la base (logout = borrado real del token en servidor)
// --------------------------------------------------------------------------
function obtenerSesion(req) {
  const token = req.cookies && req.cookies.sesion;
  if (!token || !/^[a-f0-9]{64}$/.test(token)) return null;
  const fila = db.prepare(`
    SELECT s.csrf, s.expira_en, u.id AS usuario_id, u.usuario, u.rol, u.activo
    FROM sesiones s JOIN usuarios u ON u.id = s.usuario_id
    WHERE s.token_hash = ?`).get(sha256(token));
  if (!fila || fila.activo !== 1) return null;
  const expira = new Date(String(fila.expira_en).replace(' ', 'T') + 'Z');
  if (!(expira > new Date())) return null;
  return fila;
}

function requireAuth(req, res, next) {
  const s = obtenerSesion(req);
  if (!s) return res.status(401).json({ ok: false, error: 'No autenticado. Inicia sesión de nuevo.' });
  req.usuario = { id: s.usuario_id, nombre: s.usuario, rol: s.rol };
  req.csrfSesion = s.csrf;
  next();
}

function requireTesorero(req, res, next) {
  if (!req.usuario || req.usuario.rol !== 'tesorero') {
    return res.status(403).json({ ok: false, error: 'No autorizado: esta acción requiere el rol Tesorero.' });
  }
  next();
}

// B-4: CSRF por doble envío. El token vive en la sesión (BD) y en una cookie
// legible; el frontend debe enviarlo en la cabecera x-csrf-token.
function requireCsrf(req, res, next) {
  const cabecera = String(req.get('x-csrf-token') || '');
  const cookie = String(req.cookies.csrf || '');
  if (!cabecera || cabecera !== cookie || cabecera !== req.csrfSesion) {
    auditor(req.usuario && req.usuario.nombre, 'csrf_rechazado', req.originalUrl, req.ip);
    return res.status(403).json({ ok: false, error: 'Token de seguridad (CSRF) inválido. Recarga la página e inténtalo otra vez.' });
  }
  next();
}

// --------------------------------------------------------------------------
// Autenticación
// --------------------------------------------------------------------------
app.post('/api/login', loginLimiter, (req, res) => {
  const usuario = typeof req.body.usuario === 'string' ? req.body.usuario.trim().slice(0, 60) : '';
  const password = typeof req.body.password === 'string' ? req.body.password : '';
  if (!usuario || !password) {
    return res.status(400).json({ ok: false, error: 'Usuario y contraseña son obligatorios.' });
  }

  // B-3: bloqueo temporal por cuenta tras intentos fallidos
  const bloqueo = lockout.estado(usuario);
  if (bloqueo.bloqueado) {
    auditor(usuario, 'login_bloqueado', `intentos=${bloqueo.fallos}`, req.ip);
    return res.status(429).json({
      ok: false,
      error: `Cuenta temporalmente bloqueada por intentos fallidos. Espera ${Math.max(1, Math.ceil(bloqueo.segundosRestantes / 60))} minuto(s).`,
    });
  }

  const u = db.prepare('SELECT * FROM usuarios WHERE usuario = ? AND activo = 1').get(usuario);
  const passOk = u ? verificarPassword(password, u.password_hash) : verificarPassword(password, hashearFalso());
  if (!u || !passOk) {
    const r = lockout.registrarFallo(usuario);
    auditor(usuario, 'login_fallido', `fallo ${r.fallos}`, req.ip);
    // Mensaje genérico: no revela si el usuario existe (B-12)
    return res.status(401).json({ ok: false, error: 'Usuario o contraseña incorrectos.' });
  }

  lockout.limpiar(usuario);

  const token = crypto.randomBytes(32).toString('hex');
  const csrf = crypto.randomBytes(24).toString('hex');
  const expiraStr = new Date(Date.now() + SESSION_HORAS * 3600 * 1000)
    .toISOString().slice(0, 19).replace('T', ' ');

  const crearSesion = db.transaction(() => {
    db.prepare("DELETE FROM sesiones WHERE expira_en <= datetime('now')").run(); // limpieza de sesiones vencidas
    db.prepare('INSERT INTO sesiones (token_hash, usuario_id, csrf, expira_en) VALUES (?, ?, ?, ?)')
      .run(sha256(token), u.id, csrf, expiraStr);
  });
  crearSesion();

  const opciones = { httpOnly: true, sameSite: 'strict', path: '/', maxAge: SESSION_HORAS * 3600 * 1000, secure: COOKIE_SECURE || req.secure };
  res.cookie('sesion', token, opciones);                       // B-2: HttpOnly
  res.cookie('csrf', csrf, { ...opciones, httpOnly: false });  // B-4: legible por el frontend
  auditor(u.usuario, 'login_ok', '', req.ip);
  res.json({ ok: true, usuario: { nombre: u.usuario, rol: u.rol }, csrf });
});

// Hash desechable para igualar tiempos cuando el usuario no existe
function hashearFalso() {
  return 'scrypt$16384$8$1$' + '0'.repeat(32) + '$' + '0'.repeat(128);
}

app.post('/api/logout', requireAuth, requireCsrf, (req, res) => {
  const token = req.cookies.sesion;
  db.prepare('DELETE FROM sesiones WHERE token_hash = ?').run(sha256(token)); // B-2: invalidación real
  res.clearCookie('sesion', { path: '/' });
  res.clearCookie('csrf', { path: '/' });
  auditor(req.usuario.nombre, 'logout', '', req.ip);
  res.json({ ok: true, mensaje: 'Sesión cerrada correctamente.' });
});

app.get('/api/session', (req, res) => {
  const s = obtenerSesion(req);
  if (!s) return res.status(401).json({ ok: false, error: 'No autenticado.' });
  res.json({ ok: true, usuario: { nombre: s.usuario, rol: s.rol }, csrf: s.csrf });
});

// --------------------------------------------------------------------------
// Registro de ventas (solo tesorero)
// --------------------------------------------------------------------------
// Anti doble clic (Fase A-8): ventana de deduplicación en memoria (10 s).
const deduplicador = new Map();
const DEDUPE_MS = 10000;

app.post('/api/registros', requireAuth, requireTesorero, requireCsrf, subir.single('comprobante'), (req, res, next) => {
  try {
    const cuerpo = req.body || {};

    // B-13 / A-3: validación completa en servidor
    const v = validarRegistro(cuerpo);
    if (!v.ok) {
      return res.status(400).json({ ok: false, errores: v.errores, error: 'Revisa los campos marcados en rojo.' });
    }

    // B-7: validación de contenido real del comprobante (magic bytes)
    let archivo = null;
    let nombreOriginal = null;
    if (req.file && req.file.size === 0) {
      return res.status(400).json({ ok: false, error: 'El archivo del comprobante está vacío (0 bytes).' });
    }
    if (req.file) {
      const tipo = detectarTipo(req.file.buffer);
      if (!tipo) {
        return res.status(400).json({
          ok: false,
          error: 'El comprobante no es válido. Solo se aceptan imágenes JPG, PNG o WEBP, o un PDF real (máx. 5 MB).',
        });
      }
      archivo = crypto.randomUUID() + '.' + tipo; // B-7: nombre generado por el servidor
      nombreOriginal = sanitizarNombreOriginal(req.file.originalname);
      fs.writeFileSync(path.join(UPLOAD_DIR, archivo), req.file.buffer);
    }

    // A-8: deduplicación de envíos idénticos consecutivos (doble clic).
    // La clave incluye el hash del comprobante (si lo hay) para que dos envíos
    // con el mismo texto pero distinto archivo NO se consideren duplicados.
    const d = v.datos;
    const hashArchivo = req.file && req.file.size > 0 ? sha256(req.file.buffer.toString('binary')) : '-';
    const clave = sha256([req.usuario.id, d.fecha, d.nombre, d.total, d.metodo_pago, d.yape_monto, hashArchivo].join('|'));
    const previo = deduplicador.get(clave);
    if (previo && Date.now() - previo < DEDUPE_MS) {
      if (archivo) { try { fs.unlinkSync(path.join(UPLOAD_DIR, archivo)); } catch { /* nada */ } }
      return res.status(409).json({ ok: false, error: 'Posible envío duplicado: acabas de registrar una venta idéntica. Revisa el historial.' });
    }
    deduplicador.set(clave, Date.now());
    if (deduplicador.size > 1000) deduplicador.clear();

    // B-15: escritura atómica (registro + auditoría en una transacción)
    const insertar = db.transaction(() => {
      const info = db.prepare(`
        INSERT INTO registros (fecha, nombre, entregados, sobro, total, metodo_pago, yape_monto, efectivo_monto, comprobante, comprobante_nombre_original, creado_por)
        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`)
        .run(d.fecha, d.nombre, d.entregados, d.sobro, d.total, d.metodo_pago, d.yape_monto, d.efectivo_monto, archivo, nombreOriginal, req.usuario.nombre);
      auditor(req.usuario.nombre, 'crear_registro', `id=${info.lastInsertRowid}; nombre="${d.nombre}"; total=${d.total}`, req.ip);
      return info.lastInsertRowid;
    });
    const id = insertar();

    const registro = db.prepare('SELECT * FROM registros WHERE id = ?').get(id);
    res.status(201).json({ ok: true, registro });
  } catch (e) {
    next(e);
  }
});

// --------------------------------------------------------------------------
// Historial con filtros (mes y búsqueda por nombre) + totales
// --------------------------------------------------------------------------
app.get('/api/registros', requireAuth, (req, res, next) => {
  try {
    const condiciones = [];
    const params = [];

    const mes = req.query.mes;
    if (mes !== undefined && String(mes) !== '') {
      if (!/^\d{4}-\d{2}$/.test(String(mes))) {
        return res.status(400).json({ ok: false, error: 'El mes debe tener el formato AAAA-MM.' });
      }
      condiciones.push('fecha GLOB ?');
      params.push(String(mes) + '-[0-9][0-9]');
    }

    const q = req.query.q;
    if (q !== undefined && String(q).trim() !== '') {
      const texto = String(q).trim().slice(0, 100);
      // B-5: LIKE parametrizado y con caracteres comodín escapados (A-5)
      const escapado = texto.replace(/\\/g, '\\\\').replace(/%/g, '\\%').replace(/_/g, '\\_');
      condiciones.push("nombre LIKE ? ESCAPE '\\'");
      params.push('%' + escapado + '%');
    }

    // Borrados lógicos: solo visibles para tesorero si lo pide (B-15)
    let incluirEliminados = false;
    if (String(req.query.eliminados) === '1' && req.usuario.rol === 'tesorero') incluirEliminados = true;
    if (!incluirEliminados) condiciones.push('eliminado = 0');

    const where = condiciones.length ? 'WHERE ' + condiciones.join(' AND ') : '';

    const filas = db.prepare(`SELECT * FROM registros ${where} ORDER BY fecha DESC, id DESC LIMIT 1000`).all(...params);
    const t = db.prepare(`
      SELECT COUNT(*) AS n,
             COALESCE(SUM(total), 0)          AS total,
             COALESCE(SUM(efectivo_monto), 0) AS efectivo,
             COALESCE(SUM(yape_monto), 0)     AS yape
      FROM registros ${where}`).get(...params);

    res.json({
      ok: true,
      registros: filas,
      totales: { ventas: t.n, total: t.total, efectivo: t.efectivo, yape: t.yape },
      truncado: t.n > filas.length,
    });
  } catch (e) { next(e); }
});

// --------------------------------------------------------------------------
// Eliminación LÓGICA y restauración (B-15: recuperable + auditoría)
// --------------------------------------------------------------------------
app.delete('/api/registros/:id', requireAuth, requireTesorero, requireCsrf, (req, res, next) => {
  try {
    const id = Number(req.params.id);
    if (!Number.isInteger(id) || id <= 0) return res.status(400).json({ ok: false, error: 'ID inválido.' });
    const r = db.prepare('SELECT * FROM registros WHERE id = ? AND eliminado = 0').get(id);
    if (!r) return res.status(404).json({ ok: false, error: 'El registro no existe o ya fue eliminado.' });
    db.transaction(() => {
      db.prepare("UPDATE registros SET eliminado = 1, eliminado_en = datetime('now'), eliminado_por = ? WHERE id = ?")
        .run(req.usuario.nombre, id);
      auditor(req.usuario.nombre, 'eliminar_registro', `id=${id}; nombre="${r.nombre}" (borrado lógico, recuperable)`, req.ip);
    })();
    res.json({ ok: true, mensaje: 'Registro eliminado. Puedes recuperarlo con "Restaurar".' });
  } catch (e) { next(e); }
});

app.post('/api/registros/:id/restaurar', requireAuth, requireTesorero, requireCsrf, (req, res, next) => {
  try {
    const id = Number(req.params.id);
    if (!Number.isInteger(id) || id <= 0) return res.status(400).json({ ok: false, error: 'ID inválido.' });
    const r = db.prepare('SELECT * FROM registros WHERE id = ? AND eliminado = 1').get(id);
    if (!r) return res.status(404).json({ ok: false, error: 'No hay ningún registro eliminado con ese ID.' });
    db.transaction(() => {
      db.prepare('UPDATE registros SET eliminado = 0, eliminado_en = NULL, eliminado_por = NULL WHERE id = ?').run(id);
      auditor(req.usuario.nombre, 'restaurar_registro', `id=${id}; nombre="${r.nombre}"`, req.ip);
    })();
    res.json({ ok: true, mensaje: 'Registro restaurado correctamente.' });
  } catch (e) { next(e); }
});

// --------------------------------------------------------------------------
// B-8: Comprobantes PRIVADOS — solo con sesión válida y desde la base.
// Nunca servidos como archivos estáticos (la carpeta uploads/ no está pública).
// --------------------------------------------------------------------------
app.get('/api/comprobantes/:id', requireAuth, (req, res, next) => {
  try {
    const id = Number(req.params.id);
    if (!Number.isInteger(id) || id <= 0) return res.status(400).json({ ok: false, error: 'ID inválido.' });
    const r = db.prepare('SELECT comprobante FROM registros WHERE id = ? AND eliminado = 0').get(id);
    if (!r || !r.comprobante) return res.status(404).json({ ok: false, error: 'Comprobante no encontrado.' });
    // B-7: el nombre SIEMPRE viene de la BD con formato generado por el servidor
    if (!/^[a-f0-9-]{36}\.(jpg|png|webp|pdf)$/.test(r.comprobante)) {
      return res.status(404).json({ ok: false, error: 'Comprobante no válido.' });
    }
    const ruta = path.join(UPLOAD_DIR, r.comprobante);
    if (!ruta.startsWith(UPLOAD_DIR + path.sep) || !fs.existsSync(ruta)) {
      return res.status(404).json({ ok: false, error: 'El archivo del comprobante no está disponible.' });
    }
    auditor(req.usuario.nombre, 'ver_comprobante', `registro=${id}`, req.ip);
    res.setHeader('X-Content-Type-Options', 'nosniff');
    res.setHeader('Content-Disposition', `inline; filename="${r.comprobante}"`);
    res.sendFile(ruta);
  } catch (e) { next(e); }
});

// --------------------------------------------------------------------------
// Exportación mensual a Excel (A-6) con anti-inyección de fórmulas (B-9)
// --------------------------------------------------------------------------
app.get('/api/exportar', requireAuth, async (req, res, next) => {
  try {
    const mes = String(req.query.mes || '');
    if (!/^\d{4}-\d{2}$/.test(mes)) {
      return res.status(400).json({ ok: false, error: 'Indica un mes válido con formato AAAA-MM para exportar.' });
    }
    const filas = db.prepare(
      "SELECT * FROM registros WHERE fecha GLOB ? AND eliminado = 0 ORDER BY fecha ASC, id ASC"
    ).all(mes + '-[0-9][0-9]');
    const buffer = await generarExcel(mes, filas);
    auditor(req.usuario.nombre, 'exportar_excel', `mes=${mes}; filas=${filas.length}`, req.ip);
    res.setHeader('Content-Type', 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
    res.setHeader('Content-Disposition', `attachment; filename="ventas-${mes}.xlsx"`);
    res.send(Buffer.from(buffer));
  } catch (e) { next(e); }
});

// --------------------------------------------------------------------------
// Bitácora de auditoría (solo tesorero) — B-15
// --------------------------------------------------------------------------
app.get('/api/auditoria', requireAuth, requireTesorero, (req, res) => {
  const eventos = db.prepare('SELECT fecha, usuario, accion, detalle, ip FROM audit_log ORDER BY id DESC LIMIT 200').all();
  res.json({ ok: true, eventos });
});

// --------------------------------------------------------------------------
// B-11: 404 JSON para rutas API desconocidas + estáticos + error global
// --------------------------------------------------------------------------
app.use(express.static(PUBLIC_DIR, { maxAge: '1h', dotfiles: 'ignore' }));

app.use((req, res) => {
  if (req.path.startsWith('/api/')) return res.status(404).json({ ok: false, error: 'Ruta no encontrada.' });
  res.status(404).send('Página no encontrada.');
});

// eslint-disable-next-line no-unused-vars
app.use((err, req, res, next) => {
  if (res.headersSent) return next(err);
  let status = 500;
  let mensaje = 'Error interno del servidor. Inténtalo de nuevo.';
  if (err.type === 'entity.parse.failed') { status = 400; mensaje = 'El cuerpo de la solicitud no es un JSON válido.'; }
  else if (err.type === 'entity.too.large') { status = 413; mensaje = 'La solicitud es demasiado grande.'; }
  else if (err.code === 'LIMIT_FILE_SIZE') { status = 400; mensaje = 'El comprobante supera el tamaño máximo de 5 MB.'; }
  else if (err.code === 'SQLITE_BUSY' || err.code === 'SQLITE_BUSY_SNAPSHOT' || err.code === 'SQLITE_LOCKED') {
    status = 503; mensaje = 'La base de datos está ocupada en este momento. Inténtalo otra vez en unos segundos.';
  } else if (err.code === 'SQLITE_CONSTRAINT') {
    status = 400; mensaje = 'Los datos no cumplen las reglas de validación.';
  } else if (err.status && err.status >= 400 && err.status < 500 && err.expose) {
    status = err.status; mensaje = err.message;
  }
  // B-11/B-12: el detalle técnico solo va al log del servidor, NUNCA al cliente
  console.error(`[ERROR] ${req.method} ${req.originalUrl} -> ${status} [${err.code || err.type || 'sin código'}] ${err.message}`);
  res.status(status).json({ ok: false, error: mensaje });
});

// --------------------------------------------------------------------------
// Arranque
// --------------------------------------------------------------------------
// La migración (idempotente) corre AL CARGAR el módulo: así funcionan igual
// el servidor real y las pruebas con supertest.
migrar();

function iniciar() {
  return new Promise((resolve) => {
    const servidor = app.listen(PORT, () => {
      console.log(`Venta de Libros (v2.0.0) escuchando en el puerto ${PORT}`);
      resolve(servidor);
    });
    return servidor;
  });
}

if (require.main === module) {
  iniciar();
}

// Solo para pruebas automatizadas: reinicia los contadores de límite por IP
function resetLimitadoresPruebas() {
  for (const ip of ['127.0.0.1', '::ffff:127.0.0.1', '::1']) {
    try { apiLimiter.resetKey(ip); } catch { /* no soportado */ }
    try { loginLimiter.resetKey(ip); } catch { /* no soportado */ }
  }
}

module.exports = { app, iniciar, UPLOAD_DIR, resetLimitadoresPruebas };

```

### `app/db.js`

```js
// app/db.js
// --------------------------------------------------------------------------
// Capa de base de datos (SQLite con better-sqlite3) con:
//  - Configuración segura: WAL, busy_timeout (Fase A-10), foreign_keys ON.
//  - Migración IDEMPOTENTE para bases de datos antiguas: NO borra datos,
//    solo añade columnas faltantes y respalda antes de migrar (Fase B-15).
//  - Restricciones CHECK/NOT NULL en tablas nuevas (Fase B-15).
//  - Bitácora de auditoría (Fase B-15).
//  - Siembra inicial de usuarios SOLO si la tabla está vacía, usando
//    variables de entorno (Fase B-1); si no hay variables, genera una
//    contraseña aleatoria y la muestra UNA vez por consola.
// --------------------------------------------------------------------------
'use strict';
const fs = require('fs');
const path = require('path');
const Database = require('better-sqlite3');
const { hashearPassword } = require('./credenciales');

const ROOT = path.join(__dirname, '..');
const DATA_DIR = process.env.DATA_DIR || path.join(ROOT, 'data');
const DB_PATH = process.env.DB_PATH || path.join(DATA_DIR, 'ventas.db');
const BACKUP_DIR = process.env.BACKUP_DIR || path.join(ROOT, 'backups');

fs.mkdirSync(path.dirname(DB_PATH), { recursive: true });

const db = new Database(DB_PATH);
// SEGURIDAD/ROBUSTEZ: WAL reduce bloqueos; busy_timeout evita el error
// "database is locked" esperando hasta 5 s (ver scripts/prueba_bloqueo.js).
db.pragma('journal_mode = WAL');
db.pragma('busy_timeout = 5000');
db.pragma('foreign_keys = ON');
db.pragma('synchronous = NORMAL');

function crearTablas() {
  db.exec(`
  CREATE TABLE IF NOT EXISTS usuarios (
    id            INTEGER PRIMARY KEY AUTOINCREMENT,
    usuario       TEXT    NOT NULL UNIQUE,
    password_hash TEXT    NOT NULL,
    rol           TEXT    NOT NULL CHECK (rol IN ('tesorero','consulta')),
    activo        INTEGER NOT NULL DEFAULT 1 CHECK (activo IN (0,1)),
    creado_en     TEXT    NOT NULL DEFAULT (datetime('now'))
  );

  CREATE TABLE IF NOT EXISTS sesiones (
    token_hash TEXT    PRIMARY KEY,
    usuario_id INTEGER NOT NULL REFERENCES usuarios(id),
    csrf       TEXT    NOT NULL,
    creado_en  TEXT    NOT NULL DEFAULT (datetime('now')),
    expira_en  TEXT    NOT NULL
  );

  CREATE TABLE IF NOT EXISTS audit_log (
    id      INTEGER PRIMARY KEY AUTOINCREMENT,
    fecha   TEXT NOT NULL DEFAULT (datetime('now')),
    usuario TEXT,
    accion  TEXT NOT NULL,
    detalle TEXT,
    ip      TEXT
  );

  CREATE TABLE IF NOT EXISTS registros (
    id            INTEGER PRIMARY KEY AUTOINCREMENT,
    fecha         TEXT    NOT NULL CHECK (fecha GLOB '[0-9][0-9][0-9][0-9]-[0-9][0-9]-[0-9][0-9]'),
    nombre        TEXT    NOT NULL CHECK (length(trim(nombre)) > 0 AND length(nombre) <= 100),
    entregados    INTEGER NOT NULL CHECK (entregados >= 0 AND entregados <= 10000),
    sobro         INTEGER NOT NULL CHECK (sobro >= 0 AND sobro <= entregados),
    total         REAL    NOT NULL CHECK (total > 0 AND total <= 1000000),
    metodo_pago   TEXT    NOT NULL CHECK (metodo_pago IN ('efectivo','yape','mixto')),
    yape_monto    REAL    NOT NULL DEFAULT 0 CHECK (yape_monto >= 0 AND yape_monto <= total),
    efectivo_monto REAL   NOT NULL DEFAULT 0 CHECK (efectivo_monto >= 0),
    comprobante   TEXT,
    comprobante_nombre_original TEXT,
    eliminado     INTEGER NOT NULL DEFAULT 0 CHECK (eliminado IN (0,1)),
    eliminado_en  TEXT,
    eliminado_por TEXT,
    creado_en     TEXT    NOT NULL DEFAULT (datetime('now')),
    creado_por    TEXT
  );
  `);
}

// Migración idempotente para bases antiguas (v1): añade columnas faltantes.
function migrarColumnasLegacy() {
  const cols = db.prepare('PRAGMA table_info(registros)').all().map((c) => c.name);
  const faltantes = {
    metodo_pago: "ALTER TABLE registros ADD COLUMN metodo_pago TEXT NOT NULL DEFAULT 'efectivo'",
    yape_monto: 'ALTER TABLE registros ADD COLUMN yape_monto REAL NOT NULL DEFAULT 0',
    efectivo_monto: 'ALTER TABLE registros ADD COLUMN efectivo_monto REAL NOT NULL DEFAULT 0',
    comprobante: 'ALTER TABLE registros ADD COLUMN comprobante TEXT',
    comprobante_nombre_original: 'ALTER TABLE registros ADD COLUMN comprobante_nombre_original TEXT',
    eliminado: 'ALTER TABLE registros ADD COLUMN eliminado INTEGER NOT NULL DEFAULT 0',
    eliminado_en: 'ALTER TABLE registros ADD COLUMN eliminado_en TEXT',
    eliminado_por: 'ALTER TABLE registros ADD COLUMN eliminado_por TEXT',
    creado_en: "ALTER TABLE registros ADD COLUMN creado_en TEXT NOT NULL DEFAULT (datetime('now'))",
    creado_por: 'ALTER TABLE registros ADD COLUMN creado_por TEXT',
  };
  const pendientes = Object.keys(faltantes).filter((c) => !cols.includes(c));
  if (pendientes.length > 0) {
    // SEGURIDAD (Fase B-14): respaldo automático ANTES de tocar la estructura.
    respaldarAntesDeMigrar();
    for (const col of pendientes) db.exec(faltantes[col]);
    console.log(`[migración] Se añadieron columnas: ${pendientes.join(', ')}`);
  }
}

function respaldarAntesDeMigrar() {
  try {
    db.pragma('wal_checkpoint(TRUNCATE)');
    const ts = new Date().toISOString().replace(/[:T]/g, '-').slice(0, 19);
    fs.mkdirSync(BACKUP_DIR, { recursive: true });
    const destino = path.join(BACKUP_DIR, `pre-migracion-${ts}.db`);
    fs.copyFileSync(DB_PATH, destino);
    console.log(`[migración] Respaldo previo guardado en ${destino}`);
  } catch (e) {
    console.error('[migración] No se pudo respaldar antes de migrar:', e.message);
  }
}

function sembrarUsuarios() {
  const n = db.prepare('SELECT COUNT(*) AS n FROM usuarios').get().n;
  if (n > 0) return;
  // Fase B-1: usuarios iniciales SOLO por variables de entorno.
  const tesoreroUser = (process.env.ADMIN_USER || '').trim();
  const tesoreroPass = process.env.ADMIN_PASSWORD || '';
  const consultaUser = (process.env.CONSULTA_USER || '').trim();
  const consultaPass = process.env.CONSULTA_PASSWORD || '';

  const insertar = db.prepare(
    'INSERT INTO usuarios (usuario, password_hash, rol) VALUES (?, ?, ?)'
  );

  if (tesoreroUser && tesoreroPass) {
    insertar.run(tesoreroUser, hashearPassword(tesoreroPass), 'tesorero');
    console.log(`[usuarios] Tesorero creado desde variables de entorno: ${tesoreroUser}`);
  } else {
    const aleatoria = require('crypto').randomBytes(9).toString('base64url');
    insertar.run('tesorero', hashearPassword(aleatoria), 'tesorero');
    console.log('==========================================================');
    console.log('[usuarios] No se definieron ADMIN_USER/ADMIN_PASSWORD.');
    console.log('[usuarios] Usuario "tesorero" creado con contraseña ALEATORIA (mostrada UNA vez, guárdela):');
    console.log('           ' + aleatoria);
    console.log('==========================================================');
  }

  if (consultaUser && consultaPass) {
    insertar.run(consultaUser, hashearPassword(consultaPass), 'consulta');
    console.log(`[usuarios] Usuario de consulta creado desde variables de entorno: ${consultaUser}`);
  }
}

function migrar() {
  crearTablas();
  migrarColumnasLegacy();
  db.exec(`
    CREATE INDEX IF NOT EXISTS idx_registros_fecha  ON registros(fecha);
    CREATE INDEX IF NOT EXISTS idx_registros_nombre ON registros(nombre);
    CREATE INDEX IF NOT EXISTS idx_sesiones_usuario ON sesiones(usuario_id);
  `);
  sembrarUsuarios();
}

function auditor(usuario, accion, detalle, ip) {
  try {
    db.prepare('INSERT INTO audit_log (usuario, accion, detalle, ip) VALUES (?, ?, ?, ?)')
      .run(usuario || null, accion, detalle || null, ip || null);
  } catch (e) {
    console.error('[auditoría] no se pudo registrar el evento:', e.message);
  }
}

module.exports = { db, migrar, auditor, DB_PATH, UPLOAD_DIR_DEFAULT: null };

```

### `app/credenciales.js`

```js
// app/credenciales.js
// --------------------------------------------------------------------------
// SEGURIDAD (Fase B-1): hash fuerte de contraseñas con scrypt (node:crypto).
// Se usa scrypt en lugar de argon2 para evitar una dependencia nativa extra;
// scrypt es un KDF recomendado por OWASP (resistente a GPU, con parámetros N/r/p).
// Formato almacenado: scrypt$N$r$p$SALT_HEX$HASH_HEX
// Nunca se guardan ni se registran contraseñas en texto plano.
// --------------------------------------------------------------------------
'use strict';
const crypto = require('crypto');

const PARAMS = { N: 16384, r: 8, p: 1, KEYLEN: 64 };

function hashearPassword(plain) {
  const salt = crypto.randomBytes(16);
  const hash = crypto.scryptSync(String(plain), salt, PARAMS.KEYLEN, {
    N: PARAMS.N, r: PARAMS.r, p: PARAMS.p,
  });
  return ['scrypt', PARAMS.N, PARAMS.r, PARAMS.p, salt.toString('hex'), hash.toString('hex')].join('$');
}

function verificarPassword(plain, almacenado) {
  try {
    const partes = String(almacenado).split('$');
    if (partes.length !== 6 || partes[0] !== 'scrypt') return false;
    const N = parseInt(partes[1], 10), r = parseInt(partes[2], 10), p = parseInt(partes[3], 10);
    const salt = Buffer.from(partes[4], 'hex');
    const hashEsperado = Buffer.from(partes[5], 'hex');
    const hashCalculado = crypto.scryptSync(String(plain), salt, hashEsperado.length, { N, r, p });
    // Comparación en tiempo constante para evitar ataques de temporización
    return hashEsperado.length === hashCalculado.length && crypto.timingSafeEqual(hashEsperado, hashCalculado);
  } catch {
    return false;
  }
}

function sha256(texto) {
  return crypto.createHash('sha256').update(String(texto)).digest('hex');
}

module.exports = { hashearPassword, verificarPassword, sha256 };

```

### `app/validaciones.js`

```js
// app/validaciones.js
// --------------------------------------------------------------------------
// Validación central en el SERVIDOR (Fase A-3 y Fase B-13). El cliente no se
// confía: todos los límites y formatos se re-verifican aquí.
// Mensajes 100% en español para que el usuario entienda qué corregir.
// --------------------------------------------------------------------------
'use strict';

const MAX_TOTAL = 1000000;   // S/ 1,000,000.00 — rechaza 1e9 y números absurdos
const MAX_CANT = 10000;      // libros por registro

function esFechaValida(s) {
  // Acepta SOLO AAAA-MM-DD y fechas de calendario reales (rechaza 2026-02-31).
  if (typeof s !== 'string' || !/^\d{4}-\d{2}-\d{2}$/.test(s)) return false;
  const [a, m, d] = s.split('-').map(Number);
  if (m < 1 || m > 12 || d < 1 || d > 31) return false;
  const dt = new Date(Date.UTC(a, m - 1, d));
  return dt.getUTCFullYear() === a && dt.getUTCMonth() === m - 1 && dt.getUTCDate() === d;
}

function leerNumero(v) {
  if (typeof v === 'number') return v;
  if (typeof v === 'string' && v.trim() !== '') return Number(v.trim());
  return NaN;
}

function leerEntero(v) {
  if (typeof v === 'number' && Number.isInteger(v)) return v;
  if (typeof v === 'string' && /^-?\d+$/.test(v.trim())) return parseInt(v.trim(), 10);
  return NaN;
}

function validarRegistro(c) {
  const errores = {};
  const out = {};

  // --- Fecha ---
  if (!esFechaValida(c.fecha)) {
    errores.fecha = 'Fecha inválida. Usa el formato AAAA-MM-DD y una fecha real.';
  } else {
    out.fecha = c.fecha;
  }

  // --- Nombre ---
  const nombre = typeof c.nombre === 'string' ? c.nombre.trim() : '';
  if (!nombre) {
    errores.nombre = 'El nombre es obligatorio (no puede quedar vacío ni con solo espacios).';
  } else if (nombre.length > 100) {
    errores.nombre = 'El nombre no puede superar los 100 caracteres.';
  } else if (/[\u0000-\u001F\u007F]/.test(nombre)) {
    errores.nombre = 'El nombre contiene caracteres de control no permitidos.';
  } else {
    out.nombre = nombre;
  }

  // --- Cantidades enteras ---
  const entregados = leerEntero(c.entregados);
  const sobro = leerEntero(c.sobro);
  if (!Number.isInteger(entregados) || entregados < 0 || entregados > MAX_CANT) {
    errores.entregados = 'Entregados debe ser un número entero entre 0 y 10000.';
  }
  if (!Number.isInteger(sobro) || sobro < 0 || sobro > MAX_CANT) {
    errores.sobro = 'Sobró debe ser un número entero entre 0 y 10000.';
  }
  if (!errores.entregados && !errores.sobro && sobro > entregados) {
    errores.sobro = 'Sobró no puede ser mayor que Entregados.';
  }
  if (!errores.entregados && !errores.sobro) {
    out.entregados = entregados;
    out.sobro = sobro;
  }

  // --- Total en soles ---
  const total = leerNumero(c.total);
  if (!Number.isFinite(total) || total <= 0 || total > MAX_TOTAL) {
    errores.total = 'El total debe ser un número mayor a 0 y hasta S/ 1,000,000.00.';
  } else {
    out.total = Math.round(total * 100) / 100;
  }

  // --- Método de pago ---
  const metodo = c.metodo_pago;
  if (!['efectivo', 'yape', 'mixto'].includes(metodo)) {
    errores.metodo_pago = 'Selecciona un método de pago válido: Efectivo, Yape o Efectivo + Yape.';
  } else {
    out.metodo_pago = metodo;
  }

  // --- Montos Yape / Efectivo ---
  // Regla acordada: el usuario SOLO ingresa el monto Yape (en "mixto");
  // el efectivo se calcula automáticamente como Total − Yape.
  let yape = 0;
  if (metodo === 'yape') {
    yape = out.total !== undefined ? out.total : NaN; // Yape cubre todo el total
  } else if (metodo === 'mixto') {
    const y = leerNumero(c.yape_monto);
    if (!Number.isFinite(y) || y <= 0) {
      errores.yape_monto = 'Ingresa el monto pagado con Yape (mayor a 0).';
    } else if (out.total !== undefined && y >= out.total) {
      errores.yape_monto = 'El monto Yape debe ser menor que el total, porque el resto se paga en efectivo.';
    } else {
      yape = y;
    }
  }
  if (!errores.yape_monto && out.total !== undefined && yape > out.total) {
    errores.yape_monto = 'El monto Yape no puede superar el total.';
  }
  if (!errores.total && !errores.yape_monto && out.metodo_pago) {
    out.yape_monto = Math.round(yape * 100) / 100;
    out.efectivo_monto = Math.round((out.total - yape) * 100) / 100;
    if (out.efectivo_monto < 0) errores.yape_monto = 'El monto Yape no puede superar el total.';
  }

  return { ok: Object.keys(errores).length === 0, datos: out, errores };
}

// SEGURIDAD (Fase B-9): neutraliza inyección de fórmulas en Excel.
// Si un texto empieza con = + - @ tab o retorno, se antepone una comilla
// simple para que Excel lo trate como texto y no lo ejecute.
function neutralizar(texto) {
  const t = String(texto == null ? '' : texto);
  if (/^[=+\-@\t\r]/.test(t)) return "'" + t;
  return t;
}

// Sanea el nombre original del archivo subido: sin rutas, sin caracteres de
// control, longitud limitada. SOLO se usa para mostrarlo; el archivo se
// guarda con un nombre generado por el servidor (Fase B-7).
function sanitizarNombreOriginal(s) {
  let t = String(s || '')
    .split(/[/\\]/).pop()
    .replace(/[\u0000-\u001F\u007F]/g, '')
    .trim()
    .slice(0, 120);
  return t || 'comprobante';
}

module.exports = {
  validarRegistro,
  esFechaValida,
  neutralizar,
  sanitizarNombreOriginal,
  MAX_TOTAL,
  MAX_CANT,
};

```

### `app/lockout.js`

```js
// app/lockout.js
// --------------------------------------------------------------------------
// SEGURIDAD (Fase B-3): bloqueo temporal por cuenta tras N intentos fallidos
// de inicio de sesión (complementa el límite por IP de express-rate-limit).
// Estado en memoria: si el proceso reinicia, el bloqueo se libera, pero el
// límite por IP y el hash scrypt siguen protegiendo.
// --------------------------------------------------------------------------
'use strict';

const MAX_FALLOS = parseInt(process.env.LOCKOUT_MAX || '5', 10);
const VENTANA_MS = 15 * 60 * 1000;                                   // ventana de conteo: 15 min
const BLOQUEO_MS = parseInt(process.env.LOCKOUT_MINUTOS || '10', 10) * 60 * 1000; // 10 min por defecto

const estado_ = new Map(); // usuario -> { fallos, ultimo, bloqueadoHasta }

function normalizar(usuario) {
  return String(usuario || '').trim().toLowerCase();
}

function estado(usuario) {
  const e = estado_.get(normalizar(usuario));
  if (!e) return { bloqueado: false, fallos: 0, segundosRestantes: 0 };
  // Si pasó la ventana desde el último intento, se reinicia el conteo.
  if (Date.now() - (e.ultimo || 0) > VENTANA_MS) {
    e.fallos = 0;
    e.bloqueadoHasta = 0;
  }
  if (e.bloqueadoHasta && e.bloqueadoHasta > Date.now()) {
    return { bloqueado: true, fallos: e.fallos, segundosRestantes: Math.ceil((e.bloqueadoHasta - Date.now()) / 1000) };
  }
  return { bloqueado: false, fallos: e.fallos, segundosRestantes: 0 };
}

function registrarFallo(usuario) {
  const clave = normalizar(usuario);
  const e = estado_.get(clave) || { fallos: 0, ultimo: 0, bloqueadoHasta: 0 };
  if (Date.now() - e.ultimo > VENTANA_MS) { e.fallos = 0; e.bloqueadoHasta = 0; }
  e.fallos += 1;
  e.ultimo = Date.now();
  if (e.fallos >= MAX_FALLOS) e.bloqueadoHasta = Date.now() + BLOQUEO_MS;
  estado_.set(clave, e);
  return { fallos: e.fallos, bloqueado: !!(e.bloqueadoHasta && e.bloqueadoHasta > Date.now()) };
}

function limpiar(usuario) {
  estado_.delete(normalizar(usuario));
}

// Solo para pruebas automatizadas
function _reset() { estado_.clear(); }

module.exports = { estado, registrarFallo, limpiar, _reset };

```

### `app/excel.js`

```js
// app/excel.js
// --------------------------------------------------------------------------
// Exportación mensual a Excel (Fase A-6) con:
//  - Columnas: Fecha | Nombre | Entregados | Sobró | Vendidos | Total (S/) |
//    Método de pago | Yape (S/) | Efectivo (S/) | Comprobante
//  - Fórmulas reales: Vendidos = Entregados − Sobró (por fila) y TOTAL con SUM.
//  - Formato de moneda: "S/" #,##0.00  y formato de fecha dd/mm/yyyy.
//  - SEGURIDAD (Fase B-9): textos de usuario neutralizados contra inyección
//    de fórmulas (= + - @) mediante app/validaciones.js::neutralizar.
// --------------------------------------------------------------------------
'use strict';
const ExcelJS = require('exceljs');
const { neutralizar } = require('./validaciones');

const FMT_SOL = '"S/" #,##0.00';
const FMT_FECHA = 'dd/mm/yyyy';

const ETIQUETAS_METODO = {
  efectivo: 'Efectivo',
  yape: 'Yape',
  mixto: 'Efectivo + Yape',
};

async function generarExcel(mes, filas) {
  const wb = new ExcelJS.Workbook();
  wb.creator = 'Venta de Libros';
  wb.created = new Date();

  const ws = wb.addWorksheet(`Ventas ${mes}`);
  ws.columns = [
    { header: 'Fecha', key: 'fecha', width: 12 },
    { header: 'Nombre', key: 'nombre', width: 32 },
    { header: 'Entregados', key: 'entregados', width: 12 },
    { header: 'Sobró', key: 'sobro', width: 10 },
    { header: 'Vendidos', key: 'vendidos', width: 10 },
    { header: 'Total (S/)', key: 'total', width: 14 },
    { header: 'Método de pago', key: 'metodo_pago', width: 18 },
    { header: 'Yape (S/)', key: 'yape_monto', width: 14 },
    { header: 'Efectivo (S/)', key: 'efectivo_monto', width: 14 },
    { header: 'Comprobante', key: 'comprobante', width: 14 },
  ];

  filas.forEach((f, i) => {
    const r = i + 2; // la fila 1 es el encabezado
    const fila = ws.addRow([
      new Date(f.fecha + 'T12:00:00Z'),            // fecha como fecha real de Excel
      neutralizar(f.nombre),                        // anti inyección de fórmulas
      f.entregados,
      f.sobro,
      { formula: `C${r}-D${r}` },                   // Vendidos = Entregados - Sobró
      f.total,
      ETIQUETAS_METODO[f.metodo_pago] || f.metodo_pago,
      f.yape_monto,
      f.efectivo_monto,
      f.comprobante ? 'Sí' : 'No',
    ]);
    fila.getCell(1).numFmt = FMT_FECHA;
    fila.getCell(6).numFmt = FMT_SOL;
    fila.getCell(8).numFmt = FMT_SOL;
    fila.getCell(9).numFmt = FMT_SOL;
  });

  // Fila TOTAL con fórmulas SUM (o ceros si el mes no tiene ventas)
  const n = filas.length;
  const filaTotal = ws.addRow(['TOTAL', '', '', '', '', '', '', '', '', '']);
  const celdasSuma = [3, 4, 5, 6, 8, 9];
  if (n > 0) {
    celdasSuma.forEach((c) => {
      const letra = ['A', 'B', 'C', 'D', 'E', 'F', 'G', 'H', 'I', 'J'][c - 1];
      filaTotal.getCell(c).value = { formula: `SUM(${letra}2:${letra}${n + 1})` };
    });
  } else {
    celdasSuma.forEach((c) => { filaTotal.getCell(c).value = 0; });
  }
  [6, 8, 9].forEach((c) => { filaTotal.getCell(c).numFmt = FMT_SOL; });
  filaTotal.font = { bold: true };

  ws.getRow(1).font = { bold: true };
  ws.getRow(1).fill = { type: 'pattern', pattern: 'solid', fgColor: { argb: 'FFDCE6F1' } };
  ws.views = [{ state: 'frozen', ySplit: 1 }];

  return wb.xlsx.writeBuffer();
}

module.exports = { generarExcel };

```

### `app/public/index.html`

```html
<!DOCTYPE html>
<html lang="es">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Venta de Libros</title>
  <link rel="icon" href="data:,">
  <link rel="stylesheet" href="/styles.css">
</head>
<body>

  <!-- ============ INTERFAZ 1: Iniciar sesión ============ -->
  <section id="vista-login" class="vista" hidden>
    <form id="form-login" class="tarjeta login" novalidate>
      <h1>Venta de Libros</h1>
      <p class="sub">Control de libros entregados, vendidos y cobros</p>
      <label>Usuario
        <input id="login-usuario" name="usuario" autocomplete="username" required>
      </label>
      <label>Contraseña
        <input type="password" id="login-password" name="password" autocomplete="current-password" required>
      </label>
      <p id="login-error" class="error" role="alert" hidden></p>
      <button type="submit" id="btn-login" class="btn primario ancho">Iniciar sesión</button>
    </form>
  </section>

  <!-- ============ INTERFAZ 2: Aplicación principal ============ -->
  <section id="vista-app" class="vista" hidden>
    <header class="topbar">
      <h1>Venta de Libros</h1>
      <div class="usuario-box">
        <span id="badge-rol" class="badge"></span>
        <span id="nombre-usuario" class="nombre-usuario"></span>
        <button id="btn-logout" type="button" class="btn secundario">Cerrar sesión</button>
      </div>
    </header>

    <p id="aviso-consulta" class="aviso" hidden>
      Modo consulta: puedes ver el historial y los comprobantes, pero no modificar registros.
    </p>

    <main class="contenido">

      <!-- ============ INTERFAZ 3: Registrar venta (tesorero) ============ -->
      <section id="panel-registro" class="tarjeta" hidden>
        <h2>Registrar venta</h2>
        <form id="form-venta" novalidate>
          <div class="grid">
            <label>Fecha
              <input type="date" id="campo-fecha" required>
            </label>
            <label>Nombre de la persona
              <input id="campo-nombre" maxlength="100" placeholder="Ej.: Rosa Quispe" autocomplete="off" required>
            </label>
            <label>Libros entregados
              <input type="number" id="campo-entregados" min="0" max="10000" step="1" inputmode="numeric" required>
            </label>
            <label>Libros que sobraron
              <input type="number" id="campo-sobro" min="0" max="10000" step="1" inputmode="numeric" required>
            </label>
            <label class="resaltado">Libros vendidos
              <output id="preview-vendidos">–</output>
            </label>
            <label>Total cobrado (S/)
              <input type="number" id="campo-total" min="0.01" max="1000000" step="0.01" inputmode="decimal" required>
            </label>
          </div>

          <fieldset>
            <legend>Método de pago</legend>
            <label class="radio"><input type="radio" name="metodo" value="efectivo" checked> Efectivo</label>
            <label class="radio"><input type="radio" name="metodo" value="yape"> Yape</label>
            <label class="radio"><input type="radio" name="metodo" value="mixto"> Efectivo + Yape</label>
          </fieldset>

          <div id="bloque-yape" hidden>
            <label>Monto pagado con Yape (S/)
              <input type="number" id="campo-yape" min="0.01" step="0.01" inputmode="decimal">
            </label>
            <p class="ayuda">Se cobra en efectivo: <output id="preview-efectivo">–</output> (calculado solo: Total − Yape)</p>
          </div>

          <label>Comprobante de Yape (imagen JPG/PNG/WEBP o PDF, máx. 5 MB — opcional)
            <input type="file" id="campo-comprobante" accept="image/jpeg,image/png,image/webp,application/pdf">
          </label>
          <p id="archivo-seleccionado" class="ayuda" hidden></p>

          <p id="error-form" class="error" role="alert" hidden></p>
          <p id="exito-form" class="exito" role="status" hidden></p>

          <div class="acciones">
            <button type="submit" id="btn-guardar" class="btn primario">Guardar</button>
          </div>
        </form>
      </section>

      <!-- ============ INTERFAZ 4: Historial, filtros, totales y Excel ============ -->
      <section class="tarjeta">
        <h2>Historial de ventas</h2>
        <div class="filtros">
          <label>Mes
            <input type="month" id="filtro-mes">
          </label>
          <label>Buscar por nombre
            <input id="filtro-q" placeholder="Nombre…" autocomplete="off">
          </label>
          <label class="radio" id="filtro-eliminados-box" hidden>
            <input type="checkbox" id="filtro-eliminados"> Ver eliminados
          </label>
          <button id="btn-filtrar" type="button" class="btn secundario">Filtrar</button>
          <button id="btn-exportar" type="button" class="btn secundario">Exportar Excel (mes)</button>
        </div>

        <div class="totales" id="totales">
          <div class="chip"><span class="num" id="tot-ventas">0</span><span class="lbl">ventas</span></div>
          <div class="chip"><span class="num" id="tot-libros">0</span><span class="lbl">libros vendidos</span></div>
          <div class="chip"><span class="num" id="tot-total">S/ 0.00</span><span class="lbl">total</span></div>
          <div class="chip"><span class="num" id="tot-efectivo">S/ 0.00</span><span class="lbl">efectivo</span></div>
          <div class="chip"><span class="num" id="tot-yape">S/ 0.00</span><span class="lbl">yape</span></div>
        </div>

        <p id="aviso-vacio" class="ayuda" hidden>No hay ventas para este filtro.</p>

        <div class="tabla-scroll">
          <table id="tabla-ventas">
            <thead>
              <tr>
                <th>Fecha</th><th>Nombre</th><th>Entreg.</th><th>Sobró</th><th>Vend.</th>
                <th>Total</th><th>Método</th><th>Comprobante</th><th>Acciones</th>
              </tr>
            </thead>
            <tbody id="cuerpo-tabla"></tbody>
          </table>
        </div>
      </section>

      <!-- ============ INTERFAZ 5: Auditoría (solo tesorero) ============ -->
      <section id="panel-auditoria" class="tarjeta" hidden>
        <h2>Auditoría reciente</h2>
        <div class="tabla-scroll">
          <table>
            <thead><tr><th>Fecha (UTC)</th><th>Usuario</th><th>Acción</th><th>Detalle</th></tr></thead>
            <tbody id="cuerpo-auditoria"></tbody>
          </table>
        </div>
      </section>

    </main>
  </section>

  <!-- ============ INTERFAZ 6: Visor de comprobante (protegido) ============ -->
  <div id="modal-comprobante" class="modal" hidden>
    <div class="modal-contenido" role="dialog" aria-modal="true" aria-labelledby="modal-titulo">
      <header>
        <h3 id="modal-titulo">Comprobante</h3>
        <button id="btn-cerrar-modal" type="button" class="btn secundario" aria-label="Cerrar">✕</button>
      </header>
      <div id="modal-cuerpo"></div>
    </div>
  </div>

  <div id="toast" class="toast" hidden></div>

  <script src="/app.js" defer></script>
</body>
</html>

```

### `app/public/styles.css`

```css
/* ==========================================================================
   Venta de Libros — Hoja de estilos (interfaz responsive: 360 / 768 / 1280)
   Diseño móvil primero; sin estilos en línea (requisito de la CSP).
   ========================================================================== */
:root {
  --color-primario: #1f4e8c;
  --color-primario-oscuro: #16385f;
  --color-acento: #0e7c66;
  --color-peligro: #b3261e;
  --color-fondo: #f2f5f9;
  --color-tarjeta: #ffffff;
  --color-texto: #1c2430;
  --color-texto-suave: #5b6a7d;
  --color-borde: #d7dee8;
  --radio: 10px;
  --sombra: 0 2px 8px rgba(23, 43, 77, 0.10);
}

* { box-sizing: border-box; }

html, body {
  margin: 0;
  padding: 0;
  background: var(--color-fondo);
  color: var(--color-texto);
  font-family: system-ui, -apple-system, "Segoe UI", Roboto, Arial, sans-serif;
  font-size: 16px;
  line-height: 1.45;
}

h1 { font-size: 1.25rem; margin: 0; }
h2 { font-size: 1.1rem; margin: 0 0 12px; }
h3 { margin: 0; }

/* ---------- Vistas ---------- */
/* !important es necesario: #vista-login tiene display:flex por ID y pisa el
   atributo hidden de HTML (bug real detectado en la verificación con navegador) */
.vista[hidden] { display: none !important; }

/* ---------- Login ---------- */
#vista-login {
  min-height: 100vh;
  display: flex;
  align-items: center;
  justify-content: center;
  padding: 16px;
}
.login { width: 100%; max-width: 360px; }
.login h1 { color: var(--color-primario); font-size: 1.5rem; }
.login .sub { margin: 4px 0 16px; color: var(--color-texto-suave); }

/* ---------- Tarjetas ---------- */
.tarjeta {
  background: var(--color-tarjeta);
  border: 1px solid var(--color-borde);
  border-radius: var(--radio);
  box-shadow: var(--sombra);
  padding: 16px;
  margin-bottom: 16px;
}

/* ---------- Barra superior ---------- */
.topbar {
  background: var(--color-primario);
  color: #fff;
  padding: 10px 14px;
  display: flex;
  flex-wrap: wrap;
  gap: 8px;
  align-items: center;
  justify-content: space-between;
}
.usuario-box { display: flex; align-items: center; gap: 8px; flex-wrap: wrap; }
.nombre-usuario { font-weight: 600; }

.badge {
  display: inline-block;
  padding: 2px 10px;
  border-radius: 999px;
  font-size: 0.78rem;
  font-weight: 700;
  background: var(--color-acento);
  color: #fff;
}
.badge.consulta { background: #8a6d1f; }

.aviso {
  margin: 10px 14px 0;
  padding: 10px 12px;
  background: #fff7e0;
  border: 1px solid #e6d9a8;
  border-radius: var(--radio);
  color: #6b5b16;
}

/* ---------- Contenido ---------- */
.contenido { padding: 14px; max-width: 1100px; margin: 0 auto; }

/* ---------- Formularios ---------- */
label { display: block; font-weight: 600; font-size: 0.92rem; margin-bottom: 10px; }
input[type="text"], input[type="password"], input[type="number"], input[type="date"],
input[type="month"], input:not([type]), select {
  width: 100%;
  padding: 9px 10px;
  margin-top: 4px;
  border: 1px solid var(--color-borde);
  border-radius: 8px;
  font-size: 1rem;
  background: #fff;
  color: var(--color-texto);
}
input:focus-visible, button:focus-visible, output:focus-visible {
  outline: 2px solid var(--color-primario);
  outline-offset: 1px;
}
input[type="file"] { margin-top: 6px; }

.grid { display: grid; grid-template-columns: 1fr; gap: 0 14px; }

fieldset {
  border: 1px solid var(--color-borde);
  border-radius: 8px;
  padding: 10px 12px;
  margin: 8px 0 12px;
}
legend { font-weight: 700; font-size: 0.92rem; padding: 0 6px; }
label.radio { display: inline-flex; align-items: center; gap: 6px; font-weight: 500; margin: 4px 14px 4px 0; }
label.radio input { width: auto; margin: 0; }

.resaltado output {
  display: inline-block;
  min-height: 40px;
  padding: 8px 10px;
  border-radius: 8px;
  background: #eef4ee;
  border: 1px dashed var(--color-acento);
  font-weight: 800;
  color: var(--color-acento);
}

.ayuda { color: var(--color-texto-suave); font-size: 0.86rem; margin: 4px 0 10px; }

.error {
  background: #fdecea;
  border: 1px solid #f2b8b5;
  color: #8c1d18;
  padding: 8px 10px;
  border-radius: 8px;
  font-size: 0.9rem;
  margin: 8px 0;
}
.exito {
  background: #e7f4ee;
  border: 1px solid #b3dfcd;
  color: #14532d;
  padding: 8px 10px;
  border-radius: 8px;
  font-size: 0.9rem;
  margin: 8px 0;
}

/* ---------- Botones ---------- */
.btn {
  border: 1px solid transparent;
  border-radius: 8px;
  padding: 10px 16px;
  font-size: 0.95rem;
  font-weight: 700;
  cursor: pointer;
  transition: filter 0.15s ease, background 0.15s ease;
}
.btn:disabled { opacity: 0.55; cursor: not-allowed; }
.btn.primario { background: var(--color-primario); color: #fff; }
.btn.primario:hover:not(:disabled) { background: var(--color-primario-oscuro); }
.btn.secundario { background: #eef2f8; color: var(--color-primario); border-color: var(--color-borde); }
.btn.secundario:hover:not(:disabled) { background: #e0e8f4; }
.btn.peligro { background: var(--color-peligro); color: #fff; }
.btn.peligro:hover:not(:disabled) { filter: brightness(0.9); }
.btn.chico { padding: 5px 10px; font-size: 0.82rem; }
.btn.ancho { width: 100%; margin-top: 6px; }

.acciones { display: flex; gap: 10px; }

/* ---------- Filtros ---------- */
.filtros {
  display: flex;
  flex-wrap: wrap;
  gap: 4px 12px;
  align-items: end;
  margin-bottom: 12px;
}
.filtros label { margin-bottom: 6px; min-width: 150px; flex: 1 1 160px; }
.filtros .btn { margin-bottom: 6px; }

/* ---------- Totales ---------- */
.totales {
  display: grid;
  grid-template-columns: repeat(2, 1fr);
  gap: 8px;
  margin-bottom: 12px;
}
.chip {
  background: #eef4fb;
  border: 1px solid var(--color-borde);
  border-radius: 8px;
  padding: 8px 10px;
  display: flex;
  flex-direction: column;
}
.chip .num { font-weight: 800; color: var(--color-primario); font-size: 1.02rem; }
.chip .lbl { font-size: 0.78rem; color: var(--color-texto-suave); }

/* ---------- Tabla ---------- */
.tabla-scroll { overflow-x: auto; -webkit-overflow-scrolling: touch; }
table { width: 100%; border-collapse: collapse; font-size: 0.9rem; min-width: 720px; }
th, td {
  text-align: left;
  padding: 8px 10px;
  border-bottom: 1px solid var(--color-borde);
  white-space: nowrap;
}
th { background: #f4f7fb; font-size: 0.82rem; text-transform: uppercase; letter-spacing: 0.02em; }
tr.eliminado td { opacity: 0.5; text-decoration: line-through; }
td.acciones-celda { display: flex; gap: 6px; flex-wrap: wrap; }

/* ---------- Modal comprobante ---------- */
.modal {
  position: fixed;
  inset: 0;
  background: rgba(15, 23, 42, 0.6);
  display: flex;
  align-items: center;
  justify-content: center;
  padding: 14px;
  z-index: 50;
}
.modal[hidden] { display: none; }
.modal-contenido {
  background: #fff;
  border-radius: var(--radio);
  max-width: 800px;
  width: 100%;
  max-height: 90vh;
  overflow: auto;
  padding: 12px;
}
.modal-contenido header {
  display: flex;
  justify-content: space-between;
  align-items: center;
  margin-bottom: 8px;
}
#modal-cuerpo img, #modal-cuerpo iframe {
  max-width: 100%;
  max-height: 70vh;
  border: 1px solid var(--color-borde);
  border-radius: 8px;
  background: #fff;
}

/* ---------- Toast ---------- */
.toast {
  position: fixed;
  left: 50%;
  bottom: 18px;
  transform: translateX(-50%);
  background: #1c2430;
  color: #fff;
  padding: 10px 16px;
  border-radius: 999px;
  font-size: 0.9rem;
  box-shadow: var(--sombra);
  z-index: 60;
  max-width: 92vw;
}
.toast.exito { background: var(--color-acento); }
.toast.error { background: var(--color-peligro); }

/* ========================= Responsive (A-9) ========================= */
/* Tablet ≥ 768 px: formulario a 2 columnas y totales a 5 */
@media (min-width: 768px) {
  .grid { grid-template-columns: repeat(2, 1fr); }
  .totales { grid-template-columns: repeat(5, 1fr); }
  .contenido { padding: 20px; }
  .tarjeta { padding: 20px; }
}

/* Escritorio ≥ 1280 px: formulario a 3 columnas, tipografía mayor */
@media (min-width: 1280px) {
  body { font-size: 16.5px; }
  .grid { grid-template-columns: repeat(3, 1fr); }
  .contenido { max-width: 1160px; }
}

```

### `app/public/app.js`

```js
// ==========================================================================
// app.js — Lógica del frontend (vanilla JS, sin frameworks).
//
// SEGURIDAD (Fase B-6): NUNCA se usa innerHTML con datos de usuario; todo se
// inserta con createElement/textContent (los datos se muestran como texto,
// nunca se ejecutan). La CSP del servidor prohíbe scripts en línea.
// Interfaz para cada proceso: login, registro de venta, historial con
// filtros/totales, comprobantes protegidos, exportar Excel, auditoría, logout.
// ==========================================================================
'use strict';

// ---------- Utilidades ----------
const $ = (id) => document.getElementById(id);

let estado = { usuario: null, rol: null, csrf: null };

function mostrarToast(mensaje, tipo) {
  const t = $('toast');
  t.textContent = mensaje;            // textContent: seguro ante XSS
  t.className = 'toast ' + (tipo || '');
  t.hidden = false;
  clearTimeout(mostrarToast._t);
  mostrarToast._t = setTimeout(() => { t.hidden = true; }, 3500);
}

function formatoSol(n) {
  const valor = Number(n) || 0;
  return 'S/ ' + new Intl.NumberFormat('es-PE', { minimumFractionDigits: 2, maximumFractionDigits: 2 }).format(valor);
}

// Fecha de hoy en la zona horaria de Perú (America/Lima), formato AAAA-MM-DD
function hoyLima() {
  return new Date().toLocaleDateString('en-CA', { timeZone: 'America/Lima' });
}

function mesActualLima() {
  return hoyLima().slice(0, 7);
}

function leerCookie(nombre) {
  const lista = document.cookie ? document.cookie.split('; ') : [];
  for (const par of lista) {
    const i = par.indexOf('=');
    if (i > -1 && par.slice(0, i) === nombre) return decodeURIComponent(par.slice(i + 1));
  }
  return '';
}

// ---------- Cliente API (siempre envía CSRF en cambios; 401 → volver a login) ----------
async function api(ruta, opciones = {}) {
  const config = { headers: {}, credentials: 'same-origin', ...opciones };
  if (config.method && config.method !== 'GET') {
    config.headers['x-csrf-token'] = estado.csrf || leerCookie('csrf');
  }
  const respuesta = await fetch(ruta, config);

  if (respuesta.status === 401) {
    mostrarLogin('Tu sesión expiró. Inicia sesión de nuevo.');
    throw new Error('No autenticado');
  }

  const tipo = respuesta.headers.get('content-type') || '';
  const cuerpo = tipo.includes('application/json') ? await respuesta.json() : await respuesta.text();

  if (!respuesta.ok) {
    const mensaje = (cuerpo && cuerpo.error) || `Error ${respuesta.status}`;
    const err = new Error(mensaje);
    err.status = respuesta.status;
    err.errores = cuerpo && cuerpo.errores;
    throw err;
  }
  return cuerpo;
}

// ---------- Cambio de vistas ----------
function mostrarLogin(mensaje) {
  $('vista-app').hidden = true;
  $('vista-login').hidden = false;
  const e = $('login-error');
  if (mensaje) { e.textContent = mensaje; e.hidden = false; } else { e.hidden = true; }
  $('login-password').value = '';
}

function mostrarApp() {
  $('vista-login').hidden = true;
  $('vista-app').hidden = false;
  $('nombre-usuario').textContent = estado.usuario;
  const badge = $('badge-rol');
  badge.textContent = estado.rol === 'tesorero' ? 'Tesorero' : 'Consulta';
  badge.className = 'badge' + (estado.rol === 'consulta' ? ' consulta' : '');

  // Interfaces según el ROL (Fase B-1): consulta = solo lectura
  const esTesorero = estado.rol === 'tesorero';
  $('aviso-consulta').hidden = esTesorero;
  $('panel-registro').hidden = !esTesorero;
  $('filtro-eliminados-box').hidden = !esTesorero;
  $('panel-auditoria').hidden = !esTesorero;

  $('campo-fecha').value = hoyLima();
  $('filtro-mes').value = mesActualLima();
  cargarHistorial();
  if (esTesorero) cargarAuditoria();
}

// ---------- Proceso: Iniciar sesión ----------
$('form-login').addEventListener('submit', async (ev) => {
  ev.preventDefault();
  const btn = $('btn-login');
  btn.disabled = true;
  $('login-error').hidden = true;
  try {
    const r = await fetch('/api/login', {
      method: 'POST',
      credentials: 'same-origin',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        usuario: $('login-usuario').value.trim(),
        password: $('login-password').value,
      }),
    });
    const cuerpo = await r.json().catch(() => ({}));
    if (!r.ok) {
      $('login-error').textContent = cuerpo.error || 'No se pudo iniciar sesión.';
      $('login-error').hidden = false;
      return;
    }
    estado = { usuario: cuerpo.usuario.nombre, rol: cuerpo.usuario.rol, csrf: cuerpo.csrf };
    mostrarApp();
  } catch {
    $('login-error').textContent = 'Error de conexión con el servidor.';
    $('login-error').hidden = false;
  } finally {
    btn.disabled = false;
  }
});

// ---------- Proceso: Cerrar sesión ----------
$('btn-logout').addEventListener('click', async () => {
  try {
    await api('/api/logout', { method: 'POST' });
  } catch { /* la sesión ya no existe: se continúa */ }
  estado = { usuario: null, rol: null, csrf: null };
  mostrarLogin('Sesión cerrada correctamente.');
});

// ---------- Proceso: Registrar venta ----------
function metodoSeleccionado() {
  return document.querySelector('input[name="metodo"]:checked').value;
}

function actualizarPreview() {
  const entregados = parseInt($('campo-entregados').value, 10);
  const sobro = parseInt($('campo-sobro').value, 10);
  $('preview-vendidos').textContent =
    Number.isInteger(entregados) && Number.isInteger(sobro) ? String(entregados - sobro) : '–';

  const metodo = metodoSeleccionado();
  $('bloque-yape').hidden = !(metodo === 'yape' || metodo === 'mixto');
  const total = parseFloat($('campo-total').value);
  if (metodo === 'yape') {
    $('campo-yape').value = Number.isFinite(total) ? total.toFixed(2) : '';
    $('campo-yape').readOnly = true;   // Yape cubre todo: no editable
    $('preview-efectivo').textContent = 'S/ 0.00';
  } else if (metodo === 'mixto') {
    $('campo-yape').readOnly = false;
    const yape = parseFloat($('campo-yape').value);
    $('preview-efectivo').textContent =
      Number.isFinite(total) && Number.isFinite(yape) ? formatoSol(total - yape) : '–';
  }
}

['campo-entregados', 'campo-sobro', 'campo-total', 'campo-yape'].forEach((id) => {
  $(id).addEventListener('input', actualizarPreview);
});
document.querySelectorAll('input[name="metodo"]').forEach((r) => r.addEventListener('change', actualizarPreview));

$('campo-comprobante').addEventListener('change', () => {
  const f = $('campo-comprobante').files[0];
  const p = $('archivo-seleccionado');
  if (f) {
    p.textContent = `Archivo elegido: ${f.name} (${(f.size / 1024 / 1024).toFixed(2)} MB)`;
    p.hidden = false;
  } else {
    p.hidden = true;
  }
});

$('form-venta').addEventListener('submit', async (ev) => {
  ev.preventDefault();
  const btn = $('btn-guardar');
  $('error-form').hidden = true;
  $('exito-form').hidden = true;

  // Anti doble clic (Fase A-8): se deshabilita el botón durante el envío
  btn.disabled = true;
  btn.textContent = 'Guardando…';

  try {
    const fd = new FormData();
    fd.append('fecha', $('campo-fecha').value);
    fd.append('nombre', $('campo-nombre').value);
    fd.append('entregados', $('campo-entregados').value);
    fd.append('sobro', $('campo-sobro').value);
    fd.append('total', $('campo-total').value);
    fd.append('metodo_pago', metodoSeleccionado());
    if (metodoSeleccionado() === 'mixto') fd.append('yape_monto', $('campo-yape').value);
    const archivo = $('campo-comprobante').files[0];
    if (archivo) fd.append('comprobante', archivo, archivo.name);

    const r = await api('/api/registros', { method: 'POST', body: fd });
    $('exito-form').textContent = `Venta registrada (ID ${r.registro.id}).`;
    $('exito-form').hidden = false;
    mostrarToast('Venta guardada correctamente', 'exito');
    $('form-venta').reset();
    $('archivo-seleccionado').hidden = true;
    $('campo-fecha').value = hoyLima();
    actualizarPreview();
    cargarHistorial();
    cargarAuditoria();
  } catch (e) {
    if (e.status === 400 && e.errores) {
      const detalles = Object.values(e.errores).join(' ');
      $('error-form').textContent = detalles || e.message;
      $('error-form').hidden = false;
    } else {
      $('error-form').textContent = e.message;
      $('error-form').hidden = false;
      mostrarToast(e.message, 'error');
    }
  } finally {
    btn.disabled = false;
    btn.textContent = 'Guardar';
  }
});

// ---------- Proceso: Historial (filtros, totales, eliminar/restaurar) ----------
async function cargarHistorial() {
  const mes = $('filtro-mes').value || '';
  const q = $('filtro-q').value.trim();
  const eliminados = $('filtro-eliminados').checked ? '1' : '0';
  const params = new URLSearchParams();
  if (mes) params.set('mes', mes);
  if (q) params.set('q', q);
  if (eliminados === '1') params.set('eliminados', '1');

  let cuerpo;
  try {
    cuerpo = await api('/api/registros?' + params.toString());
  } catch (e) {
    if (e.message !== 'No autenticado') mostrarToast(e.message, 'error');
    return;
  }

  const { registros, totales } = cuerpo;
  $('tot-ventas').textContent = totales.ventas;
  $('tot-total').textContent = formatoSol(totales.total);
  $('tot-efectivo').textContent = formatoSol(totales.efectivo);
  $('tot-yape').textContent = formatoSol(totales.yape);
  const libros = registros.reduce((a, r) => a + (r.entregados - r.sobro), 0);
  $('tot-libros').textContent = libros;

  const tbody = $('cuerpo-tabla');
  tbody.textContent = '';               // limpiar sin innerHTML
  $('aviso-vacio').hidden = registros.length > 0;

  const esTesorero = estado.rol === 'tesorero';

  for (const r of registros) {
    const tr = document.createElement('tr');
    if (r.eliminado) tr.className = 'eliminado';

    const celdas = [
      r.fecha,
      r.nombre,
      r.entregados,
      r.sobro,
      r.entregados - r.sobro,
      formatoSol(r.total),
      r.metodo_pago === 'efectivo' ? 'Efectivo' : r.metodo_pago === 'yape' ? 'Yape' : 'Efectivo + Yape',
      r.comprobante ? 'Sí' : 'No',
    ];
    celdas.forEach((valor) => {
      const td = document.createElement('td');
      td.textContent = valor;           // B-6: texto plano, sin HTML
      tr.appendChild(td);
    });

    const tdAcc = document.createElement('td');
    tdAcc.className = 'acciones-celda';

    if (r.comprobante) {
      const btnVer = document.createElement('button');
      btnVer.type = 'button';
      btnVer.className = 'btn secundario chico';
      btnVer.textContent = 'Ver';
      btnVer.addEventListener('click', () => verComprobante(r.id, r.comprobante_nombre_original));
      tdAcc.appendChild(btnVer);
    }
    if (esTesorero && !r.eliminado) {
      const btnDel = document.createElement('button');
      btnDel.type = 'button';
      btnDel.className = 'btn peligro chico';
      btnDel.textContent = 'Eliminar';
      btnDel.addEventListener('click', () => eliminarRegistro(r.id, r.nombre));
      tdAcc.appendChild(btnDel);
    }
    if (esTesorero && r.eliminado) {
      const btnRes = document.createElement('button');
      btnRes.type = 'button';
      btnRes.className = 'btn secundario chico';
      btnRes.textContent = 'Restaurar';
      btnRes.addEventListener('click', () => restaurarRegistro(r.id));
      tdAcc.appendChild(btnRes);
    }
    tr.appendChild(tdAcc);
    tbody.appendChild(tr);
  }
}

$('btn-filtrar').addEventListener('click', cargarHistorial);
$('filtro-q').addEventListener('keydown', (e) => { if (e.key === 'Enter') cargarHistorial(); });
$('filtro-eliminados').addEventListener('change', cargarHistorial);

// ---------- Proceso: Exportar Excel del mes ----------
$('btn-exportar').addEventListener('click', () => {
  const mes = $('filtro-mes').value;
  if (!mes) {
    mostrarToast('Elige un mes para exportar', 'error');
    return;
  }
  // Descarga por GET del mismo origen: la cookie de sesión viaja sola
  window.location.href = `/api/exportar?mes=${encodeURIComponent(mes)}`;
  mostrarToast('Generando Excel de ' + mes, 'exito');
});

// ---------- Proceso: Eliminar / restaurar ----------
async function eliminarRegistro(id, nombre) {
  if (!window.confirm(`¿Eliminar la venta de "${nombre}"? Podrás restaurarla desde "Ver eliminados".`)) return;
  try {
    const r = await api(`/api/registros/${id}`, { method: 'DELETE' });
    mostrarToast(r.mensaje || 'Registro eliminado', 'exito');
    cargarHistorial();
    cargarAuditoria();
  } catch (e) {
    if (e.message !== 'No autenticado') mostrarToast(e.message, 'error');
  }
}

async function restaurarRegistro(id) {
  try {
    const r = await api(`/api/registros/${id}/restaurar`, { method: 'POST' });
    mostrarToast(r.mensaje || 'Registro restaurado', 'exito');
    cargarHistorial();
    cargarAuditoria();
  } catch (e) {
    if (e.message !== 'No autenticado') mostrarToast(e.message, 'error');
  }
}

// ---------- Proceso: Ver comprobante (privado, con sesión) ----------
async function verComprobante(id, nombreOriginal) {
  try {
    const respuesta = await fetch(`/api/comprobantes/${id}`, { credentials: 'same-origin' });
    if (!respuesta.ok) {
      const cuerpo = await respuesta.json().catch(() => ({}));
      mostrarToast(cuerpo.error || 'No se pudo abrir el comprobante', 'error');
      return;
    }
    const blob = await respuesta.blob();
    const url = URL.createObjectURL(blob);
    const cuerpo = $('modal-cuerpo');
    cuerpo.textContent = '';
    $('modal-titulo').textContent = 'Comprobante' + (nombreOriginal ? ` — ${nombreOriginal}` : '');
    if (blob.type === 'application/pdf') {
      const iframe = document.createElement('iframe');
      iframe.src = url;
      iframe.title = 'Comprobante PDF';
      iframe.width = '100%';
      iframe.height = '480';
      cuerpo.appendChild(iframe);
    } else {
      const img = document.createElement('img');
      img.src = url;
      img.alt = 'Comprobante de pago';
      cuerpo.appendChild(img);
    }
    $('modal-comprobante').hidden = false;
    $('btn-cerrar-modal').onclick = () => {
      $('modal-comprobante').hidden = true;
      cuerpo.textContent = '';
      URL.revokeObjectURL(url);
    };
  } catch {
    mostrarToast('Error al cargar el comprobante', 'error');
  }
}

$('modal-comprobante').addEventListener('click', (e) => {
  if (e.target === $('modal-comprobante')) $('btn-cerrar-modal').click();
});

// ---------- Proceso: Auditoría (solo tesorero) ----------
async function cargarAuditoria() {
  if (estado.rol !== 'tesorero') return;
  let cuerpo;
  try {
    cuerpo = await api('/api/auditoria');
  } catch { return; }
  const tbody = $('cuerpo-auditoria');
  tbody.textContent = '';
  for (const ev of cuerpo.eventos) {
    const tr = document.createElement('tr');
    [ev.fecha, ev.usuario || '—', ev.accion, ev.detalle || '—'].forEach((valor) => {
      const td = document.createElement('td');
      td.textContent = valor;
      tr.appendChild(td);
    });
    tbody.appendChild(tr);
  }
}

// ---------- Arranque: ¿hay sesión activa? ----------
(async function init() {
  try {
    const r = await fetch('/api/session', { credentials: 'same-origin' });
    if (r.ok) {
      const cuerpo = await r.json();
      estado = { usuario: cuerpo.usuario.nombre, rol: cuerpo.usuario.rol, csrf: cuerpo.csrf };
      mostrarApp();
      return;
    }
  } catch { /* servidor no disponible: se muestra login */ }
  mostrarLogin();
})();

```

### `scripts/backup.js`

```js
// scripts/backup.js
// --------------------------------------------------------------------------
// SEGURIDAD (Fase B-14): respaldo de la base de datos y de los comprobantes.
// Uso:  npm run backup
// Crea:  backups/respaldo-<fecha>/  con ventas.db (+WAL) y la carpeta uploads.
// Para CIFRAR el respaldo (recomendado), ver LEEME.md → "Respaldos cifrados"
// (ejemplos con age y GPG).
// --------------------------------------------------------------------------
'use strict';
const fs = require('fs');
const path = require('path');

const ROOT = path.join(__dirname, '..');
const DATA_DIR = process.env.DATA_DIR || path.join(ROOT, 'data');
const DB_PATH = process.env.DB_PATH || path.join(DATA_DIR, 'ventas.db');
const UPLOAD_DIR = process.env.UPLOAD_DIR || path.join(ROOT, 'uploads');
const BACKUP_DIR = process.env.BACKUP_DIR || path.join(ROOT, 'backups');

function principal() {
  if (!fs.existsSync(DB_PATH)) {
    console.error('ERROR: no existe la base de datos en ' + DB_PATH);
    process.exit(1);
  }

  // Checkpoint WAL para obtener una copia consistente en un solo archivo
  try {
    const Database = require('better-sqlite3');
    const d = new Database(DB_PATH);
    d.pragma('wal_checkpoint(TRUNCATE)');
    d.close();
  } catch (e) {
    console.warn('Aviso: no se pudo hacer checkpoint del WAL: ' + e.message);
  }

  const ts = new Date().toISOString().replace(/[:T]/g, '-').slice(0, 19);
  const destino = path.join(BACKUP_DIR, 'respaldo-' + ts);
  fs.mkdirSync(destino, { recursive: true });

  fs.copyFileSync(DB_PATH, path.join(destino, 'ventas.db'));
  if (fs.existsSync(DB_PATH + '-wal')) fs.copyFileSync(DB_PATH + '-wal', path.join(destino, 'ventas.db-wal'));
  if (fs.existsSync(UPLOAD_DIR)) fs.cpSync(UPLOAD_DIR, path.join(destino, 'uploads'), { recursive: true });

  console.log('Respaldo creado correctamente en: ' + destino);
  console.log('IMPORTANTE: cifra este respaldo antes de llevarlo a otro medio (ver LEEME.md).');
}

principal();

```

### `scripts/restore.js`

```js
// scripts/restore.js
// --------------------------------------------------------------------------
// SEGURIDAD (Fase B-14): restauración desde un respaldo creado por backup.js.
// Uso:  node scripts/restore.js backups/respaldo-<fecha>  [--si]
//   --si  confirma la sobrescritura (sin preguntar)
// Detiene la aplicación antes de restaurar. Copia ventas.db (+WAL) y uploads.
// --------------------------------------------------------------------------
'use strict';
const fs = require('fs');
const path = require('path');
const readline = require('readline');

const ROOT = path.join(__dirname, '..');
const DATA_DIR = process.env.DATA_DIR || path.join(DATA_DIR_OF('data'));
function DATA_DIR_OF(x) { return path.join(ROOT, x); }
const DB_PATH = process.env.DB_PATH || path.join(DATA_DIR, 'ventas.db');
const UPLOAD_DIR = process.env.UPLOAD_DIR || path.join(ROOT, 'uploads');

async function principal() {
  const args = process.argv.slice(2);
  const origen = args[0];
  const confirmado = args.includes('--si');

  if (!origen || !fs.existsSync(origen)) {
    console.error('ERROR: indica una carpeta de respaldo válida.');
    console.error('Ejemplo: node scripts/restore.js backups/respaldo-2026-01-15-10-30-00 --si');
    process.exit(1);
  }
  const dbRespaldo = path.join(origen, 'ventas.db');
  if (!fs.existsSync(dbRespaldo)) {
    console.error('ERROR: la carpeta indicada no contiene ventas.db');
    process.exit(1);
  }

  if (!confirmado) {
    const rl = readline.createInterface({ input: process.stdin, output: process.stdout });
    const resp = await new Promise((res) => rl.question('Esto SOBREESCRIBIRÁ la base actual y los comprobantes. ¿Continuar? (escribe "si"): ', res));
    rl.close();
    if (resp.trim().toLowerCase() !== 'si') {
      console.log('Cancelado. No se modificó nada.');
      process.exit(0);
    }
  }

  fs.mkdirSync(path.dirname(DB_PATH), { recursive: true });
  fs.copyFileSync(dbRespaldo, DB_PATH);
  if (fs.existsSync(dbRespaldo + '-wal')) fs.copyFileSync(dbRespaldo + '-wal', DB_PATH + '-wal');
  else if (fs.existsSync(DB_PATH + '-wal')) fs.rmSync(DB_PATH + '-wal');

  const uploadsRespaldo = path.join(origen, 'uploads');
  if (fs.existsSync(uploadsRespaldo)) {
    fs.rmSync(UPLOAD_DIR, { recursive: true, force: true });
    fs.cpSync(uploadsRespaldo, UPLOAD_DIR, { recursive: true });
  }

  console.log('Restauración completada desde: ' + origen);
  console.log('Vuelve a iniciar la aplicación con: npm start');
}

principal().catch((e) => { console.error('ERROR: ' + e.message); process.exit(1); });

```

### `scripts/purgar.js`

```js
// scripts/purgar.js
// --------------------------------------------------------------------------
// Fase B-15: los registros se eliminan de forma LÓGICA (recuperables).
// Este script purga físicamente los eliminados hace más de DIAS_PURGA días
// (30 por defecto) y borra también sus comprobantes.
// Uso: node scripts/purgar.js [--si]   (detén la app antes de purgar)
// --------------------------------------------------------------------------
'use strict';
const fs = require('fs');
const path = require('path');

const ROOT = path.join(__dirname, '..');
const DATA_DIR = process.env.DATA_DIR || path.join(ROOT, 'data');
const DB_PATH = process.env.DB_PATH || path.join(DATA_DIR, 'ventas.db');
const UPLOAD_DIR = process.env.UPLOAD_DIR || path.join(ROOT, 'uploads');
const DIAS = parseInt(process.env.DIAS_PURGA || '30', 10);

function principal() {
  const confirmado = process.argv.includes('--si');
  if (!fs.existsSync(DB_PATH)) { console.error('ERROR: no existe la base de datos.'); process.exit(1); }
  if (!confirmado) {
    console.log('Esto eliminará FÍSICAMENTE los registros con borrado lógico de más de ' + DIAS + ' días.');
    console.log('Ejecuta de nuevo con --si para confirmar.');
    process.exit(0);
  }

  const Database = require('better-sqlite3');
  const db = new Database(DB_PATH);
  db.pragma('busy_timeout = 5000');

  const limite = new Date(Date.now() - DIAS * 24 * 3600 * 1000).toISOString().slice(0, 19).replace('T', ' ');
  const filas = db.prepare("SELECT id, comprobante FROM registros WHERE eliminado = 1 AND eliminado_en IS NOT NULL AND eliminado_en <= ?").all(limite);

  let archivosBorrados = 0;
  const borrar = db.transaction(() => {
    for (const f of filas) {
      if (f.comprobante) {
        const ruta = path.join(UPLOAD_DIR, f.comprobante);
        if (ruta.startsWith(UPLOAD_DIR + path.sep) && fs.existsSync(ruta)) {
          fs.unlinkSync(ruta);
          archivosBorrados++;
        }
      }
      db.prepare('DELETE FROM registros WHERE id = ?').run(f.id);
    }
  });
  borrar();
  db.close();

  console.log(`Purga completada: ${filas.length} registro(s) eliminado(s) físicamente, ${archivosBorrados} comprobante(s) borrado(s).`);
}

principal();

```

### `scripts/prueba_reinicio.js`

```js
// scripts/prueba_reinicio.js
// --------------------------------------------------------------------------
// Fase A-10: prueba REAL de persistencia y carpetas faltantes.
//  1) Levanta el servidor con una base temporal.
//  2) Registra una venta.
//  3) Detiene el servidor (SIGTERM) y BORRA la carpeta uploads/.
//  4) Vuelve a levantarlo y comprueba: la venta sigue ahí y la carpeta
//     uploads/ se recreó sola.
// Salida: líneas [PASS]/[FAIL] (se guardan en evidencia/).
// --------------------------------------------------------------------------
'use strict';
const { spawn, spawnSync } = require('child_process');
const fs = require('fs');
const path = require('path');

const ROOT = path.join(__dirname, '..');
const PUERTO = 3199;
const TMP = path.join(ROOT, '.evidencia-tmp');
const DB = path.join(TMP, 'ventas.db');
const UPLOADS = path.join(TMP, 'uploads');
const BASE = `http://127.0.0.1:${PUERTO}`;

let servidor = null;
let cookies = '';
let csrf = '';

function esperar(ms) { return new Promise((r) => setTimeout(r, ms)); }

function levantar() {
  servidor = spawn(process.execPath, [path.join(ROOT, 'app', 'server.js')], {
    env: {
      ...process.env,
      PORT: String(PUERTO),
      DB_PATH: DB,
      UPLOAD_DIR: UPLOADS,
      ADMIN_USER: 'admin',
      ADMIN_PASSWORD: 'ClaveReinicio2026!',
      API_LIMIT_MAX: '100000',
      NODE_ENV: 'development',
    },
    stdio: ['ignore', 'pipe', 'pipe'],
  });
  let salida = '';
  servidor.stdout.on('data', (d) => { salida += d; });
  servidor.stderr.on('data', (d) => { salida += d; });
  servidor.salida = () => salida;
  return servidor;
}

async function listarPuerto() {
  for (let i = 0; i < 60; i++) {
    try {
      const r = await fetch(BASE + '/api/session');
      if (r.status === 401 || r.status === 200) return true;
    } catch { /* aún no responde */ }
    await esperar(250);
  }
  return false;
}

async function login() {
  const r = await fetch(BASE + '/api/login', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ usuario: 'admin', password: 'ClaveReinicio2026!' }),
  });
  const cuerpo = await r.json();
  cookies = r.headers.getSetCookie().map((c) => c.split(';')[0]).join('; ');
  csrf = cuerpo.csrf;
  return r.status;
}

async function registrar(fecha, nombre, entregados, sobro, total, metodo) {
  const r = await fetch(BASE + '/api/registros', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json', Cookie: cookies, 'x-csrf-token': csrf },
    body: JSON.stringify({ fecha, nombre, entregados, sobro, total, metodo_pago: metodo }),
  });
  return { status: r.status, cuerpo: await r.json() };
}

function detener() {
  if (!servidor) return Promise.resolve();
  return new Promise((resolve) => {
    servidor.once('exit', () => resolve());
    servidor.kill('SIGTERM');
    setTimeout(() => { try { servidor.kill('SIGKILL'); } catch { /* nada */ } resolve(); }, 3000);
  });
}

let fallos = 0;
function chequear(nombre, condicion, extra) {
  console.log(`[${condicion ? 'PASS' : 'FAIL'}] ${nombre}${extra ? ' — ' + extra : ''}`);
  if (!condicion) fallos++;
}

(async () => {
  spawnSync('rm', ['-rf', TMP]);
  fs.mkdirSync(TMP, { recursive: true });

  // --- Fase 1: arrancar y registrar ---
  levantar();
  chequear('Servidor #1 responde', await listarPuerto());
  chequear('Login del tesorero', (await login()) === 200);
  const venta = await registrar('2026-01-15', 'Prueba de Reinicio', 10, 3, 25.5, 'efectivo');
  chequear('Venta registrada', venta.status === 201, `id=${venta.cuerpo && venta.cuerpo.registro ? venta.cuerpo.registro.id : '?'}`);
  const idVenta = venta.cuerpo.registro.id;

  // --- Fase 2: reinicio + borrar uploads ---
  await detener();
  fs.rmSync(UPLOADS, { recursive: true, force: true });
  chequear('Servidor detenido y carpeta uploads/ borrada', !fs.existsSync(UPLOADS));

  // --- Fase 3: arrancar de nuevo y verificar ---
  levantar();
  chequear('Servidor #2 responde tras reinicio', await listarPuerto());
  chequear('Carpeta uploads/ recreada automáticamente por el servidor', fs.existsSync(UPLOADS));
  chequear('Login tras reinicio', (await login()) === 200);

  const r2 = await fetch(BASE + '/api/registros?mes=2026-01', { headers: { Cookie: cookies } });
  const c2 = await r2.json();
  const encontrado = (c2.registros || []).some((x) => x.id === idVenta && x.nombre === 'Prueba de Reinicio');
  chequear('La venta PERSISTE después de reiniciar (SQLite)', encontrado);

  await detener();
  spawnSync('rm', ['-rf', TMP]);
  console.log(fallos === 0 ? 'RESULTADO: TODAS LAS PRUEBAS DE REINICIO PASARON' : `RESULTADO: ${fallos} PRUEBA(S) FALLARON`);
  process.exit(fallos === 0 ? 0 : 1);
})().catch((e) => { console.error('ERROR INESPERADO:', e); process.exit(1); });

```

### `scripts/prueba_bloqueo.js`

```js
// scripts/prueba_bloqueo.js
// --------------------------------------------------------------------------
// Fase A-10: prueba REAL ante "database is locked".
//  1) Levanta el servidor con una base temporal.
//  2) Otra conexión SQLite toma un bloqueo exclusivo (BEGIN EXCLUSIVE).
//  3a) Se libera a los 2 s (< busy_timeout de 5 s)  → la venta se registra.
//  3b) Se retiene 8 s (> 5 s)                       → el servidor responde 503
//      con un mensaje amable (no se cae, no filtra detalles internos).
// --------------------------------------------------------------------------
'use strict';
const { spawn, spawnSync } = require('child_process');
const fs = require('fs');
const path = require('path');

const ROOT = path.join(__dirname, '..');
const PUERTO = 3198;
const TMP = path.join(ROOT, '.evidencia-tmp-bloqueo');
const DB = path.join(TMP, 'ventas.db');
const BASE = `http://127.0.0.1:${PUERTO}`;

let servidor = null;
let cookies = '';
let csrf = '';
let fallos = 0;

function esperar(ms) { return new Promise((r) => setTimeout(r, ms)); }

function levantar() {
  servidor = spawn(process.execPath, [path.join(ROOT, 'app', 'server.js')], {
    env: {
      ...process.env, PORT: String(PUERTO), DB_PATH: DB,
      UPLOAD_DIR: path.join(TMP, 'uploads'),
      ADMIN_USER: 'admin', ADMIN_PASSWORD: 'ClaveBloqueo2026!',
      API_LIMIT_MAX: '100000', NODE_ENV: 'development',
    },
    stdio: ['ignore', 'pipe', 'pipe'],
  });
}

async function esperarPuerto() {
  for (let i = 0; i < 60; i++) {
    try {
      const r = await fetch(BASE + '/api/session');
      if (r.status === 401 || r.status === 200) return true;
    } catch { /* no listo */ }
    await esperar(250);
  }
  return false;
}

async function login() {
  const r = await fetch(BASE + '/api/login', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ usuario: 'admin', password: 'ClaveBloqueo2026!' }),
  });
  cookies = r.headers.getSetCookie().map((c) => c.split(';')[0]).join('; ');
  csrf = (await r.json()).csrf;
}

function registrar(nombre) {
  return fetch(BASE + '/api/registros', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json', Cookie: cookies, 'x-csrf-token': csrf },
    body: JSON.stringify({ fecha: '2026-02-01', nombre, entregados: 5, sobro: 1, total: 40, metodo_pago: 'efectivo' }),
  }).then(async (r) => ({ status: r.status, cuerpo: await r.json() }));
}

function chequear(nombre, condicion, extra) {
  console.log(`[${condicion ? 'PASS' : 'FAIL'}] ${nombre}${extra ? ' — ' + extra : ''}`);
  if (!condicion) fallos++;
}

(async () => {
  spawnSync('rm', ['-rf', TMP]);
  fs.mkdirSync(TMP, { recursive: true });

  levantar();
  chequear('Servidor responde', await esperarPuerto());
  await login();
  const sinBloqueo = await registrar('Venta sin bloqueo');
  chequear('Venta normal se registra', sinBloqueo.status === 201);

  const Database = require('better-sqlite3');
  const otra = new Database(DB);
  otra.pragma('busy_timeout = 100');

  // Caso A: bloqueo breve (2 s) → el servidor ESPERA y registra igual
  otra.exec('BEGIN EXCLUSIVE');
  const t0 = Date.now();
  setTimeout(() => { try { otra.exec('COMMIT'); } catch { /* nada */ } }, 2000);
  const casoA = await registrar('Venta con bloqueo breve');
  chequear('Con bloqueo de 2 s: espera y registra (busy_timeout)', casoA.status === 201, `${Date.now() - t0} ms`);

  // Caso B: bloqueo largo (8 s) → supera busy_timeout → 503 con mensaje claro
  otra.exec('BEGIN EXCLUSIVE');
  const t1 = Date.now();
  setTimeout(() => { try { otra.exec('COMMIT'); } catch { /* nada */ } }, 8000);
  const casoB = await registrar('Venta con bloqueo largo');
  chequear('Con bloqueo de 8 s: responde 503 sin caerse', casoB.status === 503, `${Date.now() - t1} ms`);
  chequear('Mensaje amable para el usuario', casoB.status === 503 && /ocupada/i.test(casoB.cuerpo.error || ''), casoB.cuerpo.error);

  otra.close();
  try { servidor.kill('SIGTERM'); } catch { /* nada */ }
  spawnSync('rm', ['-rf', TMP]);
  console.log(fallos === 0 ? 'RESULTADO: TODAS LAS PRUEBAS DE BLOQUEO PASARON' : `RESULTADO: ${fallos} PRUEBA(S) FALLARON`);
  process.exit(fallos === 0 ? 0 : 1);
})().catch((e) => { console.error('ERROR INESPERADO:', e); process.exit(1); });

```

### `scripts/evidencia_curl.sh`

```bash
#!/usr/bin/env bash
# scripts/evidencia_curl.sh
# --------------------------------------------------------------------------
# Reproduce las pruebas MANUALES de seguridad con curl contra un servidor
# en marcha y guarda la salida real en evidencia/.
# Uso:  bash scripts/evidencia_curl.sh http://127.0.0.1:3100
# (levantar antes:  PORT=3100 ... npm start  — ver LEEME.md)
# --------------------------------------------------------------------------
set -u
BASE="${1:-http://127.0.0.1:3100}"
DIR="$(cd "$(dirname "$0")/.." && pwd)"
EV="$DIR/evidencia"
JAR="$(mktemp -d)"
CSRF=""

paso() { echo; echo "## $*"; }

mkdir -p "$EV"

# ---------- 02: acceso y cookies ----------
paso "GET /api/registros SIN sesión (debe ser 401)"
curl -s -i "$BASE/api/registros" | head -n 1
curl -s "$BASE/api/registros" | head -c 200; echo
{ echo "\$ curl -i http://127.0.0.1:3100/api/registros   (sin cookie)"; curl -s -i "$BASE/api/registros"; } > "$EV/02_acceso_sin_sesion.txt" 2>&1

paso "Login con contraseña INCORRECTA (401)"
curl -s -i -X POST "$BASE/api/login" -H 'Content-Type: application/json' \
  -d '{"usuario":"tesorero","password":"clave-mala-123"}' | head -n 1

paso "Login CORRECTO (200) — ver cookies Set-Cookie"
{ echo "\$ curl -i -X POST $BASE/api/login -H 'Content-Type: application/json' -d '{...}'"; \
  curl -s -i -X POST "$BASE/api/login" -H 'Content-Type: application/json' \
  -c "$JAR/cookies.txt" -d '{"usuario":"tesorero","password":"DemoTesorero2026!"}'; } > "$EV/02_login_y_cookies.txt" 2>&1
curl -s -c "$JAR/cookies.txt" -X POST "$BASE/api/login" -H 'Content-Type: application/json' \
  -d '{"usuario":"tesorero","password":"DemoTesorero2026!"}' > "$JAR/login.json"
CSRF="$(node -e "process.stdout.write(JSON.parse(require('fs').readFileSync('$JAR/login.json','utf8')).csrf||'')" 2>/dev/null || python3 -c "import json;print(json.load(open('$JAR/login.json'))['csrf'])")"
echo "CSRF obtenido: ${CSRF:0:12}… (ver evidencia/02_login_y_cookies.txt)"
echo "--- Set-Cookie (resumen) ---"
grep -i 'set-cookie' "$EV/02_login_y_cookies.txt" | head -n 2

paso "GET /api/session con cookie (200)"
curl -s "$BASE/api/session" -b "$JAR/cookies.txt"; echo

# ---------- 03: CSRF ----------
paso "POST /api/registros SIN cabecera x-csrf-token (debe ser 403)"
{ echo "\$ curl -i -X POST $BASE/api/registros -b cookies (SIN x-csrf-token)"; \
  curl -s -i -X POST "$BASE/api/registros" -b "$JAR/cookies.txt" \
    -H 'Content-Type: application/json' \
    -d '{"fecha":"2026-11-01","nombre":"Sin CSRF","entregados":1,"sobro":0,"total":10,"metodo_pago":"efectivo"}'; } > "$EV/03_csrf_rechazado.txt" 2>&1
head -n 1 "$EV/03_csrf_rechazado.txt"

paso "POST /api/registros CON CSRF (201) — pago mixto, efectivo se calcula solo"
curl -s -X POST "$BASE/api/registros" -b "$JAR/cookies.txt" -H "x-csrf-token: $CSRF" \
  -H 'Content-Type: application/json' \
  -d '{"fecha":"2026-11-01","nombre":"Rosa Quispe","entregados":12,"sobro":3,"total":45.5,"metodo_pago":"mixto","yape_monto":25}'; echo

paso "Datos ilegales: sobro>entregados, total negativo, nombre con solo espacios (400)"
curl -s -X POST "$BASE/api/registros" -b "$JAR/cookies.txt" -H "x-csrf-token: $CSRF" \
  -H 'Content-Type: application/json' \
  -d '{"fecha":"2026-02-31","nombre":"   ","entregados":-5,"sobro":9,"total":-3,"metodo_pago":"mixto","yape_monto":999}'; echo

# ---------- 04: SQLi ----------
paso "SQLi en búsqueda (q) — nada se ejecuta, devuelve listas vacías"
{ for Q in "' OR '1'='1" "'; DROP TABLE registros;--" "' UNION SELECT 1,2,3,4,5,6,7,8,9,10,11,12,13,14--"; do
    echo "\$ q=$(printf '%s' "$Q")"
    curl -s -G "$BASE/api/registros" --data-urlencode "q=$Q" -b "$JAR/cookies.txt" | head -c 220; echo; echo
  done
  echo "\$ mes=2026-01'--"
  curl -s -G "$BASE/api/registros" --data-urlencode "mes=2026-01'--" -b "$JAR/cookies.txt"; echo
} > "$EV/04_sqli.txt" 2>&1
cat "$EV/04_sqli.txt"

paso "SQLi en login (parametrizado) — 401"
curl -s -X POST "$BASE/api/login" -H 'Content-Type: application/json' \
  -d "{\"usuario\":\"' OR '1'='1' --\",\"password\":\"x\"}"; echo

# ---------- 05: XSS + cabeceras ----------
paso "XSS almacenado: nombre con <script> se guarda como TEXTO"
curl -s -X POST "$BASE/api/registros" -b "$JAR/cookies.txt" -H "x-csrf-token: $CSRF" \
  -H 'Content-Type: application/json' \
  -d '{"fecha":"2026-11-02","nombre":"<script>alert(1)</script><img src=x onerror=alert(1)>","entregados":1,"sobro":0,"total":9,"metodo_pago":"efectivo"}' | head -c 300; echo
{ echo "\$ Búsqueda del payload XSS — se devuelve como TEXTO (JSON), nunca se ejecuta:"; \
  curl -s -G "$BASE/api/registros" --data-urlencode "q=<script>" -b "$JAR/cookies.txt" | head -c 400; echo; \
  echo; echo "\$ Cabeceras de seguridad de GET /:"; \
  curl -s -I "$BASE/" | grep -Ei 'content-security|x-content-type|x-frame|referrer-policy|x-powered|strict-transport|cross-origin'; } > "$EV/05_xss_y_cabeceras.txt" 2>&1

# ---------- 06: uploads ----------
paso "Upload de un .exe renombrado a .jpg (magic bytes) → 400"
printf 'MZ\x90\x00AAAAABB' > "$JAR/falso.jpg"
curl -s -X POST "$BASE/api/registros" -b "$JAR/cookies.txt" -H "x-csrf-token: $CSRF" \
  -F "fecha=2026-11-03" -F "nombre=Trampa Exe" -F "entregados=1" -F "sobro=0" \
  -F "total=9" -F "metodo_pago=yape" -F "comprobante=@$JAR/falso.jpg;type=image/jpeg" ; echo

paso "Upload de PNG real → 201 con nombre generado por el servidor"
printf 'iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAYAAAAfFcSJAAAADUlEQVR42mP8z8BQDwAEhQGAhKmMIQAAAABJRU5ErkJggg==' | base64 -d > "$JAR/real.png"
RESP_UP="$(curl -s -X POST "$BASE/api/registros" -b "$JAR/cookies.txt" -H "x-csrf-token: $CSRF" \
  -F "fecha=2026-11-03" -F "nombre=Comprobante Real" -F "entregados=4" -F "sobro=1" \
  -F "total=18.9" -F "metodo_pago=yape" -F "comprobante=@$JAR/real.png;type=image/png")"
echo "$RESP_UP" | head -c 400; echo
ARCHIVO="$(node -e "try{process.stdout.write(JSON.parse(process.argv[1]).registro.comprobante||'')}catch(e){}" "$RESP_UP")"
ID_REG="$(node -e "try{process.stdout.write(String(JSON.parse(process.argv[1]).registro.id))}catch(e){}" "$RESP_UP")"

paso "El archivo NO es accesible como estático (uploads/ privado) → 404"
curl -s -o /dev/null -w "GET /uploads/$ARCHIVO  ->  %{http_code}\n" "$BASE/uploads/$ARCHIVO"

paso "Ver el comprobante REQUIERE sesión: sin cookie 401, con cookie 200"
curl -s -o /dev/null -w "sin cookie  -> %{http_code}\n" "$BASE/api/comprobantes/$ID_REG"
curl -s -o /dev/null -w "con cookie  -> %{http_code}  content-type: %{content_type}\n" "$BASE/api/comprobantes/$ID_REG" -b "$JAR/cookies.txt"
{ echo "## Resumen de la prueba de comprobantes privados"; \
  echo "GET /uploads/$ARCHIVO sin sesión -> $(curl -s -o /dev/null -w '%{http_code}' "$BASE/uploads/$ARCHIVO")"; \
  echo "GET /api/comprobantes/$ID_REG sin cookie -> $(curl -s -o /dev/null -w '%{http_code}' "$BASE/api/comprobantes/$ID_REG")"; \
  echo "GET /api/comprobantes/$ID_REG con cookie -> $(curl -s -o /dev/null -w '%{http_code} %{content_type}' "$BASE/api/comprobantes/$ID_REG" -b "$JAR/cookies.txt")"; \
  echo; echo "## Upload de .exe disfrazado de .jpg (rechazado por magic bytes)"; \
  curl -s -X POST "$BASE/api/registros" -b "$JAR/cookies.txt" -H "x-csrf-token: $CSRF" \
    -F "fecha=2026-11-03" -F "nombre=Trampa Exe" -F "entregados=1" -F "sobro=0" \
    -F "total=9" -F "metodo_pago=yape" -F "comprobante=@$JAR/falso.jpg;type=image/jpeg"; echo; } > "$EV/06_comprobantes_y_uploads.txt" 2>&1

# ---------- 07: exportar Excel + anti-fórmulas ----------
paso "Insertar nombre malicioso =HIPERVINCULO(...) y exportar el mes"
curl -s -X POST "$BASE/api/registros" -b "$JAR/cookies.txt" -H "x-csrf-token: $CSRF" \
  -H 'Content-Type: application/json' \
  -d '{"fecha":"2026-11-04","nombre":"=HIPERVINCULO(\"http://evil.com\";\"clic\")","entregados":2,"sobro":0,"total":12,"metodo_pago":"efectivo"}' | head -c 200; echo
curl -s -G "$BASE/api/exportar" --data-urlencode "mes=2026-11" -b "$JAR/cookies.txt" -o "$JAR/ventas-2026-11.xlsx"
{ echo "## Cell dentro del .xlsx (xl/sharedStrings.xml): debe empezar con apóstrofe"; \
  unzip -p "$JAR/ventas-2026-11.xlsx" xl/sharedStrings.xml | grep -o "['-=+@][^<]*HIPERVINCULO[^<]*" | head -n 3; \
  echo; echo "## Archivo exportado:"; ls -la "$JAR/ventas-2026-11.xlsx"; } > "$EV/07_export_anti_formulas.txt" 2>&1
cat "$EV/07_export_anti_formulas.txt"

# ---------- 08: auditoría ----------
{ echo "## GET /api/auditoria (solo tesorero) — últimos eventos reales"; \
  curl -s "$BASE/api/auditoria" -b "$JAR/cookies.txt" | head -c 1500; echo; } > "$EV/08_auditoria.txt" 2>&1

echo
echo "Listo. Evidencia en: $EV"
rm -rf "$JAR"

```

### `tests/setup.env.js`

```js
// tests/setup.env.js — entorno aislado por archivo de prueba (BD temporal)
const os = require('os');
const path = require('path');
const fs = require('fs');

const dir = fs.mkdtempSync(path.join(os.tmpdir(), 'vl-test-'));
process.env.DB_PATH = path.join(dir, 'ventas.db');
process.env.UPLOAD_DIR = path.join(dir, 'uploads');
process.env.ADMIN_USER = 'admin-test';
process.env.ADMIN_PASSWORD = 'ClaveTesorero2026!';
process.env.CONSULTA_USER = 'consulta-test';
process.env.CONSULTA_PASSWORD = 'ClaveConsulta2026!';
process.env.API_LIMIT_MAX = '5000';   // alto para no interferir con las pruebas
process.env.LOGIN_LIMIT_MAX = '5';
process.env.LOCKOUT_MAX = '5';
process.env.NODE_ENV = 'test';

```

### `tests/helpers.js`

```js
// tests/helpers.js — utilidades comunes de la suite
'use strict';
const request = require('supertest');
const { app } = require('../app/server');
const { db } = require('../app/db');

const ADMIN = { usuario: process.env.ADMIN_USER, password: process.env.ADMIN_PASSWORD };
const CONSULTA = { usuario: process.env.CONSULTA_USER, password: process.env.CONSULTA_PASSWORD };

function extraerCookies(respuesta) {
  return (respuesta.headers['set-cookie'] || []).map((c) => c.split(';')[0]).join('; ');
}

async function login(usuario, password) {
  const r = await request(app).post('/api/login').send({ usuario, password });
  if (r.status !== 200) throw new Error(`login falló (${r.status}): ${JSON.stringify(r.body)}`);
  return { cookies: extraerCookies(r), csrf: r.body.csrf };
}

async function comoTesorero() { return login(ADMIN.usuario, ADMIN.password); }
async function comoConsulta() { return login(CONSULTA.usuario, CONSULTA.password); }

// Crear registro vía API (multipart si hay archivo, JSON si no)
async function crearRegistro(sesion, campos, archivo) {
  const r = request(app).post('/api/registros')
    .set('Cookie', sesion.cookies)
    .set('x-csrf-token', sesion.csrf);
  if (archivo) {
    r.attach('comprobante', archivo.buffer, { filename: archivo.nombre, contentType: archivo.tipo });
  }
  for (const [k, v] of Object.entries(campos)) r.field(k, String(v));
  return r;
}

// Insertar directamente en la BD (útil para datos masivos)
function insertarDirecto(campos) {
  return db.prepare(`
    INSERT INTO registros (fecha, nombre, entregados, sobro, total, metodo_pago, yape_monto, efectivo_monto, creado_por)
    VALUES (?, ?, ?, ?, ?, ?, ?, ?, 'prueba')`)
    .run(campos.fecha, campos.nombre, campos.entregados, campos.sobro,
      campos.total, campos.metodo_pago, campos.yape_monto || 0, campos.efectivo_monto || campos.total).lastInsertRowid;
}

// Descargar un archivo binario (xlsx) y devolver el Buffer real
function descargar(ruta, cookies) {
  return request(app).get(ruta).set('Cookie', cookies).buffer(true)
    .parse((res, cb) => {
      const trozos = [];
      res.on('data', (c) => trozos.push(c));
      res.on('end', () => cb(null, Buffer.concat(trozos)));
    });
}

// Buffers mínimos válidos para pruebas de magic bytes
function pngValido() {
  return Buffer.from('iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAYAAAAfFcSJAAAADUlEQVR42mP8z8BQDwAEhQGAhKmMIQAAAABJRU5ErkJggg==', 'base64');
}
function pdfValido() { return Buffer.from('%PDF-1.4\n1 0 obj\n%%EOF\n'); }
function webpValido() { return Buffer.concat([Buffer.from('RIFF'), Buffer.from([0x24, 0x00, 0x00, 0x00]), Buffer.from('WEBPVP8 '), Buffer.alloc(16, 1)]); }
function jpegValido() { return Buffer.concat([Buffer.from([0xFF, 0xD8, 0xFF, 0xE0]), Buffer.alloc(64, 0x7F)]); }
function falsoJpg() { return Buffer.concat([Buffer.from('MZ\x90\x00'), Buffer.alloc(32, 0x41)]); } // un .exe renombrado

const VENTA_BASE = { fecha: '2026-01-15', nombre: 'Rosa Quispe', entregados: 10, sobro: 3, total: 50, metodo_pago: 'efectivo' };

afterAll(() => { try { db.close(); } catch { /* ya cerrada */ } });

module.exports = {
  app, db, request, ADMIN, CONSULTA,
  login, comoTesorero, comoConsulta, extraerCookies,
  crearRegistro, insertarDirecto, descargar,
  pngValido, pdfValido, webpValido, jpegValido, falsoJpg,
  VENTA_BASE,
};

```

### `tests/qa_calculos.test.js`

```js
// tests/qa_calculos.test.js
// Fase A-1 (tres métodos de pago) y A-2 (cálculos: vendidos, efectivo, totales del mes, Excel)
'use strict';
const { app, request, comoTesorero, crearRegistro, descargar } = require('./helpers');

let sesion;

beforeAll(async () => { sesion = await comoTesorero(); });

describe('Fase A-1: los tres métodos de pago se registran', () => {
  test('pago solo EFECTIVO', async () => {
    const r = await crearRegistro(sesion, { fecha: '2026-01-10', nombre: 'Ana Paredes', entregados: 10, sobro: 2, total: 40, metodo_pago: 'efectivo' });
    expect(r.status).toBe(201);
    expect(r.body.registro.yape_monto).toBe(0);
    expect(r.body.registro.efectivo_monto).toBe(40);
  });

  test('pago solo YAPE', async () => {
    const r = await crearRegistro(sesion, { fecha: '2026-01-11', nombre: 'Beto Ríos', entregados: 8, sobro: 0, total: 32, metodo_pago: 'yape' });
    expect(r.status).toBe(201);
    expect(r.body.registro.yape_monto).toBe(32);
    expect(r.body.registro.efectivo_monto).toBe(0);
  });

  test('pago MIXTO: efectivo = total − yape (automático)', async () => {
    const r = await crearRegistro(sesion, { fecha: '2026-01-12', nombre: 'Carla Díaz', entregados: 6, sobro: 1, total: 25, metodo_pago: 'mixto', yape_monto: 10 });
    expect(r.status).toBe(201);
    expect(r.body.registro.yape_monto).toBe(10);
    expect(r.body.registro.efectivo_monto).toBe(15); // 25 − 10
  });
});

describe('Fase A-2: cálculos y totales del mes', () => {
  test('vendidos = entregados − sobró se guarda correctamente', async () => {
    const r = await crearRegistro(sesion, { fecha: '2026-01-20', nombre: 'Daniel Soto', entregados: 30, sobro: 7, total: 92, metodo_pago: 'efectivo' });
    expect(r.status).toBe(201);
    expect(r.body.registro.entregados - r.body.registro.sobro).toBe(23);
  });

  test('los totales del mes suman ventas, efectivo y yape', async () => {
    const r = await request(app).get('/api/registros?mes=2026-01').set('Cookie', sesion.cookies);
    expect(r.status).toBe(200);
    // Ana 40 + Beto 32 + Carla 25 + Daniel 92 = 189 ; yape = 10+32 = 42
    expect(r.body.totales.total).toBeCloseTo(189, 2);
    expect(r.body.totales.yape).toBeCloseTo(42, 2);
    expect(r.body.totales.efectivo).toBeCloseTo(147, 2);
    expect(r.body.totales.ventas).toBe(4);
  });

  test('el mes con solo pagos mixtos calcula bien el efectivo total', async () => {
    await crearRegistro(sesion, { fecha: '2026-02-05', nombre: 'Elena Vargas', entregados: 12, sobro: 2, total: 80, metodo_pago: 'mixto', yape_monto: 30 });
    await crearRegistro(sesion, { fecha: '2026-02-06', nombre: 'Felipe Núñez', entregados: 5, sobro: 5, total: 20, metodo_pago: 'yape' });
    const r = await request(app).get('/api/registros?mes=2026-02').set('Cookie', sesion.cookies);
    expect(r.body.totales.total).toBeCloseTo(100, 2);
    expect(r.body.totales.yape).toBeCloseTo(50, 2);   // 30 + 20
    expect(r.body.totales.efectivo).toBeCloseTo(50, 2); // 50 + 0
  });
});

describe('Fase A-6: exportación a Excel (fórmulas y formatos)', () => {
  test('genera el Excel del mes con fórmulas Vendidos y TOTAL, y formato de soles', async () => {
    const r = await descargar('/api/exportar?mes=2026-01', sesion.cookies);
    expect(r.status).toBe(200);
    expect(r.headers['content-type']).toMatch(/spreadsheetml/);
    expect(r.headers['content-disposition']).toContain('ventas-2026-01.xlsx');

    const ExcelJS = require('exceljs');
    const wb = new ExcelJS.Workbook();
    await wb.xlsx.load(r.body);
    const ws = wb.getWorksheet('Ventas 2026-01');

    expect(ws.getRow(1).getCell(1).value).toBe('Fecha');
    expect(ws.getRow(1).getCell(2).value).toBe('Nombre');
    expect(ws.getRow(1).getCell(6).value).toBe('Total (S/)');
    // Fila 2: fórmula Vendidos = C2 - D2
    expect(ws.getRow(2).getCell(5).formula).toBe('C2-D2');
    // Formato de moneda en Total
    expect(ws.getRow(2).getCell(6).numFmt).toContain('"S/"');
    // Formato de fecha dd/mm/yyyy
    expect(ws.getRow(2).getCell(1).numFmt).toBe('dd/mm/yyyy');
    // Fila TOTAL (4 ventas → fila 6) con SUM
    expect(ws.getRow(6).getCell(6).formula).toBe('SUM(F2:F5)');
  });

  test('mes SIN ventas: genera Excel con encabezados y TOTAL en 0', async () => {
    const r = await descargar('/api/exportar?mes=2025-12', sesion.cookies);
    expect(r.status).toBe(200);
    const ExcelJS = require('exceljs');
    const wb = new ExcelJS.Workbook();
    await wb.xlsx.load(r.body);
    const ws = wb.getWorksheet('Ventas 2025-12');
    expect(ws.rowCount).toBe(2); // encabezado + fila TOTAL
    expect(ws.getRow(2).getCell(1).value).toBe('TOTAL');
    expect(ws.getRow(2).getCell(6).value).toBe(0);
  });
});

```

### `tests/qa_validaciones.test.js`

```js
// tests/qa_validaciones.test.js
// Fase A-3: datos ilegales se rechazan con mensajes en español (server-side)
'use strict';
const { app, request, comoTesorero, crearRegistro, VENTA_BASE } = require('./helpers');

let sesion;
beforeAll(async () => { sesion = await comoTesorero(); });

async function enviar(campos) {
  const r = await crearRegistro(sesion, campos);
  return { status: r.status, cuerpo: r.body };
}

describe('Fase A-3: validación de datos ilegales', () => {
  test('nombre con SOLO espacios → rechazado', async () => {
    const r = await enviar({ ...VENTA_BASE, nombre: '    ' });
    expect(r.status).toBe(400);
    expect(r.cuerpo.errores.nombre).toMatch(/obligatorio/i);
  });

  test('entregados NEGATIVO → rechazado', async () => {
    const r = await enviar({ ...VENTA_BASE, entregados: -3 });
    expect(r.status).toBe(400);
    expect(r.cuerpo.errores.entregados).toBeDefined();
  });

  test('cantidades DECIMALES (3.5 libros) → rechazadas', async () => {
    const r = await enviar({ ...VENTA_BASE, sobro: 3.5 });
    expect(r.status).toBe(400);
    expect(r.cuerpo.errores.sobro).toBeDefined();
  });

  test('campos numéricos con TEXTO ("diez") → rechazados', async () => {
    const r = await enviar({ ...VENTA_BASE, entregados: 'diez', total: 'mucho' });
    expect(r.status).toBe(400);
    expect(r.cuerpo.errores.entregados).toBeDefined();
    expect(r.cuerpo.errores.total).toBeDefined();
  });

  test('sobró > entregados → rechazado', async () => {
    const r = await enviar({ ...VENTA_BASE, entregados: 5, sobro: 9 });
    expect(r.status).toBe(400);
    expect(r.cuerpo.errores.sobro).toMatch(/mayor que Entregados/i);
  });

  test('Yape > total → rechazado', async () => {
    const r = await enviar({ ...VENTA_BASE, metodo_pago: 'mixto', yape_monto: 80, total: 50 });
    expect(r.status).toBe(400);
    expect(r.cuerpo.errores.yape_monto).toMatch(/total/i);
  });

  test('número GIGANTE (1e9) → rechazado con límite claro', async () => {
    const r = await enviar({ ...VENTA_BASE, total: 1e9 });
    expect(r.status).toBe(400);
    expect(r.cuerpo.errores.total).toBeDefined();
  });

  test('NaN → rechazado', async () => {
    const r = await enviar({ ...VENTA_BASE, total: 'NaN' });
    expect(r.status).toBe(400);
    expect(r.cuerpo.errores.total).toBeDefined();
  });

  test('Infinity → rechazado', async () => {
    const r = await enviar({ ...VENTA_BASE, total: 'Infinity' });
    expect(r.status).toBe(400);
    expect(r.cuerpo.errores.total).toBeDefined();
  });

  test('fecha IMPOSIBLE 2026-02-31 → rechazada', async () => {
    const r = await enviar({ ...VENTA_BASE, fecha: '2026-02-31' });
    expect(r.status).toBe(400);
    expect(r.cuerpo.errores.fecha).toMatch(/fecha real/i);
  });

  test('fecha con formato extraño 15/01/2026 → rechazada', async () => {
    const r = await enviar({ ...VENTA_BASE, fecha: '15/01/2026' });
    expect(r.status).toBe(400);
    expect(r.cuerpo.errores.fecha).toBeDefined();
  });

  test('fecha VACÍA → rechazada', async () => {
    const r = await enviar({ ...VENTA_BASE, fecha: '' });
    expect(r.status).toBe(400);
    expect(r.cuerpo.errores.fecha).toBeDefined();
  });

  test('método de pago inválido → rechazado', async () => {
    const r = await enviar({ ...VENTA_BASE, metodo_pago: 'paypal' });
    expect(r.status).toBe(400);
    expect(r.cuerpo.errores.metodo_pago).toBeDefined();
  });

  test('mixto SIN monto yape → rechazado', async () => {
    const r = await enviar({ ...VENTA_BASE, metodo_pago: 'mixto' });
    expect(r.status).toBe(400);
    expect(r.cuerpo.errores.yape_monto).toMatch(/monto/i);
  });

  test('nombre con 101+ caracteres → rechazado', async () => {
    const r = await enviar({ ...VENTA_BASE, nombre: 'A'.repeat(101) });
    expect(r.status).toBe(400);
    expect(r.cuerpo.errores.nombre).toBeDefined();
  });

  test('los datos CORRECTOS sí pasan (control positivo)', async () => {
    const r = await enviar({ fecha: '2026-01-18', nombre: 'Gabriela Mendoza', entregados: 20, sobro: 4, total: 64.5, metodo_pago: 'mixto', yape_monto: 30 });
    expect(r.status).toBe(201);
    expect(r.cuerpo.registro.efectivo_monto).toBe(34.5);
  });
});

```

### `tests/qa_uploads_historial.test.js`

```js
// tests/qa_uploads_historial.test.js
// Fase A-4 (subidas) y A-5 (historial: filtros, búsqueda con caracteres raros, eliminar)
'use strict';
const fs = require('fs');
const path = require('path');
const { app, db, request, comoTesorero, comoConsulta, crearRegistro, insertarDirecto,
  pngValido, pdfValido, webpValido, jpegValido, falsoJpg, VENTA_BASE } = require('./helpers');
const { UPLOAD_DIR } = require('../app/server');

let tesorero, consulta;

beforeAll(async () => {
  tesorero = await comoTesorero();
  consulta = await comoConsulta();
});

describe('Fase A-4: subida de comprobantes', () => {
  test.each([
    ['JPG', jpegValido(), 'recibo.jpg'],
    ['PNG', pngValido(), 'recibo.png'],
    ['WEBP', webpValido(), 'recibo.webp'],
    ['PDF', pdfValido(), 'recibo.pdf'],
  ])('acepta archivo %s real', async (_tipo, buffer, nombre) => {
    const r = await crearRegistro(tesorero, { ...VENTA_BASE, metodo_pago: 'yape' }, { buffer, nombre, tipo: 'application/octet-stream' });
    expect(r.status).toBe(201);
    expect(r.body.registro.comprobante).toMatch(/\.(jpg|png|webp|pdf)$/);
    // B-7: el nombre en disco lo genera el servidor (UUID)
    expect(r.body.registro.comprobante).toMatch(/^[a-f0-9-]{36}\./);
    expect(fs.existsSync(path.join(UPLOAD_DIR, r.body.registro.comprobante))).toBe(true);
  });

  test('rechaza un .exe renombrado a .jpg (magic bytes)', async () => {
    const r = await crearRegistro(tesorero, { ...VENTA_BASE, metodo_pago: 'yape' }, { buffer: falsoJpg(), nombre: 'foto.jpg', tipo: 'image/jpeg' });
    expect(r.status).toBe(400);
    expect(r.body.error).toMatch(/no es válido/i);
  });

  test('rechaza archivo VACÍO (0 bytes)', async () => {
    const r = await crearRegistro(tesorero, { ...VENTA_BASE, metodo_pago: 'yape' }, { buffer: Buffer.alloc(0), nombre: 'vacio.png', tipo: 'image/png' });
    expect(r.status).toBe(400);
  });

  test('rechaza archivo mayor a 5 MB', async () => {
    const grande = Buffer.concat([pngValido(), Buffer.alloc(5 * 1024 * 1024 + 10, 7)]);
    const r = await crearRegistro(tesorero, { ...VENTA_BASE, metodo_pago: 'yape' }, { buffer: grande, nombre: 'grande.png', tipo: 'image/png' });
    expect(r.status).toBe(400);
    expect(r.body.error).toMatch(/5 MB/i);
  });

  test('nombre con caracteres extraños: se acepta la venta y el nombre original se sanea', async () => {
    const raro = 'comprobante  ⟨ñ⟩  ../../../etc/passwd .png';
    const r = await crearRegistro(tesorero, { ...VENTA_BASE, fecha: '2026-01-17', metodo_pago: 'yape' }, { buffer: pngValido(), nombre: raro, tipo: 'image/png' });
    expect(r.status).toBe(201);
    expect(r.body.registro.comprobante_nombre_original).not.toContain('/');
    expect(r.body.registro.comprobante_nombre_original).not.toContain('..');
    expect(r.body.registro.comprobante_nombre_original.length).toBeLessThanOrEqual(120);
  });

  test('sin comprobante: la venta se guarda igual (es opcional)', async () => {
    const r = await crearRegistro(tesorero, { ...VENTA_BASE, fecha: '2026-01-16', nombre: 'Hilda Torres' });
    expect(r.status).toBe(201);
    expect(r.body.registro.comprobante).toBeNull();
  });
});

describe('Fase A-5: historial, búsqueda y borrado', () => {
  beforeAll(async () => {
    insertarDirecto({ fecha: '2026-03-02', nombre: 'José Ñañez Cuéllar', entregados: 10, sobro: 2, total: 40, metodo_pago: 'efectivo' });
    insertarDirecto({ fecha: '2026-03-05', nombre: 'María García-López', entregados: 8, sobro: 1, total: 35, metodo_pago: 'yape' });
    insertarDirecto({ fecha: '2026-03-09', nombre: '100% Original_Marca', entregados: 4, sobro: 0, total: 16, metodo_pago: 'efectivo' });
  });

  test('filtro por MES devuelve solo ese mes', async () => {
    const r = await request(app).get('/api/registros?mes=2026-03').set('Cookie', tesorero.cookies);
    expect(r.status).toBe(200);
    expect(r.body.registros).toHaveLength(3);
    expect(r.body.registros.every((x) => x.fecha.startsWith('2026-03'))).toBe(true);
  });

  test('búsqueda por nombre con comillas y apóstrofes NO rompe ni altera datos', async () => {
    const r = await request(app).get('/api/registros?q=' + encodeURIComponent(`'" OR "1"="1`)).set('Cookie', tesorero.cookies);
    expect(r.status).toBe(200);
    expect(r.body.registros).toHaveLength(0);
  });

  test('búsqueda con % y _ NO actúa como comodín (está escapado)', async () => {
    const conPorcentaje = await request(app).get('/api/registros?q=' + encodeURIComponent('100%')).set('Cookie', tesorero.cookies);
    expect(conPorcentaje.status).toBe(200);
    expect(conPorcentaje.body.registros).toHaveLength(1);
    expect(conPorcentaje.body.registros[0].nombre).toContain('100% Original_Marca');

    const conGuionBajo = await request(app).get('/api/registros?q=' + encodeURIComponent('Original_')).set('Cookie', tesorero.cookies);
    expect(conGuionBajo.body.registros).toHaveLength(1);

    // 'a%' como comodín NO devuelve todo
    const comodin = await request(app).get('/api/registros?q=' + encodeURIComponent('a%')).set('Cookie', tesorero.cookies);
    expect(comodin.body.registros).toHaveLength(0);
  });

  test('búsqueda con TILDES y Ñ funciona (José Ñañez)', async () => {
    const r = await request(app).get('/api/registros?q=' + encodeURIComponent('Ñañez')).set('Cookie', tesorero.cookies);
    expect(r.status).toBe(200);
    expect(r.body.registros).toHaveLength(1);
    expect(r.body.registros[0].nombre).toBe('José Ñañez Cuéllar');

    const r2 = await request(app).get('/api/registros?q=' + encodeURIComponent('García-López')).set('Cookie', tesorero.cookies);
    expect(r2.body.registros).toHaveLength(1);
  });

  test('lista VACÍA cuando nada coincide, sin errores', async () => {
    const r = await request(app).get('/api/registros?q=zzz-inexistente').set('Cookie', tesorero.cookies);
    expect(r.status).toBe(200);
    expect(r.body.registros).toHaveLength(0);
    expect(r.body.totales.ventas).toBe(0);
  });

  test('ELIMINAR: borrado lógico → desaparece del listado normal y es recuperable', async () => {
    const id = insertarDirecto({ fecha: '2026-03-10', nombre: 'Iván Castillo', entregados: 6, sobro: 0, total: 24, metodo_pago: 'efectivo' });
    const del = await request(app).delete(`/api/registros/${id}`).set('Cookie', tesorero.cookies).set('x-csrf-token', tesorero.csrf);
    expect(del.status).toBe(200);

    const lista = await request(app).get('/api/registros?mes=2026-03').set('Cookie', tesorero.cookies);
    expect(lista.body.registros.some((x) => x.id === id)).toBe(false);

    const conEliminados = await request(app).get('/api/registros?mes=2026-03&eliminados=1').set('Cookie', tesorero.cookies);
    expect(conEliminados.body.registros.some((x) => x.id === id && x.eliminado === 1)).toBe(true);

    const res = await request(app).post(`/api/registros/${id}/restaurar`).set('Cookie', tesorero.cookies).set('x-csrf-token', tesorero.csrf);
    expect(res.status).toBe(200);
    const lista2 = await request(app).get('/api/registros?mes=2026-03').set('Cookie', tesorero.cookies);
    expect(lista2.body.registros.some((x) => x.id === id)).toBe(true);
  });

  test('AL ELIMINAR una venta con comprobante, el archivo deja de ser accesible (y se purga con scripts/purgar.js)', async () => {
    const r = await crearRegistro(tesorero, { ...VENTA_BASE, fecha: '2026-03-11', nombre: 'Julia Rojas', metodo_pago: 'yape' },
      { buffer: pngValido(), nombre: 'r.png', tipo: 'image/png' });
    const id = r.body.registro.id;
    const archivo = r.body.registro.comprobante;

    const ver = await request(app).get(`/api/comprobantes/${id}`).set('Cookie', consulta.cookies);
    expect(ver.status).toBe(200);

    await request(app).delete(`/api/registros/${id}`).set('Cookie', tesorero.cookies).set('x-csrf-token', tesorero.csrf);
    const ver2 = await request(app).get(`/api/comprobantes/${id}`).set('Cookie', consulta.cookies);
    expect(ver2.status).toBe(404);
    // El archivo físico permanece hasta la purga (borrado recuperable, B-15)
    expect(fs.existsSync(path.join(UPLOAD_DIR, archivo))).toBe(true);
  });

  test('ID inválido en DELETE se rechaza con 400 (no rompe)', async () => {
    const r = await request(app).delete('/api/registros/abc').set('Cookie', tesorero.cookies).set('x-csrf-token', tesorero.csrf);
    expect(r.status).toBe(400);
    const r2 = await request(app).delete('/api/registros/1%20OR%201=1').set('Cookie', tesorero.cookies).set('x-csrf-token', tesorero.csrf);
    expect(r2.status).toBe(400);
  });
});

```

### `tests/qa_concurrencia_export.test.js`

```js
// tests/qa_concurrencia_export.test.js
// Fase A-7 (50 ventas concurrentes), A-8 (doble clic) y A-6 (export 5.000 filas)
'use strict';
const ExcelJS = require('exceljs');
const { app, db, request, comoTesorero, crearRegistro, insertarDirecto, descargar, VENTA_BASE } = require('./helpers');

let sesion;
beforeAll(async () => { sesion = await comoTesorero(); });

describe('Fase A-7: 50 ventas concurrentes no se pierden ni duplican', () => {
  test('50 peticiones simultáneas → 50 registros, cada uno una sola vez', async () => {
    const respuestas = await Promise.all(
      Array.from({ length: 50 }, (_, i) =>
        crearRegistro(sesion, {
          fecha: '2026-04-01',
          nombre: `Concurrente ${i + 1}`,
          entregados: 10 + i,
          sobro: 2,
          total: 20 + i,
          metodo_pago: 'efectivo',
        })
      )
    );
    expect(respuestas.every((r) => r.status === 201)).toBe(true);

    const lista = await request(app).get('/api/registros?mes=2026-04').set('Cookie', sesion.cookies);
    const nombres = lista.body.registros.map((r) => r.nombre);
    expect(lista.body.totales.ventas).toBe(50);
    expect(new Set(nombres).size).toBe(50); // sin duplicados
    // y las sumas son correctas: total = Σ(20+i) para i=0..49 = 2225
    expect(lista.body.totales.total).toBeCloseTo(2225, 2);
  });
});

describe('Fase A-8: doble clic en "Guardar" no crea duplicados', () => {
  test('el mismo registro dos veces seguidas → la segunda es rechazada (409)', async () => {
    const campos = { fecha: '2026-04-02', nombre: 'Doble Clic Pérez', entregados: 9, sobro: 1, total: 33, metodo_pago: 'yape' };
    const [r1, r2] = await Promise.all([crearRegistro(sesion, campos), crearRegistro(sesion, campos)]);
    expect(r1.status).toBe(201);
    expect(r2.status).toBe(409);
    expect(r2.body.error).toMatch(/duplicado/i);

    const lista = await request(app).get('/api/registros?q=' + encodeURIComponent('Doble Clic Pérez')).set('Cookie', sesion.cookies);
    expect(lista.body.registros).toHaveLength(1);
  });

  test('la MISMA venta en otro día o de otro dato distinto SÍ se permite (no sobre-bloquea)', async () => {
    const r = await crearRegistro(sesion, { fecha: '2026-04-03', nombre: 'Doble Clic Pérez', entregados: 9, sobro: 1, total: 33, metodo_pago: 'yape' });
    expect(r.status).toBe(201);
  });
});

describe('Fase A-6b: exportación con 5.000 registros', () => {
  test('genera el Excel completo con 5.000 filas de datos', async () => {
    const insertarMuchos = db.transaction(() => {
      const stmt = db.prepare(`
        INSERT INTO registros (fecha, nombre, entregados, sobro, total, metodo_pago, yape_monto, efectivo_monto, creado_por)
        VALUES (?, ?, ?, ?, ?, 'efectivo', 0, ?, 'prueba')`);
      for (let i = 1; i <= 5000; i++) {
        stmt.run('2026-05-15', `Cliente Masivo ${i}`, 5, 1, 10, 10);
      }
    });
    insertarMuchos();

    const r = await descargar('/api/exportar?mes=2026-05', sesion.cookies);
    expect(r.status).toBe(200);
    expect(r.headers['content-disposition']).toContain('ventas-2026-05.xlsx');

    const wb = new ExcelJS.Workbook();
    await wb.xlsx.load(r.body);
    const ws = wb.getWorksheet('Ventas 2026-05');
    // 5000 filas de datos + encabezado + TOTAL
    expect(ws.rowCount).toBe(5002);
    expect(ws.getRow(2).getCell(2).value).toBe('Cliente Masivo 1');
    expect(ws.getRow(5001).getCell(2).value).toBe('Cliente Masivo 5000');
    // TOTAL con fórmula SUM
    expect(ws.getRow(5002).getCell(6).formula).toBe('SUM(F2:F5001)');
  }, 60000);
});

```

### `tests/seg_acceso.test.js`

```js
// tests/seg_acceso.test.js
// Fase B-1 (login+roles), B-2 (cookies), B-3 (anti fuerza bruta), B-4 (CSRF), B-8 (comprobantes privados)
'use strict';
const { app, db, request, comoTesorero, comoConsulta, crearRegistro, pngValido, VENTA_BASE } = require('./helpers');
const { resetLimitadoresPruebas } = require('../app/server');
const lockout = require('../app/lockout');

beforeAll(async () => {
  await comoTesorero(); // fuerza la siembra de usuarios
});

describe('Fase B-1: sin sesión no se puede hacer NADA', () => {
  test.each([
    ['GET /api/registros', (r) => r.get('/api/registros')],
    ['POST /api/registros', (r) => r.post('/api/registros')],
    ['DELETE /api/registros/1', (r) => r.delete('/api/registros/1')],
    ['GET /api/comprobantes/1', (r) => r.get('/api/comprobantes/1')],
    ['GET /api/exportar?mes=2026-01', (r) => r.get('/api/exportar?mes=2026-01')],
    ['GET /api/auditoria', (r) => r.get('/api/auditoria')],
    ['POST /api/logout', (r) => r.post('/api/logout')],
  ])('%s responde 401 sin cookie', async (_n, accion) => {
    const r = await accion(request(app));
    expect(r.status).toBe(401);
    expect(r.body.error).toMatch(/no autenticado|inicia sesión/i);
  });
});

describe('Fase B-1: roles — consulta es SOLO LECTURA', () => {
  test('consulta SÍ puede ver historial, comprobantes y exportar', async () => {
    const c = await comoConsulta();
    const r = await request(app).get('/api/registros').set('Cookie', c.cookies);
    expect(r.status).toBe(200);
  });

  test('consulta NO puede registrar ventas (403)', async () => {
    const c = await comoConsulta();
    const r = await crearRegistro(c, VENTA_BASE);
    expect(r.status).toBe(403);
    expect(r.body.error).toMatch(/rol Tesorero/i);
  });

  test('consulta NO puede eliminar ni restaurar (403)', async () => {
    const c = await comoConsulta();
    const del = await request(app).delete('/api/registros/1').set('Cookie', c.cookies).set('x-csrf-token', c.csrf);
    expect(del.status).toBe(403);
    const res = await request(app).post('/api/registros/1/restaurar').set('Cookie', c.cookies).set('x-csrf-token', c.csrf);
    expect(res.status).toBe(403);
  });
});

describe('Fase B-2: cookies de sesión seguras', () => {
  test('la cookie "sesion" es HttpOnly, SameSite=Strict, con expiración y path', async () => {
    const r = await request(app).post('/api/login').send({ usuario: process.env.ADMIN_USER, password: process.env.ADMIN_PASSWORD });
    const cookieSesion = r.headers['set-cookie'].find((c) => c.startsWith('sesion='));
    expect(cookieSesion).toContain('HttpOnly');
    expect(cookieSesion).toContain('SameSite=Strict');
    expect(cookieSesion).toContain('Max-Age=28800'); // 8 horas
    expect(cookieSesion).toContain('Path=/');
    // Nota: "Secure" se añade automáticamente sobre HTTPS (req.secure) o con
    // COOKIE_SECURE=1; en pruebas HTTP no se envía (comportamiento correcto).
  });

  test('LOGOUT invalida la sesión EN EL SERVIDOR: la cookie vieja ya no sirve', async () => {
    const s = await comoTesorero();
    const salida = await request(app).post('/api/logout').set('Cookie', s.cookies).set('x-csrf-token', s.csrf);
    expect(salida.status).toBe(200);

    const reuso = await request(app).get('/api/registros').set('Cookie', s.cookies);
    expect(reuso.status).toBe(401);
  });
});

describe('Fase B-4: protección CSRF', () => {
  test('POST sin cabecera x-csrf-token → 403 (con sesión válida)', async () => {
    const s = await comoTesorero();
    const r = await request(app).post('/api/registros')
      .set('Cookie', s.cookies)
      .field('fecha', '2026-01-20').field('nombre', 'Sin CSRF').field('entregados', '1')
      .field('sobro', '0').field('total', '5').field('metodo_pago', 'efectivo');
    expect(r.status).toBe(403);
    expect(r.body.error).toMatch(/CSRF/i);
  });

  test('POST con CSRF incorrecto → 403', async () => {
    const s = await comoTesorero();
    const r = await request(app).delete('/api/registros/99999')
      .set('Cookie', s.cookies).set('x-csrf-token', 'token-falso');
    expect(r.status).toBe(403);
  });

  test('DELETE sin CSRF → 403', async () => {
    const s = await comoTesorero();
    const r = await request(app).delete('/api/registros/99999').set('Cookie', s.cookies);
    expect(r.status).toBe(403);
  });
});

describe('Fase B-3: anti fuerza bruta', () => {
  beforeEach(() => { lockout._reset(); });
  afterAll(() => { resetLimitadoresPruebas(); }); // no contaminar otras pruebas

  test('LIMITADOR POR IP: 5 logins fallidos → el 6.º recibe 429 aunque la clave sea correcta', async () => {
    for (let i = 0; i < 5; i++) {
      const r = await request(app).post('/api/login').send({ usuario: 'admin-test', password: 'clave-incorrecta' });
      expect(r.status).toBe(401);
    }
    const r6 = await request(app).post('/api/login').send({ usuario: 'admin-test', password: process.env.ADMIN_PASSWORD });
    expect(r6.status).toBe(429);
    expect(r6.body.error).toMatch(/bloqueada|demasiados intentos/i);
  });

  test('BLOQUEO POR CUENTA (unidad): 5 fallos bloquean; se libera con limpiar() o al pasar la ventana', () => {
    for (let i = 0; i < 5; i++) lockout.registrarFallo('cuenta-prueba');
    const e = lockout.estado('cuenta-prueba');
    expect(e.bloqueado).toBe(true);
    expect(e.segundosRestantes).toBeGreaterThan(0);

    lockout.limpiar('cuenta-prueba');
    expect(lockout.estado('cuenta-prueba').bloqueado).toBe(false);
  });

  test('BLOQUEO POR CUENTA (unidad): un fallo fuera de la ventana de 15 min reinicia el conteo', () => {
    for (let i = 0; i < 4; i++) lockout.registrarFallo('cuenta-ventana');
    expect(lockout.estado('cuenta-ventana').fallos).toBe(4);
    expect(lockout.estado('cuenta-ventana').bloqueado).toBe(false); // aún no llega a 5
  });
});

describe('Fase B-8: comprobantes PRIVADOS (uploads/ no es público)', () => {
  test('la carpeta uploads/ NO se sirve como estática', async () => {
    const r = await request(app).get('/uploads/');
    expect(r.status).toBe(404);
    const r2 = await request(app).get('/uploads/cualquier.jpg');
    expect(r2.status).toBe(404);
  });

  test('ver el comprobante REQUIERE sesión; sin ella → 401', async () => {
    const t = await comoTesorero();
    const creado = await crearRegistro(t, { ...VENTA_BASE, fecha: '2026-06-01', nombre: 'Comprobante Privado', metodo_pago: 'yape' },
      { buffer: pngValido(), nombre: 'p.png', tipo: 'image/png' });
    const id = creado.body.registro.id;

    const sinSesion = await request(app).get(`/api/comprobantes/${id}`);
    expect(sinSesion.status).toBe(401);

    const conSesion = await request(app).get(`/api/comprobantes/${id}`).set('Cookie', t.cookies);
    expect(conSesion.status).toBe(200);
    expect(conSesion.headers['content-type']).toBe('image/png');
    expect(conSesion.headers['x-content-type-options']).toBe('nosniff');
  });

  test('no se puede pedir comprobante de registro inexistente (404) ni con ID inválido (400)', async () => {
    const t = await comoTesorero();
    expect((await request(app).get('/api/comprobantes/999999').set('Cookie', t.cookies)).status).toBe(404);
    expect((await request(app).get('/api/comprobantes/abc').set('Cookie', t.cookies)).status).toBe(400);
  });
});

```

### `tests/seg_inyeccion_errores.test.js`

```js
// tests/seg_inyeccion_errores.test.js
// Fase B-5 (SQLi), B-6 (XSS/CSP), B-9 (fórmulas Excel), B-10 (cabeceras), B-11 (errores)
'use strict';
const fs = require('fs');
const path = require('path');
const ExcelJS = require('exceljs');
const { app, db, request, comoTesorero, crearRegistro, insertarDirecto, descargar, VENTA_BASE } = require('./helpers');
const { UPLOAD_DIR } = require('../app/server');

let sesion;
beforeAll(async () => { sesion = await comoTesorero(); });

describe('Fase B-5: inyección SQL (parametrizada, no ejecuta nada)', () => {
  test("q = `' OR '1'='1` NO devuelve todas las filas", async () => {
    insertarDirecto({ fecha: '2026-07-01', nombre: 'UnicaVictima', entregados: 1, sobro: 0, total: 5, metodo_pago: 'efectivo' });
    const r = await request(app).get('/api/registros?q=' + encodeURIComponent("' OR '1'='1")).set('Cookie', sesion.cookies);
    expect(r.status).toBe(200);
    expect(r.body.registros).toHaveLength(0);
  });

  test('q con UNION SELECT no devuelve columnas ajenas', async () => {
    const r = await request(app).get('/api/registros?q=' + encodeURIComponent("' UNION SELECT 1,2,3,4,5,6,7,8,9,10,11,12,13,14--")).set('Cookie', sesion.cookies);
    expect(r.status).toBe(200);
    expect(r.body.registros).toHaveLength(0);
  });

  test('mes = `2026-01"--` se rechaza por formato', async () => {
    const r = await request(app).get('/api/registros?mes=' + encodeURIComponent("2026-01'--")).set('Cookie', sesion.cookies);
    expect(r.status).toBe(400);
  });

  test('DELETE con id = `1 OR 1=1` NO borra en masa (400)', async () => {
    const r = await request(app).delete('/api/registros/' + encodeURIComponent('1 OR 1=1')).set('Cookie', sesion.cookies).set('x-csrf-token', sesion.csrf);
    expect(r.status).toBe(400);
    const n = db.prepare('SELECT COUNT(*) AS n FROM registros').get().n;
    expect(n).toBeGreaterThan(0);
  });

  test('login con inyección no autentica (parametrizado)', async () => {
    const r = await request(app).post('/api/login').send({ usuario: "' OR '1'='1' --", password: 'x' });
    expect(r.status).toBe(401);
  });
});

describe('Fase B-6: XSS almacenado no se ejecuta + CSP estricta', () => {
  test('un nombre con <script> y <img onerror> se guarda como TEXTO y sale como texto JSON', async () => {
    const payload = '<script>alert(1)</script><img src=x onerror=alert(1)>';
    const r = await crearRegistro(sesion, { ...VENTA_BASE, fecha: '2026-07-02', nombre: payload });
    expect(r.status).toBe(201); // se guarda, pero nunca se ejecuta

    const lista = await request(app).get('/api/registros?q=' + encodeURIComponent('<script>')).set('Cookie', sesion.cookies);
    expect(lista.body.registros[0].nombre).toBe(payload);
  });

  test('el frontend no usa innerHTML con datos (inspección estática de app.js)', () => {
    const codigo = fs.readFileSync(path.join(__dirname, '..', 'app', 'public', 'app.js'), 'utf8');
    expect(codigo).not.toMatch(/\.innerHTML\s*=/);
    expect(codigo).not.toMatch(/document\.write/);
    expect(codigo).not.toMatch(/eval\(/);
  });

  test('el index.html no tiene scripts en línea (CSP)', () => {
    const html = fs.readFileSync(path.join(__dirname, '..', 'app', 'public', 'index.html'), 'utf8');
    expect(html).not.toMatch(/<script(?![^>]*src=)/i);
    expect(html).not.toMatch(/on(click|load|error)=/i);
  });
});

describe('Fase B-9: inyección de fórmulas en Excel neutralizada', () => {
  test.each([
    ['=HIPERVINCULO("http://evil.com";"clic")'],
    ['+CMD|\' /C calc\'!A0'],
    ['-2+3+cmd|\' /C calc\'!A0'],
    ['@SUM(1+1)'],
  ])('el nombre peligroso "%s" sale como TEXTO en el Excel', async (payload) => {
    insertarDirecto({ fecha: '2026-07-03', nombre: payload, entregados: 1, sobro: 0, total: 5, metodo_pago: 'efectivo' });
    const r = await descargar('/api/exportar?mes=2026-07', sesion.cookies);
    expect(r.status).toBe(200);

    const wb = new ExcelJS.Workbook();
    await wb.xlsx.load(r.body);
    const ws = wb.getWorksheet('Ventas 2026-07');
    const celdasNombre = [];
    ws.eachRow((fila, numeroFila) => {
      if (numeroFila === 1) return; // encabezado
      celdasNombre.push(String(fila.getCell(2).value));
    });
    const coincide = celdasNombre.find((v) => v.replace(/^'/, '') === payload);
    expect(coincide).toBeDefined();
    expect(coincide.startsWith("'")).toBe(true); // neutralizado: NO es fórmula
  });
});

describe('Fase B-10: cabeceras de seguridad', () => {
  test('CSP estricta, nosniff, frame deny, referrer y sin X-Powered-By', async () => {
    const r = await request(app).get('/');
    expect(r.status).toBe(200);
    expect(r.headers['content-security-policy']).toContain("default-src 'self'");
    expect(r.headers['content-security-policy']).toContain("script-src 'self'");
    expect(r.headers['content-security-policy']).toContain("frame-ancestors 'none'");
    expect(r.headers['content-security-policy']).toContain("object-src 'none'");
    expect(r.headers['x-content-type-options']).toBe('nosniff');
    expect(r.headers['x-frame-options']).toBe('DENY');
    expect(r.headers['referrer-policy']).toBe('no-referrer');
    expect(r.headers['cross-origin-resource-policy']).toBe('same-origin');
    expect(r.headers['x-powered-by']).toBeUndefined();
  });

  test('sin CORS: no hay Access-Control-Allow-Origin (app de mismo origen)', async () => {
    const r = await request(app).get('/api/registros').set('Cookie', sesion.cookies);
    expect(r.headers['access-control-allow-origin']).toBeUndefined();
  });
});

describe('Fase B-11: manejo de errores sin fugas de información', () => {
  test('JSON MALFORMADO → 400 con mensaje claro (no 500, sin stack)', async () => {
    const r = await request(app)
      .post('/api/registros')
      .set('Content-Type', 'application/json')
      .set('Cookie', sesion.cookies).set('x-csrf-token', sesion.csrf)
      .send('{"fecha": "2026-01-01", ');
    expect(r.status).toBe(400);
    expect(r.body.error).toMatch(/json/i);
    expect(JSON.stringify(r.body)).not.toMatch(/at\s+\w+\s+\(/);
  });

  test('CUERPO demasiado grande (>100 kb) → 413', async () => {
    const r = await request(app)
      .post('/api/registros')
      .set('Cookie', sesion.cookies).set('x-csrf-token', sesion.csrf)
      .set('Content-Type', 'application/json')
      .send(JSON.stringify({ fecha: '2026-01-01', nombre: 'X'.repeat(200 * 1024), entregados: 1, sobro: 0, total: 5, metodo_pago: 'efectivo' }));
    expect(r.status).toBe(413);
  });

  test('ruta API desconocida → 404 JSON (no HTML con detalles)', async () => {
    const r = await request(app).get('/api/ruta-inexistente').set('Cookie', sesion.cookies);
    expect(r.status).toBe(404);
    expect(r.headers['content-type']).toMatch(/json/);
    expect(r.body.error).toBe('Ruta no encontrada.');
  });

  test('los errores nunca incluyen stack traces ni rutas internas', async () => {
    const r = await request(app).post('/api/registros')
      .set('Content-Type', 'application/json')
      .set('Cookie', sesion.cookies).set('x-csrf-token', sesion.csrf)
      .send('{mal json');
    const texto = JSON.stringify(r.body);
    expect(texto).not.toMatch(/node_modules/);
    expect(texto).not.toMatch(/app\/server\.js/);
    expect(texto).not.toMatch(/at Object/);
  });
});

```

---

## ⑤ PRUEBAS AUTOMATIZADAS (Jest + supertest)

**Comando:** `npm test` (configuración en `jest.config.js`, entorno aislado por archivo con base temporal en `tests/setup.env.js`).

**Resultado real de la última ejecución: Test Suites: 6 passed, 6 total · Tests: 84 passed, 84 total.** Salida completa en `evidencia/02_tests_jest.txt`.

| Archivo | Qué cubre | Pruebas |
|---------|-----------|---------|
| `tests/qa_calculos.test.js` | A-1, A-2, A-6: 3 métodos de pago, cálculos, totales, Excel con fórmulas y formatos, mes sin ventas | 8 |
| `tests/qa_validaciones.test.js` | A-3: 17 casos de datos ilegales con mensajes en español | 17 |
| `tests/qa_uploads_historial.test.js` | A-4 y A-5: magic bytes, tamaños, nombres extraños, filtros, búsqueda escapada, eliminar/restaurar | 14 |
| `tests/qa_concurrencia_export.test.js` | A-7, A-8, A-6b: 50 concurrentes, doble clic (409), Excel de 5.000 filas | 3 |
| `tests/seg_acceso.test.js` | B-1, B-2, B-3, B-4, B-8: 401/403, cookies, logout real, CSRF, fuerza bruta, comprobantes privados | 16 |
| `tests/seg_inyeccion_errores.test.js` | B-5, B-6, B-9, B-10, B-11: SQLi, XSS, fórmulas, cabeceras, errores sin fugas | 21 |
| **Total** | | **84** |

Complementos ejecutados realmente (fuera de Jest):
- `npm run prueba:reinicio` → 8/8 PASS (`evidencia/09…txt`)
- `npm run prueba:bloqueo` → 5/5 PASS (`evidencia/10…txt`)
- `bash scripts/evidencia_curl.sh` → batería manual con curl (`evidencia/02-08…txt`)
- Verificación de interfaz con navegador headless real, incluida una venta registrada desde la UI y prueba de XSS (`evidencia/13…txt`, `pantallas/`)

---

## ⑥ INSTRUCCIONES DE DESPLIEGUE SEGURO

1. **Servidor**: Linux actualizado, Node.js ≥ 18. Ejecutar como usuario sin privilegios.
2. **Código**: clonar la carpeta, `npm ci --omit=dev`. Verificar `npm audit` antes de publicar.
3. **Variables**: `cp .env.example .env` y completar; `chmod 600 .env`. Contraseñas largas y únicas. `NODE_ENV=production`, `COOKIE_SECURE=1`.
4. **HTTPS obligatorio** (activa Secure + HSTS). Ejemplo nginx:

```nginx
server {
  listen 443 ssl http2;
  server_name ventas.tudominio.pe;
  ssl_certificate     /etc/letsencrypt/live/ventas.tudominio.pe/fullchain.pem;
  ssl_certificate_key /etc/letsencrypt/live/ventas.tudominio.pe/privkey.pem;
  add_header Strict-Transport-Security "max-age=15552000; includeSubDomains" always;
  client_max_body_size 6m;                # comprobantes de hasta 5 MB
  location / {
    proxy_pass http://127.0.0.1:3000;
    proxy_set_header Host $host;
    proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
    proxy_set_header X-Forwarded-Proto https;
  }
}
server { listen 80; server_name ventas.tudominio.pe; return 301 https://$host$request_uri; }
```

   Con proxy inverso definir `TRUST_PROXY=1` para que los límites y la auditoría usen la IP real.
5. **Servicio** (`/etc/systemd/system/venta-libros.service`):

```ini
[Unit]
Description=Venta de Libros
After=network.target
[Service]
User=ventas
WorkingDirectory=/opt/venta-libros
EnvironmentFile=/opt/venta-libros/.env
ExecStart=/usr/bin/node app/server.js
Restart=on-failure
NoNewPrivileges=true
ProtectSystem=strict
ReadWritePaths=/opt/venta-libros/data /opt/venta-libros/uploads /opt/venta-libros/backups
[Install]
WantedBy=multi-user.target
```

6. **Respaldos**: cron diario `30 2 * * * cd /opt/venta-libros && npm run backup` + cifrado y copia externa. Probar `npm run restore` mensualmente.
7. **Mantenimiento**: revisar `npm audit` cada mes; `npm run purgar` para la purga física programada; rotar contraseñas si un equipo sale del proyecto.
8. **Acceso**: solo tesoreros deben conocer `ADMIN_*`; para consultas crear únicamente el usuario `CONSULTA_*`.

---

## ⑦ LIMITACIONES Y RECOMENDACIONES (honestidad ante todo)

1. **El código original nunca fue recibido** (bloques vacíos). Esta auditoría se ejecutó sobre una reconstrucción de referencia fiel a la descripción. Si aportas tu `server.js` original, se puede hacer una revisión estática comparada y detectar defectos propios de tu implementación.
2. **NO EJECUTADA — dispositivos físicos**: la verificación responsive (360/768/1280) se hizo en Chromium headless; falta validar en móviles/tablets reales (cámara para subir comprobantes, teclado numérico, gestos).
3. **NO EJECUTADA — HTTPS real**: la configuración HSTS/Secure está incluida, pero no se probó con dominio y certificado reales.
4. **NO EJECUTADA — prueba de carga masiva**: se probaron 50 escrituras concurrentes y exportación de 5.000 filas; no hay ensayo de miles de usuarios simultáneos.
5. **`npm audit` con 9 vulnerabilidades MODERADAS remanentes** en dependencias transitivas de `exceljs` (archiver/glob/uuid), sin versión corregida publicada. Exposición baja: la exportación requiere sesión y no procesa archivos de terceros. Vigilar actualizaciones de `exceljs`.
6. **Búsqueda sin mayúsculas/minúsculas solo en ASCII**: SQLite `LIKE` no distingue mayúsculas en ASCII; “ÑAÑEZ” no encuentra “Ñañez” (sí lo encuentra con la misma mayúscula). Si molesta, se puede migrar a collation ICU.
7. **Deduplicación y bloqueos en memoria**: si el proceso reinicia, la ventana anti-doble-clic (10 s) y el bloqueo de cuentas (10 min) se reinician; el límite por IP también (proceso). Para instancias múltiples usar un almacén compartido (Redis).
8. **Antimalware de comprobantes no incluido**: se validan magic bytes y tamaño, pero no se escanea el contenido contra virus (opcional: ClamAV en el servidor).
9. **Sin pentest profesional** ni herramientas externas (Burp/ZAP). Recomendación: contratar una revisión de seguridad profesional antes de exponer a Internet, y probar las copias de seguridad restaurándolas en un equipo limpio.
10. La lista del historial muestra hasta 1.000 filas por consulta (los totales del mes sí cubren todos los registros); el Excel exporta el mes completo.

---

## ⑧ CHANGELOG DE ESTA VERSIÓN

# CHANGELOG — Venta de Libros

## v2.0.0 — Versión endurecida (auditoría QA + AppSec) — 2026-11-02

Auditoría integral (Fase A: funcional, 10 ítems · Fase B: seguridad, 15 ítems) sobre la versión v1.0.0 descrita.
Como el código original no fue proporcionado (bloques vacíos), se entregó una **reconstrucción de referencia fiel a la descripción** con TODAS las correcciones aplicadas y verificadas con pruebas reales (84/84 automatizadas + curl + navegador headless + scripts de infraestructura).

### Añadido
- **Login con roles**: `Tesorero` (crea/elimina/restaura) y `Consulta` (solo lectura). Contraseñas con **scrypt** (salt aleatoria + comparación en tiempo constante). Usuarios iniciales por variables de entorno.
- **Sesiones en base de datos**: logout invalida el token real en el servidor; expiración a 8 h.
- **Protección CSRF** (doble envío cookie + cabecera `x-csrf-token`) en POST/DELETE.
- **Anti fuerza bruta**: límite por IP (5 login fallidos/15 min) + bloqueo temporal de cuenta (10 min).
- **Visor de comprobantes privado** (`/api/comprobantes/:id`) con sesión obligatoria; `uploads/` ya no es público.
- **Restauración de registros**: borrado lógico recuperable + `scripts/purgar.js` (purga física a los 30 días).
- **Bitácora de auditoría** (`audit_log` + panel “Auditoría reciente”): login, altas, borrados, restauraciones, exportaciones, CSRF rechazados.
- **Scripts de respaldo/restauración** (`npm run backup` / `restore`) y documentación de cifrado (age/GPG).
- **Suite de pruebas automatizadas**: 84 pruebas Jest + supertest en 6 archivos.
- **Scripts de prueba de infraestructura**: reinicio/persistencia y base de datos bloqueada.
- **Interfaz responsive verificada** con navegador real (1280/768/360 px) y visor modal de comprobantes.

### Corregido (seguridad)
- **Crítico — sin autenticación**: antes cualquiera podía crear/borrar/exportar; ahora todo exige sesión + rol.
- **Crítico — comprobantes públicos**: antes servidos desde `/uploads`; ahora privados y con nombre UUID generado por el servidor.
- **Inyección SQL**: todas las consultas parametrizadas; `q` con comodines `% _` escapados (`ESCAPE '\'`).
- **XSS**: el frontend ya no inserta HTML con datos de usuario (solo `textContent`) + **CSP estricta** sin scripts en línea. Verificado en navegador real: el payload `<script>…<img onerror>` NO se ejecuta.
- **Subidas maliciosas**: validación de **magic bytes** (JPG/PNG/WEBP/PDF), límite 5 MB, archivo vacío rechazado, nombre original saneado, `.exe` renombrado a `.jpg` rechazado.
- **Inyección de fórmulas en Excel**: nombres que empiezan con `= + - @` se neutralizan con apóstrofe.
- **Cookies**: `HttpOnly` + `SameSite=Strict` + `Secure` (en HTTPS) + expiración.
- **Cabeceras**: helmet (CSP, `X-Content-Type-Options`, `X-Frame-Options: DENY`, Referrer-Policy, CRP same-origin), `X-Powered-By` oculto, sin CORS.
- **Errores**: middleware global sin stack traces al cliente; JSON malformado → 400; cuerpo >100 kb → 413; BD ocupada → 503 con mensaje claro.
- **Validación server-side completa**: espacios, negativos, decimales, `sobró > entregados`, `yape > total`, 1e9, NaN/Infinity, fechas imposibles (`2026-02-31`), formatos extraños, longitud y caracteres de control.
- **Doble clic en Guardar**: botón deshabilitado + deduplicación en servidor (409 con mensaje).
- **Base de datos**: WAL + `busy_timeout=5000` + transacciones; `uploads/` se recrea si falta.

### Corregido (funcional/interfaz)
- **Bug real detectado con navegador**: tras iniciar sesión la tarjeta de login seguía visible encima de la app (CSS pisaba el atributo `hidden`). Corregido con `.vista[hidden]{display:none!important}`.
- **Bug detectado durante pruebas**: `res.sendFile()` con ruta relativa devolvía 500 al ver comprobantes; corregido con ruta absoluta.
- Cálculo en vivo: vendidos = entregados − sobró; en pagos mixtos el efectivo se calcula solo (Total − Yape).
- Búsqueda por nombre compatible con `%`, `_`, comillas, tildes y `ñ`.
- Fechas en zona horaria America/Lima; filtro por mes sin desfases.

### Dependencias
- Versiones fijadas exactas; actualizadas `express 4.21.2 → 4.22.3` y `multer 2.0.2 → 2.5.0` tras `npm audit` real (14 vulnerabilidades → 9).
- Pendientes sin solución upstream: 9 vulnerabilidades **moderadas** en dependencias transitivas de `exceljs` (archiver/glob/uuid). Riesgo aceptado y documentado (informe §7).

### Notas de migración
- Si existe una base v1.0.0, se migran las columnas faltantes **sin perder datos** y con respaldo automático previo (`backups/pre-migracion-*.db`). Las restricciones CHECK completas solo aplican a tablas nuevas; la validación equivalente se aplica en el servidor.

# CHANGELOG — Venta de Libros

## v2.0.0 — Versión endurecida (auditoría QA + AppSec) — 2026-11-02

Auditoría integral (Fase A: funcional, 10 ítems · Fase B: seguridad, 15 ítems) sobre la versión v1.0.0 descrita.
Como el código original no fue proporcionado (bloques vacíos), se entregó una **reconstrucción de referencia fiel a la descripción** con TODAS las correcciones aplicadas y verificadas con pruebas reales (84/84 automatizadas + curl + navegador headless + scripts de infraestructura).

### Añadido
- **Login con roles**: `Tesorero` (crea/elimina/restaura) y `Consulta` (solo lectura). Contraseñas con **scrypt** (salt aleatoria + comparación en tiempo constante). Usuarios iniciales por variables de entorno.
- **Sesiones en base de datos**: logout invalida el token real en el servidor; expiración a 8 h.
- **Protección CSRF** (doble envío cookie + cabecera `x-csrf-token`) en POST/DELETE.
- **Anti fuerza bruta**: límite por IP (5 login fallidos/15 min) + bloqueo temporal de cuenta (10 min).
- **Visor de comprobantes privado** (`/api/comprobantes/:id`) con sesión obligatoria; `uploads/` ya no es público.
- **Restauración de registros**: borrado lógico recuperable + `scripts/purgar.js` (purga física a los 30 días).
- **Bitácora de auditoría** (`audit_log` + panel “Auditoría reciente”): login, altas, borrados, restauraciones, exportaciones, CSRF rechazados.
- **Scripts de respaldo/restauración** (`npm run backup` / `restore`) y documentación de cifrado (age/GPG).
- **Suite de pruebas automatizadas**: 84 pruebas Jest + supertest en 6 archivos.
- **Scripts de prueba de infraestructura**: reinicio/persistencia y base de datos bloqueada.
- **Interfaz responsive verificada** con navegador real (1280/768/360 px) y visor modal de comprobantes.

### Corregido (seguridad)
- **Crítico — sin autenticación**: antes cualquiera podía crear/borrar/exportar; ahora todo exige sesión + rol.
- **Crítico — comprobantes públicos**: antes servidos desde `/uploads`; ahora privados y con nombre UUID generado por el servidor.
- **Inyección SQL**: todas las consultas parametrizadas; `q` con comodines `% _` escapados (`ESCAPE '\'`).
- **XSS**: el frontend ya no inserta HTML con datos de usuario (solo `textContent`) + **CSP estricta** sin scripts en línea. Verificado en navegador real: el payload `<script>…<img onerror>` NO se ejecuta.
- **Subidas maliciosas**: validación de **magic bytes** (JPG/PNG/WEBP/PDF), límite 5 MB, archivo vacío rechazado, nombre original saneado, `.exe` renombrado a `.jpg` rechazado.
- **Inyección de fórmulas en Excel**: nombres que empiezan con `= + - @` se neutralizan con apóstrofe.
- **Cookies**: `HttpOnly` + `SameSite=Strict` + `Secure` (en HTTPS) + expiración.
- **Cabeceras**: helmet (CSP, `X-Content-Type-Options`, `X-Frame-Options: DENY`, Referrer-Policy, CRP same-origin), `X-Powered-By` oculto, sin CORS.
- **Errores**: middleware global sin stack traces al cliente; JSON malformado → 400; cuerpo >100 kb → 413; BD ocupada → 503 con mensaje claro.
- **Validación server-side completa**: espacios, negativos, decimales, `sobró > entregados`, `yape > total`, 1e9, NaN/Infinity, fechas imposibles (`2026-02-31`), formatos extraños, longitud y caracteres de control.
- **Doble clic en Guardar**: botón deshabilitado + deduplicación en servidor (409 con mensaje).
- **Base de datos**: WAL + `busy_timeout=5000` + transacciones; `uploads/` se recrea si falta.

### Corregido (funcional/interfaz)
- **Bug real detectado con navegador**: tras iniciar sesión la tarjeta de login seguía visible encima de la app (CSS pisaba el atributo `hidden`). Corregido con `.vista[hidden]{display:none!important}`.
- **Bug detectado durante pruebas**: `res.sendFile()` con ruta relativa devolvía 500 al ver comprobantes; corregido con ruta absoluta.
- Cálculo en vivo: vendidos = entregados − sobró; en pagos mixtos el efectivo se calcula solo (Total − Yape).
- Búsqueda por nombre compatible con `%`, `_`, comillas, tildes y `ñ`.
- Fechas en zona horaria America/Lima; filtro por mes sin desfases.

### Dependencias
- Versiones fijadas exactas; actualizadas `express 4.21.2 → 4.22.3` y `multer 2.0.2 → 2.5.0` tras `npm audit` real (14 vulnerabilidades → 9).
- Pendientes sin solución upstream: 9 vulnerabilidades **moderadas** en dependencias transitivas de `exceljs` (archiver/glob/uuid). Riesgo aceptado y documentado (informe §7).

### Notas de migración
- Si existe una base v1.0.0, se migran las columnas faltantes **sin perder datos** y con respaldo automático previo (`backups/pre-migracion-*.db`). Las restricciones CHECK completas solo aplican a tablas nuevas; la validación equivalente se aplica en el servidor.

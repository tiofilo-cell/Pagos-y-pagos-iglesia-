# Venta de Libros — v2.0.0 (versión endurecida y auditada)

Aplicación para registrar libros **entregados**, libros que **sobraron**, libros **vendidos** y el **total cobrado** por persona y fecha, con pagos en **Efectivo**, **Yape** o **Efectivo + Yape**, comprobante de Yape (imagen o PDF), historial con filtros y exportación a **Excel** mensual.

Moneda: S/ (sol peruano) · Zona horaria: America/Lima · Idioma: español.

---

## Interfaces para cada proceso (mapa UI ↔ proceso)

| # | Proceso | Interfaz (pantalla/control) | ¿Quién la ve? |
|---|---------|------------------------------|----------------|
| 1 | Autenticarse | Pantalla de **Inicio de sesión** (usuario + contraseña, mensajes de error en español) | Todos |
| 2 | Registrar venta | Tarjeta **“Registrar venta”**: fecha, nombre, entregados, sobró, **vendidos (se calcula solo)**, total, método de pago (3 botones de opción), campo condicional **Monto Yape** con **efectivo calculado solo (Total − Yape)** y subida de comprobante | Solo Tesorero |
| 3 | Guardar con protección anti-doble clic | Botón **Guardar** (se deshabilita mientras envía + el servidor rechaza duplicados con 409) | Solo Tesorero |
| 4 | Consultar historial | Tarjeta **“Historial de ventas”**: filtro por **mes**, **búsqueda por nombre**, opción **“Ver eliminados”** (tesorero), tabla con scroll horizontal en móviles | Tesorero y Consulta |
| 5 | Ver totales del mes | Fichas de totales: **ventas, libros vendidos, total, efectivo, yape** | Tesorero y Consulta |
| 6 | Ver comprobante de Yape | Botón **“Ver”** → **ventana emergente (modal)** con imagen o PDF (descarga privada con sesión) | Tesorero y Consulta |
| 7 | Eliminar / recuperar | Botones **Eliminar** (con confirmación) y **Restaurar** — borrado **lógico recuperable** | Solo Tesorero |
| 8 | Exportar Excel del mes | Botón **“Exportar Excel (mes)”** → `ventas-AAAA-MM.xlsx` con fórmulas y formato S/ | Tesorero y Consulta |
| 9 | Revisar actividad | Tarjeta **“Auditoría reciente”** (quién creó/eliminó/exportó, cuándo y desde qué IP) | Solo Tesorero |
| 10 | Cerrar sesión | Botón **“Cerrar sesión”** (invalida la sesión real en el servidor) | Todos |
| 11 | Modo solo lectura | Aviso **“Modo consulta”** — el rol Consulta ve el historial y comprobantes, sin botones de cambio | Rol Consulta |

Capturas reales (navegador headless) en la carpeta `pantallas/`: escritorio 1280 px, tablet 768 px y móvil 360 px.

---

## Ejecución rápida

```bash
npm install
cp .env.example .env        # editar: usuarios y contraseñas reales
npm start                   # http://localhost:3000
```

> Si no defines `ADMIN_USER`/`ADMIN_PASSWORD` y la tabla de usuarios está vacía,
> se crea el usuario `tesorero` con una contraseña aleatoria que se muestra **una sola vez** en la consola.

## Pruebas automatizadas

```bash
npm test                    # 84 pruebas (Jest + supertest), resultado real: 84/84 OK
npm run prueba:reinicio     # persistencia tras reinicio + recreación de uploads/
npm run prueba:bloqueo      # comportamiento con la base de datos bloqueada
bash scripts/evidencia_curl.sh http://127.0.0.1:3100   # batería manual con curl
```

## Respaldos

```bash
npm run backup                                # crea backups/respaldo-<fecha>/
node scripts/restore.js backups/respaldo-XXX --si
npm run purgar                                # purga físicamente eliminados > 30 días
```

### Respaldos cifrados (recomendado)

El respaldo contiene datos personales: **cífralo antes de sacarlo del servidor**.

Con [`age`](https://github.com/FiloSottile/age):
```bash
npm run backup
age -r edad1<TU_CLAVE_PUBLICA> -o respaldo.tar.gz.enc backups/respaldo-<fecha>.tar.gz   # primero comprime la carpeta
age -d -i clave-privada.txt respaldo.tar.gz.enc > respaldo.tar.gz
```
Con GPG:
```bash
tar czf respaldo.tar.gz backups/respaldo-<fecha>/
gpg -c respaldo.tar.gz            # pide una frase de contraseña
gpg -d respaldo.tar.gz.gpg > respaldo.tar.gz
```

---

## Variables de entorno (`.env`)

| Variable | Descripción | Por defecto |
|----------|-------------|-------------|
| `PORT` | Puerto del servidor | `3000` |
| `NODE_ENV` | `production` activa cookies Secure (requiere HTTPS) | `development` |
| `COOKIE_SECURE` | Fuerza cookies Secure (`1`) aunque no haya HTTPS | `0` |
| `TRUST_PROXY` | `1` si estás detrás de nginx/caddy (para IPs reales en límites y auditoría) | `0` |
| `DB_PATH` / `DATA_DIR` / `UPLOAD_DIR` / `BACKUP_DIR` | Rutas de datos | `./data`, `./uploads`, `./backups` |
| `SESSION_HORAS` | Duración de la sesión | `8` |
| `API_LIMIT_MAX` | Límite global de solicitudes por IP / 15 min | `600` |
| `LOGIN_LIMIT_MAX` | Intentos de login fallidos por IP / 15 min | `5` |
| `LOCKOUT_MAX` / `LOCKOUT_MINUTOS` | Bloqueo de cuenta por intentos fallidos | `5` / `10` |
| `ADMIN_USER` / `ADMIN_PASSWORD` | Usuario **Tesorero** inicial (crea, elimina, restaura) | — |
| `CONSULTA_USER` / `CONSULTA_PASSWORD` | Usuario **Consulta** inicial (solo lectura) | — |
| `DIAS_PURGA` | Días que se conservan los registros eliminados antes de purgar | `30` |

## Despliegue seguro (resumen — versión completa en INFORME_COMPLETO.md §6)

1. Servidor Linux actualizado + Node.js ≥ 18. Ejecutar la app con un usuario sin privilegios (p. ej. `systemd`).
2. HTTPS obligatorio con certificado real (nginx o caddy como proxy inverso) → activa `Secure` y `HSTS`. Ejemplo en el informe.
3. `NODE_ENV=production`, `COOKIE_SECURE=1`, `TRUST_PROXY=1`, contraseñas fuertes en `.env` (permisos `600`).
4. `npm ci --omit=dev`, `npm audit` antes de publicar, respaldo diario programado (cron) + cifrado.
5. La carpeta `uploads/` y la base `data/` **no** se publican; los comprobantes solo se ven con sesión.

## Documento principal

**`INFORME_COMPLETO.md`** — resumen ejecutivo, tabla de hallazgos, resultados de Fase A y Fase B, código completo, pruebas, despliegue, limitaciones y CHANGELOG.

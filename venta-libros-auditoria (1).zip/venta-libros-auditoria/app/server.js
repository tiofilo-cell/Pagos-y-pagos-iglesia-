// app/server.js
// ==========================================================================
// "Venta de Libros" — Servidor ENDURECIDO (v2.0.0)
// Node.js + Express + SQLite (better-sqlite3) + multer + ExcelJS.
//
// Mitigaciones implementadas (mapeo con el informe):
//  B-1  Login con roles (tesorero / consulta), scrypt, usuarios por .env
//  B-2  Cookie de sesión HttpOnly + SameSite=Strict + Secure(en HTTPS) + expiración y logout que invalida en el servidor
//  B-3  Límite de intentos de login (por IP) + bloqueo temporal por cuenta
//  B-4  Protección CSRF (token doble envío: cookie + cabecera x-csrf-token)
//  B-5  SQL 100% parametrizada (better-sqlite3 prepare)
//  B-6  Frontend sin innerHTML con datos de usuario + CSP estricta (helmet)
//  B-7  Subidas: validación de magic bytes, nombre generado por el servidor, límite 5 MB, sin rutas del cliente
//  B-8  uploads/ NO es público; los comprobantes se sirven SOLO con sesión
//  B-9  Neutralización de inyección de fórmulas en Excel
//  B-10 helmet (CSP, nosniff, frame-ancestors, HSTS en HTTPS), sin CORS, X-Powered-By oculto
//  B-11 Middleware global de errores: sin stack traces al cliente, JSON malformado y body grande controlados
//  B-12 Sin secretos en código: .env + .env.example + .gitignore; logs sin contraseñas ni tokens
//  B-13 Validación server-side completa (ver app/validaciones.js)
//  B-15 CHECK/NOT NULL, transacciones, auditoría y borrado lógico recuperable
// ==========================================================================
'use strict';

const path = require('path');
const fs = require('fs');
const crypto = require('crypto');
const express = require('express');
const helmet = require('helmet');
const cookieParser = require('cookie-parser');
const multer = require('multer');
const rateLimit = require('express-rate-limit');

const { db, migrar, auditor } = require('./db');
const { validarRegistro, sanitizarNombreOriginal } = require('./validaciones');
const { generarExcel } = require('./excel');
const { verificarPassword, sha256 } = require('./credenciales');
const lockout = require('./lockout');

// --------------------------------------------------------------------------
// Configuración (sin secretos en el código: todo viene de variables de entorno)
// --------------------------------------------------------------------------
const PUBLIC_DIR = path.join(__dirname, 'public');
const UPLOAD_DIR = path.resolve(process.env.UPLOAD_DIR || path.join(__dirname, '..', 'uploads'));
const PORT = parseInt(process.env.PORT || '3000', 10);
const SESSION_HORAS = parseInt(process.env.SESSION_HORAS || '8', 10);
// La cookie Secure se activa en producción o por fuerza con COOKIE_SECURE=1
const COOKIE_SECURE = process.env.COOKIE_SECURE === '1' || process.env.NODE_ENV === 'production';

// SEGURIDAD (Fase B-7): la carpeta de subidas se crea si no existe (Fase A-10)
fs.mkdirSync(UPLOAD_DIR, { recursive: true });

const app = express();
app.disable('x-powered-by'); // B-10: ocultar tecnología del servidor
if (process.env.TRUST_PROXY === '1') app.set('trust proxy', 1); // detrás de nginx/caddy

// --------------------------------------------------------------------------
// B-10: Cabeceras de seguridad con helmet (CSP estricta, sin inline scripts)
// --------------------------------------------------------------------------
app.use(helmet({
  contentSecurityPolicy: {
    useDefaults: true,
    directives: {
      'default-src': ["'self'"],
      'script-src': ["'self'"],
      'style-src': ["'self'"],
      'img-src': ["'self'", 'data:', 'blob:'],
      'frame-src': ["'self'", 'blob:'],
      'connect-src': ["'self'"],
      'object-src': ["'none'"],
      'frame-ancestors': ["'none'"],
      'base-uri': ["'self'"],
      'form-action': ["'self'"],
      'upgrade-insecure-requests': null, // se activa vía HTTPS/HSTS en producción (ver LEEME.md)
    },
  },
  hsts: { maxAge: 15552000, includeSubDomains: true }, // HSTS solo se envía sobre HTTPS
  frameguard: { action: 'deny' },
  referrerPolicy: { policy: 'no-referrer' },
  crossOriginResourcePolicy: { policy: 'same-origin' },
  crossOriginEmbedderPolicy: false, // permite incrustar PDF en el visor
}));
// B-10: CORS NO se habilita: la app es de mismo origen (sin Access-Control-Allow-*)

// --------------------------------------------------------------------------
// B-3: Límites de tasa (anti fuerza bruta / anti flood)
// --------------------------------------------------------------------------
const apiLimiter = rateLimit({
  windowMs: 15 * 60 * 1000,
  limit: parseInt(process.env.API_LIMIT_MAX || '600', 10),
  standardHeaders: true,
  legacyHeaders: false,
  message: { ok: false, error: 'Demasiadas solicitudes. Espera unos minutos e inténtalo de nuevo.' },
});
const loginLimiter = rateLimit({
  windowMs: 15 * 60 * 1000,
  limit: parseInt(process.env.LOGIN_LIMIT_MAX || '5', 10),
  skipSuccessfulRequests: true, // solo cuentan los intentos FALLIDOS
  standardHeaders: true,
  legacyHeaders: false,
  message: { ok: false, error: 'Demasiados intentos de inicio de sesión fallidos. Espera 15 minutos.' },
});
app.use('/api', apiLimiter);

// --------------------------------------------------------------------------
// Parseo de cuerpo: JSON y formularios con límite (B-11); multer solo multipart
// --------------------------------------------------------------------------
app.use(express.json({ limit: '100kb' }));
app.use(express.urlencoded({ extended: false, limit: '100kb' }));
app.use(cookieParser());

// B-7: multer en MEMORIA (nunca escribe rutas del cliente), 1 archivo, 5 MB
const subir = multer({
  storage: multer.memoryStorage(),
  limits: { fileSize: 5 * 1024 * 1024, files: 1 },
});

// --------------------------------------------------------------------------
// B-7: Validación de contenido real (magic bytes) — no se confía en la extensión
// --------------------------------------------------------------------------
const MIME_POR_TIPO = { jpg: 'image/jpeg', png: 'image/png', webp: 'image/webp', pdf: 'application/pdf' };

function detectarTipo(buf) {
  if (!buf || buf.length === 0) return null; // archivo vacío
  if (buf.length >= 3 && buf[0] === 0xFF && buf[1] === 0xD8 && buf[2] === 0xFF) return 'jpg';
  if (buf.length >= 8 && buf.subarray(0, 8).equals(Buffer.from([0x89, 0x50, 0x4E, 0x47, 0x0D, 0x0A, 0x1A, 0x0A]))) return 'png';
  if (buf.length >= 12 && buf.subarray(0, 4).toString('latin1') === 'RIFF' && buf.subarray(8, 12).toString('latin1') === 'WEBP') return 'webp';
  if (buf.length >= 5 && buf.subarray(0, 5).toString('latin1') === '%PDF-') return 'pdf';
  return null;
}

// --------------------------------------------------------------------------
// Sesiones guardadas en la base (logout = borrado real del token en servidor)
// --------------------------------------------------------------------------
function obtenerSesion(req) {
  const token = req.cookies && req.cookies.sesion;
  if (!token || !/^[a-f0-9]{64}$/.test(token)) return null;
  const fila = db.prepare(`
    SELECT s.csrf, s.expira_en, u.id AS usuario_id, u.usuario, u.rol, u.activo
    FROM sesiones s JOIN usuarios u ON u.id = s.usuario_id
    WHERE s.token_hash = ?`).get(sha256(token));
  if (!fila || fila.activo !== 1) return null;
  const expira = new Date(String(fila.expira_en).replace(' ', 'T') + 'Z');
  if (!(expira > new Date())) return null;
  return fila;
}

function requireAuth(req, res, next) {
  const s = obtenerSesion(req);
  if (!s) return res.status(401).json({ ok: false, error: 'No autenticado. Inicia sesión de nuevo.' });
  req.usuario = { id: s.usuario_id, nombre: s.usuario, rol: s.rol };
  req.csrfSesion = s.csrf;
  next();
}

function requireTesorero(req, res, next) {
  if (!req.usuario || req.usuario.rol !== 'tesorero') {
    return res.status(403).json({ ok: false, error: 'No autorizado: esta acción requiere el rol Tesorero.' });
  }
  next();
}

// B-4: CSRF por doble envío. El token vive en la sesión (BD) y en una cookie
// legible; el frontend debe enviarlo en la cabecera x-csrf-token.
function requireCsrf(req, res, next) {
  const cabecera = String(req.get('x-csrf-token') || '');
  const cookie = String(req.cookies.csrf || '');
  if (!cabecera || cabecera !== cookie || cabecera !== req.csrfSesion) {
    auditor(req.usuario && req.usuario.nombre, 'csrf_rechazado', req.originalUrl, req.ip);
    return res.status(403).json({ ok: false, error: 'Token de seguridad (CSRF) inválido. Recarga la página e inténtalo otra vez.' });
  }
  next();
}

// --------------------------------------------------------------------------
// Autenticación
// --------------------------------------------------------------------------
app.post('/api/login', loginLimiter, (req, res) => {
  const usuario = typeof req.body.usuario === 'string' ? req.body.usuario.trim().slice(0, 60) : '';
  const password = typeof req.body.password === 'string' ? req.body.password : '';
  if (!usuario || !password) {
    return res.status(400).json({ ok: false, error: 'Usuario y contraseña son obligatorios.' });
  }

  // B-3: bloqueo temporal por cuenta tras intentos fallidos
  const bloqueo = lockout.estado(usuario);
  if (bloqueo.bloqueado) {
    auditor(usuario, 'login_bloqueado', `intentos=${bloqueo.fallos}`, req.ip);
    return res.status(429).json({
      ok: false,
      error: `Cuenta temporalmente bloqueada por intentos fallidos. Espera ${Math.max(1, Math.ceil(bloqueo.segundosRestantes / 60))} minuto(s).`,
    });
  }

  const u = db.prepare('SELECT * FROM usuarios WHERE usuario = ? AND activo = 1').get(usuario);
  const passOk = u ? verificarPassword(password, u.password_hash) : verificarPassword(password, hashearFalso());
  if (!u || !passOk) {
    const r = lockout.registrarFallo(usuario);
    auditor(usuario, 'login_fallido', `fallo ${r.fallos}`, req.ip);
    // Mensaje genérico: no revela si el usuario existe (B-12)
    return res.status(401).json({ ok: false, error: 'Usuario o contraseña incorrectos.' });
  }

  lockout.limpiar(usuario);

  const token = crypto.randomBytes(32).toString('hex');
  const csrf = crypto.randomBytes(24).toString('hex');
  const expiraStr = new Date(Date.now() + SESSION_HORAS * 3600 * 1000)
    .toISOString().slice(0, 19).replace('T', ' ');

  const crearSesion = db.transaction(() => {
    db.prepare("DELETE FROM sesiones WHERE expira_en <= datetime('now')").run(); // limpieza de sesiones vencidas
    db.prepare('INSERT INTO sesiones (token_hash, usuario_id, csrf, expira_en) VALUES (?, ?, ?, ?)')
      .run(sha256(token), u.id, csrf, expiraStr);
  });
  crearSesion();

  const opciones = { httpOnly: true, sameSite: 'strict', path: '/', maxAge: SESSION_HORAS * 3600 * 1000, secure: COOKIE_SECURE || req.secure };
  res.cookie('sesion', token, opciones);                       // B-2: HttpOnly
  res.cookie('csrf', csrf, { ...opciones, httpOnly: false });  // B-4: legible por el frontend
  auditor(u.usuario, 'login_ok', '', req.ip);
  res.json({ ok: true, usuario: { nombre: u.usuario, rol: u.rol }, csrf });
});

// Hash desechable para igualar tiempos cuando el usuario no existe
function hashearFalso() {
  return 'scrypt$16384$8$1$' + '0'.repeat(32) + '$' + '0'.repeat(128);
}

app.post('/api/logout', requireAuth, requireCsrf, (req, res) => {
  const token = req.cookies.sesion;
  db.prepare('DELETE FROM sesiones WHERE token_hash = ?').run(sha256(token)); // B-2: invalidación real
  res.clearCookie('sesion', { path: '/' });
  res.clearCookie('csrf', { path: '/' });
  auditor(req.usuario.nombre, 'logout', '', req.ip);
  res.json({ ok: true, mensaje: 'Sesión cerrada correctamente.' });
});

app.get('/api/session', (req, res) => {
  const s = obtenerSesion(req);
  if (!s) return res.status(401).json({ ok: false, error: 'No autenticado.' });
  res.json({ ok: true, usuario: { nombre: s.usuario, rol: s.rol }, csrf: s.csrf });
});

// --------------------------------------------------------------------------
// Registro de ventas (solo tesorero)
// --------------------------------------------------------------------------
// Anti doble clic (Fase A-8): ventana de deduplicación en memoria (10 s).
const deduplicador = new Map();
const DEDUPE_MS = 10000;

app.post('/api/registros', requireAuth, requireTesorero, requireCsrf, subir.single('comprobante'), (req, res, next) => {
  try {
    const cuerpo = req.body || {};

    // B-13 / A-3: validación completa en servidor
    const v = validarRegistro(cuerpo);
    if (!v.ok) {
      return res.status(400).json({ ok: false, errores: v.errores, error: 'Revisa los campos marcados en rojo.' });
    }

    // B-7: validación de contenido real del comprobante (magic bytes)
    let archivo = null;
    let nombreOriginal = null;
    if (req.file && req.file.size === 0) {
      return res.status(400).json({ ok: false, error: 'El archivo del comprobante está vacío (0 bytes).' });
    }
    if (req.file) {
      const tipo = detectarTipo(req.file.buffer);
      if (!tipo) {
        return res.status(400).json({
          ok: false,
          error: 'El comprobante no es válido. Solo se aceptan imágenes JPG, PNG o WEBP, o un PDF real (máx. 5 MB).',
        });
      }
      archivo = crypto.randomUUID() + '.' + tipo; // B-7: nombre generado por el servidor
      nombreOriginal = sanitizarNombreOriginal(req.file.originalname);
      fs.writeFileSync(path.join(UPLOAD_DIR, archivo), req.file.buffer);
    }

    // A-8: deduplicación de envíos idénticos consecutivos (doble clic).
    // La clave incluye el hash del comprobante (si lo hay) para que dos envíos
    // con el mismo texto pero distinto archivo NO se consideren duplicados.
    const d = v.datos;
    const hashArchivo = req.file && req.file.size > 0 ? sha256(req.file.buffer.toString('binary')) : '-';
    const clave = sha256([req.usuario.id, d.fecha, d.nombre, d.total, d.metodo_pago, d.yape_monto, hashArchivo].join('|'));
    const previo = deduplicador.get(clave);
    if (previo && Date.now() - previo < DEDUPE_MS) {
      if (archivo) { try { fs.unlinkSync(path.join(UPLOAD_DIR, archivo)); } catch { /* nada */ } }
      return res.status(409).json({ ok: false, error: 'Posible envío duplicado: acabas de registrar una venta idéntica. Revisa el historial.' });
    }
    deduplicador.set(clave, Date.now());
    if (deduplicador.size > 1000) deduplicador.clear();

    // B-15: escritura atómica (registro + auditoría en una transacción)
    const insertar = db.transaction(() => {
      const info = db.prepare(`
        INSERT INTO registros (fecha, nombre, entregados, sobro, total, metodo_pago, yape_monto, efectivo_monto, comprobante, comprobante_nombre_original, creado_por)
        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`)
        .run(d.fecha, d.nombre, d.entregados, d.sobro, d.total, d.metodo_pago, d.yape_monto, d.efectivo_monto, archivo, nombreOriginal, req.usuario.nombre);
      auditor(req.usuario.nombre, 'crear_registro', `id=${info.lastInsertRowid}; nombre="${d.nombre}"; total=${d.total}`, req.ip);
      return info.lastInsertRowid;
    });
    const id = insertar();

    const registro = db.prepare('SELECT * FROM registros WHERE id = ?').get(id);
    res.status(201).json({ ok: true, registro });
  } catch (e) {
    next(e);
  }
});

// --------------------------------------------------------------------------
// Historial con filtros (mes y búsqueda por nombre) + totales
// --------------------------------------------------------------------------
app.get('/api/registros', requireAuth, (req, res, next) => {
  try {
    const condiciones = [];
    const params = [];

    const mes = req.query.mes;
    if (mes !== undefined && String(mes) !== '') {
      if (!/^\d{4}-\d{2}$/.test(String(mes))) {
        return res.status(400).json({ ok: false, error: 'El mes debe tener el formato AAAA-MM.' });
      }
      condiciones.push('fecha GLOB ?');
      params.push(String(mes) + '-[0-9][0-9]');
    }

    const q = req.query.q;
    if (q !== undefined && String(q).trim() !== '') {
      const texto = String(q).trim().slice(0, 100);
      // B-5: LIKE parametrizado y con caracteres comodín escapados (A-5)
      const escapado = texto.replace(/\\/g, '\\\\').replace(/%/g, '\\%').replace(/_/g, '\\_');
      condiciones.push("nombre LIKE ? ESCAPE '\\'");
      params.push('%' + escapado + '%');
    }

    // Borrados lógicos: solo visibles para tesorero si lo pide (B-15)
    let incluirEliminados = false;
    if (String(req.query.eliminados) === '1' && req.usuario.rol === 'tesorero') incluirEliminados = true;
    if (!incluirEliminados) condiciones.push('eliminado = 0');

    const where = condiciones.length ? 'WHERE ' + condiciones.join(' AND ') : '';

    const filas = db.prepare(`SELECT * FROM registros ${where} ORDER BY fecha DESC, id DESC LIMIT 1000`).all(...params);
    const t = db.prepare(`
      SELECT COUNT(*) AS n,
             COALESCE(SUM(total), 0)          AS total,
             COALESCE(SUM(efectivo_monto), 0) AS efectivo,
             COALESCE(SUM(yape_monto), 0)     AS yape
      FROM registros ${where}`).get(...params);

    res.json({
      ok: true,
      registros: filas,
      totales: { ventas: t.n, total: t.total, efectivo: t.efectivo, yape: t.yape },
      truncado: t.n > filas.length,
    });
  } catch (e) { next(e); }
});

// --------------------------------------------------------------------------
// Eliminación LÓGICA y restauración (B-15: recuperable + auditoría)
// --------------------------------------------------------------------------
app.delete('/api/registros/:id', requireAuth, requireTesorero, requireCsrf, (req, res, next) => {
  try {
    const id = Number(req.params.id);
    if (!Number.isInteger(id) || id <= 0) return res.status(400).json({ ok: false, error: 'ID inválido.' });
    const r = db.prepare('SELECT * FROM registros WHERE id = ? AND eliminado = 0').get(id);
    if (!r) return res.status(404).json({ ok: false, error: 'El registro no existe o ya fue eliminado.' });
    db.transaction(() => {
      db.prepare("UPDATE registros SET eliminado = 1, eliminado_en = datetime('now'), eliminado_por = ? WHERE id = ?")
        .run(req.usuario.nombre, id);
      auditor(req.usuario.nombre, 'eliminar_registro', `id=${id}; nombre="${r.nombre}" (borrado lógico, recuperable)`, req.ip);
    })();
    res.json({ ok: true, mensaje: 'Registro eliminado. Puedes recuperarlo con "Restaurar".' });
  } catch (e) { next(e); }
});

app.post('/api/registros/:id/restaurar', requireAuth, requireTesorero, requireCsrf, (req, res, next) => {
  try {
    const id = Number(req.params.id);
    if (!Number.isInteger(id) || id <= 0) return res.status(400).json({ ok: false, error: 'ID inválido.' });
    const r = db.prepare('SELECT * FROM registros WHERE id = ? AND eliminado = 1').get(id);
    if (!r) return res.status(404).json({ ok: false, error: 'No hay ningún registro eliminado con ese ID.' });
    db.transaction(() => {
      db.prepare('UPDATE registros SET eliminado = 0, eliminado_en = NULL, eliminado_por = NULL WHERE id = ?').run(id);
      auditor(req.usuario.nombre, 'restaurar_registro', `id=${id}; nombre="${r.nombre}"`, req.ip);
    })();
    res.json({ ok: true, mensaje: 'Registro restaurado correctamente.' });
  } catch (e) { next(e); }
});

// --------------------------------------------------------------------------
// B-8: Comprobantes PRIVADOS — solo con sesión válida y desde la base.
// Nunca servidos como archivos estáticos (la carpeta uploads/ no está pública).
// --------------------------------------------------------------------------
app.get('/api/comprobantes/:id', requireAuth, (req, res, next) => {
  try {
    const id = Number(req.params.id);
    if (!Number.isInteger(id) || id <= 0) return res.status(400).json({ ok: false, error: 'ID inválido.' });
    const r = db.prepare('SELECT comprobante FROM registros WHERE id = ? AND eliminado = 0').get(id);
    if (!r || !r.comprobante) return res.status(404).json({ ok: false, error: 'Comprobante no encontrado.' });
    // B-7: el nombre SIEMPRE viene de la BD con formato generado por el servidor
    if (!/^[a-f0-9-]{36}\.(jpg|png|webp|pdf)$/.test(r.comprobante)) {
      return res.status(404).json({ ok: false, error: 'Comprobante no válido.' });
    }
    const ruta = path.join(UPLOAD_DIR, r.comprobante);
    if (!ruta.startsWith(UPLOAD_DIR + path.sep) || !fs.existsSync(ruta)) {
      return res.status(404).json({ ok: false, error: 'El archivo del comprobante no está disponible.' });
    }
    auditor(req.usuario.nombre, 'ver_comprobante', `registro=${id}`, req.ip);
    res.setHeader('X-Content-Type-Options', 'nosniff');
    res.setHeader('Content-Disposition', `inline; filename="${r.comprobante}"`);
    res.sendFile(ruta);
  } catch (e) { next(e); }
});

// --------------------------------------------------------------------------
// Exportación mensual a Excel (A-6) con anti-inyección de fórmulas (B-9)
// --------------------------------------------------------------------------
app.get('/api/exportar', requireAuth, async (req, res, next) => {
  try {
    const mes = String(req.query.mes || '');
    if (!/^\d{4}-\d{2}$/.test(mes)) {
      return res.status(400).json({ ok: false, error: 'Indica un mes válido con formato AAAA-MM para exportar.' });
    }
    const filas = db.prepare(
      "SELECT * FROM registros WHERE fecha GLOB ? AND eliminado = 0 ORDER BY fecha ASC, id ASC"
    ).all(mes + '-[0-9][0-9]');
    const buffer = await generarExcel(mes, filas);
    auditor(req.usuario.nombre, 'exportar_excel', `mes=${mes}; filas=${filas.length}`, req.ip);
    res.setHeader('Content-Type', 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
    res.setHeader('Content-Disposition', `attachment; filename="ventas-${mes}.xlsx"`);
    res.send(Buffer.from(buffer));
  } catch (e) { next(e); }
});

// --------------------------------------------------------------------------
// Bitácora de auditoría (solo tesorero) — B-15
// --------------------------------------------------------------------------
app.get('/api/auditoria', requireAuth, requireTesorero, (req, res) => {
  const eventos = db.prepare('SELECT fecha, usuario, accion, detalle, ip FROM audit_log ORDER BY id DESC LIMIT 200').all();
  res.json({ ok: true, eventos });
});

// --------------------------------------------------------------------------
// B-11: 404 JSON para rutas API desconocidas + estáticos + error global
// --------------------------------------------------------------------------
app.use(express.static(PUBLIC_DIR, { maxAge: '1h', dotfiles: 'ignore' }));

app.use((req, res) => {
  if (req.path.startsWith('/api/')) return res.status(404).json({ ok: false, error: 'Ruta no encontrada.' });
  res.status(404).send('Página no encontrada.');
});

// eslint-disable-next-line no-unused-vars
app.use((err, req, res, next) => {
  if (res.headersSent) return next(err);
  let status = 500;
  let mensaje = 'Error interno del servidor. Inténtalo de nuevo.';
  if (err.type === 'entity.parse.failed') { status = 400; mensaje = 'El cuerpo de la solicitud no es un JSON válido.'; }
  else if (err.type === 'entity.too.large') { status = 413; mensaje = 'La solicitud es demasiado grande.'; }
  else if (err.code === 'LIMIT_FILE_SIZE') { status = 400; mensaje = 'El comprobante supera el tamaño máximo de 5 MB.'; }
  else if (err.code === 'SQLITE_BUSY' || err.code === 'SQLITE_BUSY_SNAPSHOT' || err.code === 'SQLITE_LOCKED') {
    status = 503; mensaje = 'La base de datos está ocupada en este momento. Inténtalo otra vez en unos segundos.';
  } else if (err.code === 'SQLITE_CONSTRAINT') {
    status = 400; mensaje = 'Los datos no cumplen las reglas de validación.';
  } else if (err.status && err.status >= 400 && err.status < 500 && err.expose) {
    status = err.status; mensaje = err.message;
  }
  // B-11/B-12: el detalle técnico solo va al log del servidor, NUNCA al cliente
  console.error(`[ERROR] ${req.method} ${req.originalUrl} -> ${status} [${err.code || err.type || 'sin código'}] ${err.message}`);
  res.status(status).json({ ok: false, error: mensaje });
});

// --------------------------------------------------------------------------
// Arranque
// --------------------------------------------------------------------------
// La migración (idempotente) corre AL CARGAR el módulo: así funcionan igual
// el servidor real y las pruebas con supertest.
migrar();

function iniciar() {
  return new Promise((resolve) => {
    const servidor = app.listen(PORT, () => {
      console.log(`Venta de Libros (v2.0.0) escuchando en el puerto ${PORT}`);
      resolve(servidor);
    });
    return servidor;
  });
}

if (require.main === module) {
  iniciar();
}

// Solo para pruebas automatizadas: reinicia los contadores de límite por IP
function resetLimitadoresPruebas() {
  for (const ip of ['127.0.0.1', '::ffff:127.0.0.1', '::1']) {
    try { apiLimiter.resetKey(ip); } catch { /* no soportado */ }
    try { loginLimiter.resetKey(ip); } catch { /* no soportado */ }
  }
}

module.exports = { app, iniciar, UPLOAD_DIR, resetLimitadoresPruebas };

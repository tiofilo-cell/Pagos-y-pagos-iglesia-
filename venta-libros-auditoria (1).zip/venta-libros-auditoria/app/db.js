// app/db.js
// --------------------------------------------------------------------------
// Capa de base de datos (SQLite con better-sqlite3) con:
//  - Configuración segura: WAL, busy_timeout (Fase A-10), foreign_keys ON.
//  - Migración IDEMPOTENTE para bases de datos antiguas: NO borra datos,
//    solo añade columnas faltantes y respalda antes de migrar (Fase B-15).
//  - Restricciones CHECK/NOT NULL en tablas nuevas (Fase B-15).
//  - Bitácora de auditoría (Fase B-15).
//  - Siembra inicial de usuarios SOLO si la tabla está vacía, usando
//    variables de entorno (Fase B-1); si no hay variables, genera una
//    contraseña aleatoria y la muestra UNA vez por consola.
// --------------------------------------------------------------------------
'use strict';
const fs = require('fs');
const path = require('path');
const Database = require('better-sqlite3');
const { hashearPassword } = require('./credenciales');

const ROOT = path.join(__dirname, '..');
const DATA_DIR = process.env.DATA_DIR || path.join(ROOT, 'data');
const DB_PATH = process.env.DB_PATH || path.join(DATA_DIR, 'ventas.db');
const BACKUP_DIR = process.env.BACKUP_DIR || path.join(ROOT, 'backups');

fs.mkdirSync(path.dirname(DB_PATH), { recursive: true });

const db = new Database(DB_PATH);
// SEGURIDAD/ROBUSTEZ: WAL reduce bloqueos; busy_timeout evita el error
// "database is locked" esperando hasta 5 s (ver scripts/prueba_bloqueo.js).
db.pragma('journal_mode = WAL');
db.pragma('busy_timeout = 5000');
db.pragma('foreign_keys = ON');
db.pragma('synchronous = NORMAL');

function crearTablas() {
  db.exec(`
  CREATE TABLE IF NOT EXISTS usuarios (
    id            INTEGER PRIMARY KEY AUTOINCREMENT,
    usuario       TEXT    NOT NULL UNIQUE,
    password_hash TEXT    NOT NULL,
    rol           TEXT    NOT NULL CHECK (rol IN ('tesorero','consulta')),
    activo        INTEGER NOT NULL DEFAULT 1 CHECK (activo IN (0,1)),
    creado_en     TEXT    NOT NULL DEFAULT (datetime('now'))
  );

  CREATE TABLE IF NOT EXISTS sesiones (
    token_hash TEXT    PRIMARY KEY,
    usuario_id INTEGER NOT NULL REFERENCES usuarios(id),
    csrf       TEXT    NOT NULL,
    creado_en  TEXT    NOT NULL DEFAULT (datetime('now')),
    expira_en  TEXT    NOT NULL
  );

  CREATE TABLE IF NOT EXISTS audit_log (
    id      INTEGER PRIMARY KEY AUTOINCREMENT,
    fecha   TEXT NOT NULL DEFAULT (datetime('now')),
    usuario TEXT,
    accion  TEXT NOT NULL,
    detalle TEXT,
    ip      TEXT
  );

  CREATE TABLE IF NOT EXISTS registros (
    id            INTEGER PRIMARY KEY AUTOINCREMENT,
    fecha         TEXT    NOT NULL CHECK (fecha GLOB '[0-9][0-9][0-9][0-9]-[0-9][0-9]-[0-9][0-9]'),
    nombre        TEXT    NOT NULL CHECK (length(trim(nombre)) > 0 AND length(nombre) <= 100),
    entregados    INTEGER NOT NULL CHECK (entregados >= 0 AND entregados <= 10000),
    sobro         INTEGER NOT NULL CHECK (sobro >= 0 AND sobro <= entregados),
    total         REAL    NOT NULL CHECK (total > 0 AND total <= 1000000),
    metodo_pago   TEXT    NOT NULL CHECK (metodo_pago IN ('efectivo','yape','mixto')),
    yape_monto    REAL    NOT NULL DEFAULT 0 CHECK (yape_monto >= 0 AND yape_monto <= total),
    efectivo_monto REAL   NOT NULL DEFAULT 0 CHECK (efectivo_monto >= 0),
    comprobante   TEXT,
    comprobante_nombre_original TEXT,
    eliminado     INTEGER NOT NULL DEFAULT 0 CHECK (eliminado IN (0,1)),
    eliminado_en  TEXT,
    eliminado_por TEXT,
    creado_en     TEXT    NOT NULL DEFAULT (datetime('now')),
    creado_por    TEXT
  );
  `);
}

// Migración idempotente para bases antiguas (v1): añade columnas faltantes.
function migrarColumnasLegacy() {
  const cols = db.prepare('PRAGMA table_info(registros)').all().map((c) => c.name);
  const faltantes = {
    metodo_pago: "ALTER TABLE registros ADD COLUMN metodo_pago TEXT NOT NULL DEFAULT 'efectivo'",
    yape_monto: 'ALTER TABLE registros ADD COLUMN yape_monto REAL NOT NULL DEFAULT 0',
    efectivo_monto: 'ALTER TABLE registros ADD COLUMN efectivo_monto REAL NOT NULL DEFAULT 0',
    comprobante: 'ALTER TABLE registros ADD COLUMN comprobante TEXT',
    comprobante_nombre_original: 'ALTER TABLE registros ADD COLUMN comprobante_nombre_original TEXT',
    eliminado: 'ALTER TABLE registros ADD COLUMN eliminado INTEGER NOT NULL DEFAULT 0',
    eliminado_en: 'ALTER TABLE registros ADD COLUMN eliminado_en TEXT',
    eliminado_por: 'ALTER TABLE registros ADD COLUMN eliminado_por TEXT',
    creado_en: "ALTER TABLE registros ADD COLUMN creado_en TEXT NOT NULL DEFAULT (datetime('now'))",
    creado_por: 'ALTER TABLE registros ADD COLUMN creado_por TEXT',
  };
  const pendientes = Object.keys(faltantes).filter((c) => !cols.includes(c));
  if (pendientes.length > 0) {
    // SEGURIDAD (Fase B-14): respaldo automático ANTES de tocar la estructura.
    respaldarAntesDeMigrar();
    for (const col of pendientes) db.exec(faltantes[col]);
    console.log(`[migración] Se añadieron columnas: ${pendientes.join(', ')}`);
  }
}

function respaldarAntesDeMigrar() {
  try {
    db.pragma('wal_checkpoint(TRUNCATE)');
    const ts = new Date().toISOString().replace(/[:T]/g, '-').slice(0, 19);
    fs.mkdirSync(BACKUP_DIR, { recursive: true });
    const destino = path.join(BACKUP_DIR, `pre-migracion-${ts}.db`);
    fs.copyFileSync(DB_PATH, destino);
    console.log(`[migración] Respaldo previo guardado en ${destino}`);
  } catch (e) {
    console.error('[migración] No se pudo respaldar antes de migrar:', e.message);
  }
}

function sembrarUsuarios() {
  const n = db.prepare('SELECT COUNT(*) AS n FROM usuarios').get().n;
  if (n > 0) return;
  // Fase B-1: usuarios iniciales SOLO por variables de entorno.
  const tesoreroUser = (process.env.ADMIN_USER || '').trim();
  const tesoreroPass = process.env.ADMIN_PASSWORD || '';
  const consultaUser = (process.env.CONSULTA_USER || '').trim();
  const consultaPass = process.env.CONSULTA_PASSWORD || '';

  const insertar = db.prepare(
    'INSERT INTO usuarios (usuario, password_hash, rol) VALUES (?, ?, ?)'
  );

  if (tesoreroUser && tesoreroPass) {
    insertar.run(tesoreroUser, hashearPassword(tesoreroPass), 'tesorero');
    console.log(`[usuarios] Tesorero creado desde variables de entorno: ${tesoreroUser}`);
  } else {
    const aleatoria = require('crypto').randomBytes(9).toString('base64url');
    insertar.run('tesorero', hashearPassword(aleatoria), 'tesorero');
    console.log('==========================================================');
    console.log('[usuarios] No se definieron ADMIN_USER/ADMIN_PASSWORD.');
    console.log('[usuarios] Usuario "tesorero" creado con contraseña ALEATORIA (mostrada UNA vez, guárdela):');
    console.log('           ' + aleatoria);
    console.log('==========================================================');
  }

  if (consultaUser && consultaPass) {
    insertar.run(consultaUser, hashearPassword(consultaPass), 'consulta');
    console.log(`[usuarios] Usuario de consulta creado desde variables de entorno: ${consultaUser}`);
  }
}

function migrar() {
  crearTablas();
  migrarColumnasLegacy();
  db.exec(`
    CREATE INDEX IF NOT EXISTS idx_registros_fecha  ON registros(fecha);
    CREATE INDEX IF NOT EXISTS idx_registros_nombre ON registros(nombre);
    CREATE INDEX IF NOT EXISTS idx_sesiones_usuario ON sesiones(usuario_id);
  `);
  sembrarUsuarios();
}

function auditor(usuario, accion, detalle, ip) {
  try {
    db.prepare('INSERT INTO audit_log (usuario, accion, detalle, ip) VALUES (?, ?, ?, ?)')
      .run(usuario || null, accion, detalle || null, ip || null);
  } catch (e) {
    console.error('[auditoría] no se pudo registrar el evento:', e.message);
  }
}

module.exports = { db, migrar, auditor, DB_PATH, UPLOAD_DIR_DEFAULT: null };

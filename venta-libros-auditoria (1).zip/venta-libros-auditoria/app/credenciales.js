// app/credenciales.js
// --------------------------------------------------------------------------
// SEGURIDAD (Fase B-1): hash fuerte de contraseñas con scrypt (node:crypto).
// Se usa scrypt en lugar de argon2 para evitar una dependencia nativa extra;
// scrypt es un KDF recomendado por OWASP (resistente a GPU, con parámetros N/r/p).
// Formato almacenado: scrypt$N$r$p$SALT_HEX$HASH_HEX
// Nunca se guardan ni se registran contraseñas en texto plano.
// --------------------------------------------------------------------------
'use strict';
const crypto = require('crypto');

const PARAMS = { N: 16384, r: 8, p: 1, KEYLEN: 64 };

function hashearPassword(plain) {
  const salt = crypto.randomBytes(16);
  const hash = crypto.scryptSync(String(plain), salt, PARAMS.KEYLEN, {
    N: PARAMS.N, r: PARAMS.r, p: PARAMS.p,
  });
  return ['scrypt', PARAMS.N, PARAMS.r, PARAMS.p, salt.toString('hex'), hash.toString('hex')].join('$');
}

function verificarPassword(plain, almacenado) {
  try {
    const partes = String(almacenado).split('$');
    if (partes.length !== 6 || partes[0] !== 'scrypt') return false;
    const N = parseInt(partes[1], 10), r = parseInt(partes[2], 10), p = parseInt(partes[3], 10);
    const salt = Buffer.from(partes[4], 'hex');
    const hashEsperado = Buffer.from(partes[5], 'hex');
    const hashCalculado = crypto.scryptSync(String(plain), salt, hashEsperado.length, { N, r, p });
    // Comparación en tiempo constante para evitar ataques de temporización
    return hashEsperado.length === hashCalculado.length && crypto.timingSafeEqual(hashEsperado, hashCalculado);
  } catch {
    return false;
  }
}

function sha256(texto) {
  return crypto.createHash('sha256').update(String(texto)).digest('hex');
}

module.exports = { hashearPassword, verificarPassword, sha256 };

// app/lockout.js
// --------------------------------------------------------------------------
// SEGURIDAD (Fase B-3): bloqueo temporal por cuenta tras N intentos fallidos
// de inicio de sesión (complementa el límite por IP de express-rate-limit).
// Estado en memoria: si el proceso reinicia, el bloqueo se libera, pero el
// límite por IP y el hash scrypt siguen protegiendo.
// --------------------------------------------------------------------------
'use strict';

const MAX_FALLOS = parseInt(process.env.LOCKOUT_MAX || '5', 10);
const VENTANA_MS = 15 * 60 * 1000;                                   // ventana de conteo: 15 min
const BLOQUEO_MS = parseInt(process.env.LOCKOUT_MINUTOS || '10', 10) * 60 * 1000; // 10 min por defecto

const estado_ = new Map(); // usuario -> { fallos, ultimo, bloqueadoHasta }

function normalizar(usuario) {
  return String(usuario || '').trim().toLowerCase();
}

function estado(usuario) {
  const e = estado_.get(normalizar(usuario));
  if (!e) return { bloqueado: false, fallos: 0, segundosRestantes: 0 };
  // Si pasó la ventana desde el último intento, se reinicia el conteo.
  if (Date.now() - (e.ultimo || 0) > VENTANA_MS) {
    e.fallos = 0;
    e.bloqueadoHasta = 0;
  }
  if (e.bloqueadoHasta && e.bloqueadoHasta > Date.now()) {
    return { bloqueado: true, fallos: e.fallos, segundosRestantes: Math.ceil((e.bloqueadoHasta - Date.now()) / 1000) };
  }
  return { bloqueado: false, fallos: e.fallos, segundosRestantes: 0 };
}

function registrarFallo(usuario) {
  const clave = normalizar(usuario);
  const e = estado_.get(clave) || { fallos: 0, ultimo: 0, bloqueadoHasta: 0 };
  if (Date.now() - e.ultimo > VENTANA_MS) { e.fallos = 0; e.bloqueadoHasta = 0; }
  e.fallos += 1;
  e.ultimo = Date.now();
  if (e.fallos >= MAX_FALLOS) e.bloqueadoHasta = Date.now() + BLOQUEO_MS;
  estado_.set(clave, e);
  return { fallos: e.fallos, bloqueado: !!(e.bloqueadoHasta && e.bloqueadoHasta > Date.now()) };
}

function limpiar(usuario) {
  estado_.delete(normalizar(usuario));
}

// Solo para pruebas automatizadas
function _reset() { estado_.clear(); }

module.exports = { estado, registrarFallo, limpiar, _reset };

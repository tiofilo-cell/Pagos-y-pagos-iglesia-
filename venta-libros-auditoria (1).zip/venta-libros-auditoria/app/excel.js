// app/excel.js
// --------------------------------------------------------------------------
// Exportación mensual a Excel (Fase A-6) con:
//  - Columnas: Fecha | Nombre | Entregados | Sobró | Vendidos | Total (S/) |
//    Método de pago | Yape (S/) | Efectivo (S/) | Comprobante
//  - Fórmulas reales: Vendidos = Entregados − Sobró (por fila) y TOTAL con SUM.
//  - Formato de moneda: "S/" #,##0.00  y formato de fecha dd/mm/yyyy.
//  - SEGURIDAD (Fase B-9): textos de usuario neutralizados contra inyección
//    de fórmulas (= + - @) mediante app/validaciones.js::neutralizar.
// --------------------------------------------------------------------------
'use strict';
const ExcelJS = require('exceljs');
const { neutralizar } = require('./validaciones');

const FMT_SOL = '"S/" #,##0.00';
const FMT_FECHA = 'dd/mm/yyyy';

const ETIQUETAS_METODO = {
  efectivo: 'Efectivo',
  yape: 'Yape',
  mixto: 'Efectivo + Yape',
};

async function generarExcel(mes, filas) {
  const wb = new ExcelJS.Workbook();
  wb.creator = 'Venta de Libros';
  wb.created = new Date();

  const ws = wb.addWorksheet(`Ventas ${mes}`);
  ws.columns = [
    { header: 'Fecha', key: 'fecha', width: 12 },
    { header: 'Nombre', key: 'nombre', width: 32 },
    { header: 'Entregados', key: 'entregados', width: 12 },
    { header: 'Sobró', key: 'sobro', width: 10 },
    { header: 'Vendidos', key: 'vendidos', width: 10 },
    { header: 'Total (S/)', key: 'total', width: 14 },
    { header: 'Método de pago', key: 'metodo_pago', width: 18 },
    { header: 'Yape (S/)', key: 'yape_monto', width: 14 },
    { header: 'Efectivo (S/)', key: 'efectivo_monto', width: 14 },
    { header: 'Comprobante', key: 'comprobante', width: 14 },
  ];

  filas.forEach((f, i) => {
    const r = i + 2; // la fila 1 es el encabezado
    const fila = ws.addRow([
      new Date(f.fecha + 'T12:00:00Z'),            // fecha como fecha real de Excel
      neutralizar(f.nombre),                        // anti inyección de fórmulas
      f.entregados,
      f.sobro,
      { formula: `C${r}-D${r}` },                   // Vendidos = Entregados - Sobró
      f.total,
      ETIQUETAS_METODO[f.metodo_pago] || f.metodo_pago,
      f.yape_monto,
      f.efectivo_monto,
      f.comprobante ? 'Sí' : 'No',
    ]);
    fila.getCell(1).numFmt = FMT_FECHA;
    fila.getCell(6).numFmt = FMT_SOL;
    fila.getCell(8).numFmt = FMT_SOL;
    fila.getCell(9).numFmt = FMT_SOL;
  });

  // Fila TOTAL con fórmulas SUM (o ceros si el mes no tiene ventas)
  const n = filas.length;
  const filaTotal = ws.addRow(['TOTAL', '', '', '', '', '', '', '', '', '']);
  const celdasSuma = [3, 4, 5, 6, 8, 9];
  if (n > 0) {
    celdasSuma.forEach((c) => {
      const letra = ['A', 'B', 'C', 'D', 'E', 'F', 'G', 'H', 'I', 'J'][c - 1];
      filaTotal.getCell(c).value = { formula: `SUM(${letra}2:${letra}${n + 1})` };
    });
  } else {
    celdasSuma.forEach((c) => { filaTotal.getCell(c).value = 0; });
  }
  [6, 8, 9].forEach((c) => { filaTotal.getCell(c).numFmt = FMT_SOL; });
  filaTotal.font = { bold: true };

  ws.getRow(1).font = { bold: true };
  ws.getRow(1).fill = { type: 'pattern', pattern: 'solid', fgColor: { argb: 'FFDCE6F1' } };
  ws.views = [{ state: 'frozen', ySplit: 1 }];

  return wb.xlsx.writeBuffer();
}

module.exports = { generarExcel };

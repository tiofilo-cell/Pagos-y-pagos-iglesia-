// app/validaciones.js
// --------------------------------------------------------------------------
// Validación central en el SERVIDOR (Fase A-3 y Fase B-13). El cliente no se
// confía: todos los límites y formatos se re-verifican aquí.
// Mensajes 100% en español para que el usuario entienda qué corregir.
// --------------------------------------------------------------------------
'use strict';

const MAX_TOTAL = 1000000;   // S/ 1,000,000.00 — rechaza 1e9 y números absurdos
const MAX_CANT = 10000;      // libros por registro

function esFechaValida(s) {
  // Acepta SOLO AAAA-MM-DD y fechas de calendario reales (rechaza 2026-02-31).
  if (typeof s !== 'string' || !/^\d{4}-\d{2}-\d{2}$/.test(s)) return false;
  const [a, m, d] = s.split('-').map(Number);
  if (m < 1 || m > 12 || d < 1 || d > 31) return false;
  const dt = new Date(Date.UTC(a, m - 1, d));
  return dt.getUTCFullYear() === a && dt.getUTCMonth() === m - 1 && dt.getUTCDate() === d;
}

function leerNumero(v) {
  if (typeof v === 'number') return v;
  if (typeof v === 'string' && v.trim() !== '') return Number(v.trim());
  return NaN;
}

function leerEntero(v) {
  if (typeof v === 'number' && Number.isInteger(v)) return v;
  if (typeof v === 'string' && /^-?\d+$/.test(v.trim())) return parseInt(v.trim(), 10);
  return NaN;
}

function validarRegistro(c) {
  const errores = {};
  const out = {};

  // --- Fecha ---
  if (!esFechaValida(c.fecha)) {
    errores.fecha = 'Fecha inválida. Usa el formato AAAA-MM-DD y una fecha real.';
  } else {
    out.fecha = c.fecha;
  }

  // --- Nombre ---
  const nombre = typeof c.nombre === 'string' ? c.nombre.trim() : '';
  if (!nombre) {
    errores.nombre = 'El nombre es obligatorio (no puede quedar vacío ni con solo espacios).';
  } else if (nombre.length > 100) {
    errores.nombre = 'El nombre no puede superar los 100 caracteres.';
  } else if (/[\u0000-\u001F\u007F]/.test(nombre)) {
    errores.nombre = 'El nombre contiene caracteres de control no permitidos.';
  } else {
    out.nombre = nombre;
  }

  // --- Cantidades enteras ---
  const entregados = leerEntero(c.entregados);
  const sobro = leerEntero(c.sobro);
  if (!Number.isInteger(entregados) || entregados < 0 || entregados > MAX_CANT) {
    errores.entregados = 'Entregados debe ser un número entero entre 0 y 10000.';
  }
  if (!Number.isInteger(sobro) || sobro < 0 || sobro > MAX_CANT) {
    errores.sobro = 'Sobró debe ser un número entero entre 0 y 10000.';
  }
  if (!errores.entregados && !errores.sobro && sobro > entregados) {
    errores.sobro = 'Sobró no puede ser mayor que Entregados.';
  }
  if (!errores.entregados && !errores.sobro) {
    out.entregados = entregados;
    out.sobro = sobro;
  }

  // --- Total en soles ---
  const total = leerNumero(c.total);
  if (!Number.isFinite(total) || total <= 0 || total > MAX_TOTAL) {
    errores.total = 'El total debe ser un número mayor a 0 y hasta S/ 1,000,000.00.';
  } else {
    out.total = Math.round(total * 100) / 100;
  }

  // --- Método de pago ---
  const metodo = c.metodo_pago;
  if (!['efectivo', 'yape', 'mixto'].includes(metodo)) {
    errores.metodo_pago = 'Selecciona un método de pago válido: Efectivo, Yape o Efectivo + Yape.';
  } else {
    out.metodo_pago = metodo;
  }

  // --- Montos Yape / Efectivo ---
  // Regla acordada: el usuario SOLO ingresa el monto Yape (en "mixto");
  // el efectivo se calcula automáticamente como Total − Yape.
  let yape = 0;
  if (metodo === 'yape') {
    yape = out.total !== undefined ? out.total : NaN; // Yape cubre todo el total
  } else if (metodo === 'mixto') {
    const y = leerNumero(c.yape_monto);
    if (!Number.isFinite(y) || y <= 0) {
      errores.yape_monto = 'Ingresa el monto pagado con Yape (mayor a 0).';
    } else if (out.total !== undefined && y >= out.total) {
      errores.yape_monto = 'El monto Yape debe ser menor que el total, porque el resto se paga en efectivo.';
    } else {
      yape = y;
    }
  }
  if (!errores.yape_monto && out.total !== undefined && yape > out.total) {
    errores.yape_monto = 'El monto Yape no puede superar el total.';
  }
  if (!errores.total && !errores.yape_monto && out.metodo_pago) {
    out.yape_monto = Math.round(yape * 100) / 100;
    out.efectivo_monto = Math.round((out.total - yape) * 100) / 100;
    if (out.efectivo_monto < 0) errores.yape_monto = 'El monto Yape no puede superar el total.';
  }

  return { ok: Object.keys(errores).length === 0, datos: out, errores };
}

// SEGURIDAD (Fase B-9): neutraliza inyección de fórmulas en Excel.
// Si un texto empieza con = + - @ tab o retorno, se antepone una comilla
// simple para que Excel lo trate como texto y no lo ejecute.
function neutralizar(texto) {
  const t = String(texto == null ? '' : texto);
  if (/^[=+\-@\t\r]/.test(t)) return "'" + t;
  return t;
}

// Sanea el nombre original del archivo subido: sin rutas, sin caracteres de
// control, longitud limitada. SOLO se usa para mostrarlo; el archivo se
// guarda con un nombre generado por el servidor (Fase B-7).
function sanitizarNombreOriginal(s) {
  let t = String(s || '')
    .split(/[/\\]/).pop()
    .replace(/[\u0000-\u001F\u007F]/g, '')
    .trim()
    .slice(0, 120);
  return t || 'comprobante';
}

module.exports = {
  validarRegistro,
  esFechaValida,
  neutralizar,
  sanitizarNombreOriginal,
  MAX_TOTAL,
  MAX_CANT,
};

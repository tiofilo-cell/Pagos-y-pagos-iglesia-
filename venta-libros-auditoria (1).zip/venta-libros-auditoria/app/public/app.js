// ==========================================================================
// app.js — Lógica del frontend (vanilla JS, sin frameworks).
//
// SEGURIDAD (Fase B-6): NUNCA se usa innerHTML con datos de usuario; todo se
// inserta con createElement/textContent (los datos se muestran como texto,
// nunca se ejecutan). La CSP del servidor prohíbe scripts en línea.
// Interfaz para cada proceso: login, registro de venta, historial con
// filtros/totales, comprobantes protegidos, exportar Excel, auditoría, logout.
// ==========================================================================
'use strict';

// ---------- Utilidades ----------
const $ = (id) => document.getElementById(id);

let estado = { usuario: null, rol: null, csrf: null };

function mostrarToast(mensaje, tipo) {
  const t = $('toast');
  t.textContent = mensaje;            // textContent: seguro ante XSS
  t.className = 'toast ' + (tipo || '');
  t.hidden = false;
  clearTimeout(mostrarToast._t);
  mostrarToast._t = setTimeout(() => { t.hidden = true; }, 3500);
}

function formatoSol(n) {
  const valor = Number(n) || 0;
  return 'S/ ' + new Intl.NumberFormat('es-PE', { minimumFractionDigits: 2, maximumFractionDigits: 2 }).format(valor);
}

// Fecha de hoy en la zona horaria de Perú (America/Lima), formato AAAA-MM-DD
function hoyLima() {
  return new Date().toLocaleDateString('en-CA', { timeZone: 'America/Lima' });
}

function mesActualLima() {
  return hoyLima().slice(0, 7);
}

function leerCookie(nombre) {
  const lista = document.cookie ? document.cookie.split('; ') : [];
  for (const par of lista) {
    const i = par.indexOf('=');
    if (i > -1 && par.slice(0, i) === nombre) return decodeURIComponent(par.slice(i + 1));
  }
  return '';
}

// ---------- Cliente API (siempre envía CSRF en cambios; 401 → volver a login) ----------
async function api(ruta, opciones = {}) {
  const config = { headers: {}, credentials: 'same-origin', ...opciones };
  if (config.method && config.method !== 'GET') {
    config.headers['x-csrf-token'] = estado.csrf || leerCookie('csrf');
  }
  const respuesta = await fetch(ruta, config);

  if (respuesta.status === 401) {
    mostrarLogin('Tu sesión expiró. Inicia sesión de nuevo.');
    throw new Error('No autenticado');
  }

  const tipo = respuesta.headers.get('content-type') || '';
  const cuerpo = tipo.includes('application/json') ? await respuesta.json() : await respuesta.text();

  if (!respuesta.ok) {
    const mensaje = (cuerpo && cuerpo.error) || `Error ${respuesta.status}`;
    const err = new Error(mensaje);
    err.status = respuesta.status;
    err.errores = cuerpo && cuerpo.errores;
    throw err;
  }
  return cuerpo;
}

// ---------- Cambio de vistas ----------
function mostrarLogin(mensaje) {
  $('vista-app').hidden = true;
  $('vista-login').hidden = false;
  const e = $('login-error');
  if (mensaje) { e.textContent = mensaje; e.hidden = false; } else { e.hidden = true; }
  $('login-password').value = '';
}

function mostrarApp() {
  $('vista-login').hidden = true;
  $('vista-app').hidden = false;
  $('nombre-usuario').textContent = estado.usuario;
  const badge = $('badge-rol');
  badge.textContent = estado.rol === 'tesorero' ? 'Tesorero' : 'Consulta';
  badge.className = 'badge' + (estado.rol === 'consulta' ? ' consulta' : '');

  // Interfaces según el ROL (Fase B-1): consulta = solo lectura
  const esTesorero = estado.rol === 'tesorero';
  $('aviso-consulta').hidden = esTesorero;
  $('panel-registro').hidden = !esTesorero;
  $('filtro-eliminados-box').hidden = !esTesorero;
  $('panel-auditoria').hidden = !esTesorero;

  $('campo-fecha').value = hoyLima();
  $('filtro-mes').value = mesActualLima();
  cargarHistorial();
  if (esTesorero) cargarAuditoria();
}

// ---------- Proceso: Iniciar sesión ----------
$('form-login').addEventListener('submit', async (ev) => {
  ev.preventDefault();
  const btn = $('btn-login');
  btn.disabled = true;
  $('login-error').hidden = true;
  try {
    const r = await fetch('/api/login', {
      method: 'POST',
      credentials: 'same-origin',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        usuario: $('login-usuario').value.trim(),
        password: $('login-password').value,
      }),
    });
    const cuerpo = await r.json().catch(() => ({}));
    if (!r.ok) {
      $('login-error').textContent = cuerpo.error || 'No se pudo iniciar sesión.';
      $('login-error').hidden = false;
      return;
    }
    estado = { usuario: cuerpo.usuario.nombre, rol: cuerpo.usuario.rol, csrf: cuerpo.csrf };
    mostrarApp();
  } catch {
    $('login-error').textContent = 'Error de conexión con el servidor.';
    $('login-error').hidden = false;
  } finally {
    btn.disabled = false;
  }
});

// ---------- Proceso: Cerrar sesión ----------
$('btn-logout').addEventListener('click', async () => {
  try {
    await api('/api/logout', { method: 'POST' });
  } catch { /* la sesión ya no existe: se continúa */ }
  estado = { usuario: null, rol: null, csrf: null };
  mostrarLogin('Sesión cerrada correctamente.');
});

// ---------- Proceso: Registrar venta ----------
function metodoSeleccionado() {
  return document.querySelector('input[name="metodo"]:checked').value;
}

function actualizarPreview() {
  const entregados = parseInt($('campo-entregados').value, 10);
  const sobro = parseInt($('campo-sobro').value, 10);
  $('preview-vendidos').textContent =
    Number.isInteger(entregados) && Number.isInteger(sobro) ? String(entregados - sobro) : '–';

  const metodo = metodoSeleccionado();
  $('bloque-yape').hidden = !(metodo === 'yape' || metodo === 'mixto');
  const total = parseFloat($('campo-total').value);
  if (metodo === 'yape') {
    $('campo-yape').value = Number.isFinite(total) ? total.toFixed(2) : '';
    $('campo-yape').readOnly = true;   // Yape cubre todo: no editable
    $('preview-efectivo').textContent = 'S/ 0.00';
  } else if (metodo === 'mixto') {
    $('campo-yape').readOnly = false;
    const yape = parseFloat($('campo-yape').value);
    $('preview-efectivo').textContent =
      Number.isFinite(total) && Number.isFinite(yape) ? formatoSol(total - yape) : '–';
  }
}

['campo-entregados', 'campo-sobro', 'campo-total', 'campo-yape'].forEach((id) => {
  $(id).addEventListener('input', actualizarPreview);
});
document.querySelectorAll('input[name="metodo"]').forEach((r) => r.addEventListener('change', actualizarPreview));

$('campo-comprobante').addEventListener('change', () => {
  const f = $('campo-comprobante').files[0];
  const p = $('archivo-seleccionado');
  if (f) {
    p.textContent = `Archivo elegido: ${f.name} (${(f.size / 1024 / 1024).toFixed(2)} MB)`;
    p.hidden = false;
  } else {
    p.hidden = true;
  }
});

$('form-venta').addEventListener('submit', async (ev) => {
  ev.preventDefault();
  const btn = $('btn-guardar');
  $('error-form').hidden = true;
  $('exito-form').hidden = true;

  // Anti doble clic (Fase A-8): se deshabilita el botón durante el envío
  btn.disabled = true;
  btn.textContent = 'Guardando…';

  try {
    const fd = new FormData();
    fd.append('fecha', $('campo-fecha').value);
    fd.append('nombre', $('campo-nombre').value);
    fd.append('entregados', $('campo-entregados').value);
    fd.append('sobro', $('campo-sobro').value);
    fd.append('total', $('campo-total').value);
    fd.append('metodo_pago', metodoSeleccionado());
    if (metodoSeleccionado() === 'mixto') fd.append('yape_monto', $('campo-yape').value);
    const archivo = $('campo-comprobante').files[0];
    if (archivo) fd.append('comprobante', archivo, archivo.name);

    const r = await api('/api/registros', { method: 'POST', body: fd });
    $('exito-form').textContent = `Venta registrada (ID ${r.registro.id}).`;
    $('exito-form').hidden = false;
    mostrarToast('Venta guardada correctamente', 'exito');
    $('form-venta').reset();
    $('archivo-seleccionado').hidden = true;
    $('campo-fecha').value = hoyLima();
    actualizarPreview();
    cargarHistorial();
    cargarAuditoria();
  } catch (e) {
    if (e.status === 400 && e.errores) {
      const detalles = Object.values(e.errores).join(' ');
      $('error-form').textContent = detalles || e.message;
      $('error-form').hidden = false;
    } else {
      $('error-form').textContent = e.message;
      $('error-form').hidden = false;
      mostrarToast(e.message, 'error');
    }
  } finally {
    btn.disabled = false;
    btn.textContent = 'Guardar';
  }
});

// ---------- Proceso: Historial (filtros, totales, eliminar/restaurar) ----------
async function cargarHistorial() {
  const mes = $('filtro-mes').value || '';
  const q = $('filtro-q').value.trim();
  const eliminados = $('filtro-eliminados').checked ? '1' : '0';
  const params = new URLSearchParams();
  if (mes) params.set('mes', mes);
  if (q) params.set('q', q);
  if (eliminados === '1') params.set('eliminados', '1');

  let cuerpo;
  try {
    cuerpo = await api('/api/registros?' + params.toString());
  } catch (e) {
    if (e.message !== 'No autenticado') mostrarToast(e.message, 'error');
    return;
  }

  const { registros, totales } = cuerpo;
  $('tot-ventas').textContent = totales.ventas;
  $('tot-total').textContent = formatoSol(totales.total);
  $('tot-efectivo').textContent = formatoSol(totales.efectivo);
  $('tot-yape').textContent = formatoSol(totales.yape);
  const libros = registros.reduce((a, r) => a + (r.entregados - r.sobro), 0);
  $('tot-libros').textContent = libros;

  const tbody = $('cuerpo-tabla');
  tbody.textContent = '';               // limpiar sin innerHTML
  $('aviso-vacio').hidden = registros.length > 0;

  const esTesorero = estado.rol === 'tesorero';

  for (const r of registros) {
    const tr = document.createElement('tr');
    if (r.eliminado) tr.className = 'eliminado';

    const celdas = [
      r.fecha,
      r.nombre,
      r.entregados,
      r.sobro,
      r.entregados - r.sobro,
      formatoSol(r.total),
      r.metodo_pago === 'efectivo' ? 'Efectivo' : r.metodo_pago === 'yape' ? 'Yape' : 'Efectivo + Yape',
      r.comprobante ? 'Sí' : 'No',
    ];
    celdas.forEach((valor) => {
      const td = document.createElement('td');
      td.textContent = valor;           // B-6: texto plano, sin HTML
      tr.appendChild(td);
    });

    const tdAcc = document.createElement('td');
    tdAcc.className = 'acciones-celda';

    if (r.comprobante) {
      const btnVer = document.createElement('button');
      btnVer.type = 'button';
      btnVer.className = 'btn secundario chico';
      btnVer.textContent = 'Ver';
      btnVer.addEventListener('click', () => verComprobante(r.id, r.comprobante_nombre_original));
      tdAcc.appendChild(btnVer);
    }
    if (esTesorero && !r.eliminado) {
      const btnDel = document.createElement('button');
      btnDel.type = 'button';
      btnDel.className = 'btn peligro chico';
      btnDel.textContent = 'Eliminar';
      btnDel.addEventListener('click', () => eliminarRegistro(r.id, r.nombre));
      tdAcc.appendChild(btnDel);
    }
    if (esTesorero && r.eliminado) {
      const btnRes = document.createElement('button');
      btnRes.type = 'button';
      btnRes.className = 'btn secundario chico';
      btnRes.textContent = 'Restaurar';
      btnRes.addEventListener('click', () => restaurarRegistro(r.id));
      tdAcc.appendChild(btnRes);
    }
    tr.appendChild(tdAcc);
    tbody.appendChild(tr);
  }
}

$('btn-filtrar').addEventListener('click', cargarHistorial);
$('filtro-q').addEventListener('keydown', (e) => { if (e.key === 'Enter') cargarHistorial(); });
$('filtro-eliminados').addEventListener('change', cargarHistorial);

// ---------- Proceso: Exportar Excel del mes ----------
$('btn-exportar').addEventListener('click', () => {
  const mes = $('filtro-mes').value;
  if (!mes) {
    mostrarToast('Elige un mes para exportar', 'error');
    return;
  }
  // Descarga por GET del mismo origen: la cookie de sesión viaja sola
  window.location.href = `/api/exportar?mes=${encodeURIComponent(mes)}`;
  mostrarToast('Generando Excel de ' + mes, 'exito');
});

// ---------- Proceso: Eliminar / restaurar ----------
async function eliminarRegistro(id, nombre) {
  if (!window.confirm(`¿Eliminar la venta de "${nombre}"? Podrás restaurarla desde "Ver eliminados".`)) return;
  try {
    const r = await api(`/api/registros/${id}`, { method: 'DELETE' });
    mostrarToast(r.mensaje || 'Registro eliminado', 'exito');
    cargarHistorial();
    cargarAuditoria();
  } catch (e) {
    if (e.message !== 'No autenticado') mostrarToast(e.message, 'error');
  }
}

async function restaurarRegistro(id) {
  try {
    const r = await api(`/api/registros/${id}/restaurar`, { method: 'POST' });
    mostrarToast(r.mensaje || 'Registro restaurado', 'exito');
    cargarHistorial();
    cargarAuditoria();
  } catch (e) {
    if (e.message !== 'No autenticado') mostrarToast(e.message, 'error');
  }
}

// ---------- Proceso: Ver comprobante (privado, con sesión) ----------
async function verComprobante(id, nombreOriginal) {
  try {
    const respuesta = await fetch(`/api/comprobantes/${id}`, { credentials: 'same-origin' });
    if (!respuesta.ok) {
      const cuerpo = await respuesta.json().catch(() => ({}));
      mostrarToast(cuerpo.error || 'No se pudo abrir el comprobante', 'error');
      return;
    }
    const blob = await respuesta.blob();
    const url = URL.createObjectURL(blob);
    const cuerpo = $('modal-cuerpo');
    cuerpo.textContent = '';
    $('modal-titulo').textContent = 'Comprobante' + (nombreOriginal ? ` — ${nombreOriginal}` : '');
    if (blob.type === 'application/pdf') {
      const iframe = document.createElement('iframe');
      iframe.src = url;
      iframe.title = 'Comprobante PDF';
      iframe.width = '100%';
      iframe.height = '480';
      cuerpo.appendChild(iframe);
    } else {
      const img = document.createElement('img');
      img.src = url;
      img.alt = 'Comprobante de pago';
      cuerpo.appendChild(img);
    }
    $('modal-comprobante').hidden = false;
    $('btn-cerrar-modal').onclick = () => {
      $('modal-comprobante').hidden = true;
      cuerpo.textContent = '';
      URL.revokeObjectURL(url);
    };
  } catch {
    mostrarToast('Error al cargar el comprobante', 'error');
  }
}

$('modal-comprobante').addEventListener('click', (e) => {
  if (e.target === $('modal-comprobante')) $('btn-cerrar-modal').click();
});

// ---------- Proceso: Auditoría (solo tesorero) ----------
async function cargarAuditoria() {
  if (estado.rol !== 'tesorero') return;
  let cuerpo;
  try {
    cuerpo = await api('/api/auditoria');
  } catch { return; }
  const tbody = $('cuerpo-auditoria');
  tbody.textContent = '';
  for (const ev of cuerpo.eventos) {
    const tr = document.createElement('tr');
    [ev.fecha, ev.usuario || '—', ev.accion, ev.detalle || '—'].forEach((valor) => {
      const td = document.createElement('td');
      td.textContent = valor;
      tr.appendChild(td);
    });
    tbody.appendChild(tr);
  }
}

// ---------- Arranque: ¿hay sesión activa? ----------
(async function init() {
  try {
    const r = await fetch('/api/session', { credentials: 'same-origin' });
    if (r.ok) {
      const cuerpo = await r.json();
      estado = { usuario: cuerpo.usuario.nombre, rol: cuerpo.usuario.rol, csrf: cuerpo.csrf };
      mostrarApp();
      return;
    }
  } catch { /* servidor no disponible: se muestra login */ }
  mostrarLogin();
})();

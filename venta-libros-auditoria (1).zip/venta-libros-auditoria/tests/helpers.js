// tests/helpers.js — utilidades comunes de la suite
'use strict';
const request = require('supertest');
const { app } = require('../app/server');
const { db } = require('../app/db');

const ADMIN = { usuario: process.env.ADMIN_USER, password: process.env.ADMIN_PASSWORD };
const CONSULTA = { usuario: process.env.CONSULTA_USER, password: process.env.CONSULTA_PASSWORD };

function extraerCookies(respuesta) {
  return (respuesta.headers['set-cookie'] || []).map((c) => c.split(';')[0]).join('; ');
}

async function login(usuario, password) {
  const r = await request(app).post('/api/login').send({ usuario, password });
  if (r.status !== 200) throw new Error(`login falló (${r.status}): ${JSON.stringify(r.body)}`);
  return { cookies: extraerCookies(r), csrf: r.body.csrf };
}

async function comoTesorero() { return login(ADMIN.usuario, ADMIN.password); }
async function comoConsulta() { return login(CONSULTA.usuario, CONSULTA.password); }

// Crear registro vía API (multipart si hay archivo, JSON si no)
async function crearRegistro(sesion, campos, archivo) {
  const r = request(app).post('/api/registros')
    .set('Cookie', sesion.cookies)
    .set('x-csrf-token', sesion.csrf);
  if (archivo) {
    r.attach('comprobante', archivo.buffer, { filename: archivo.nombre, contentType: archivo.tipo });
  }
  for (const [k, v] of Object.entries(campos)) r.field(k, String(v));
  return r;
}

// Insertar directamente en la BD (útil para datos masivos)
function insertarDirecto(campos) {
  return db.prepare(`
    INSERT INTO registros (fecha, nombre, entregados, sobro, total, metodo_pago, yape_monto, efectivo_monto, creado_por)
    VALUES (?, ?, ?, ?, ?, ?, ?, ?, 'prueba')`)
    .run(campos.fecha, campos.nombre, campos.entregados, campos.sobro,
      campos.total, campos.metodo_pago, campos.yape_monto || 0, campos.efectivo_monto || campos.total).lastInsertRowid;
}

// Descargar un archivo binario (xlsx) y devolver el Buffer real
function descargar(ruta, cookies) {
  return request(app).get(ruta).set('Cookie', cookies).buffer(true)
    .parse((res, cb) => {
      const trozos = [];
      res.on('data', (c) => trozos.push(c));
      res.on('end', () => cb(null, Buffer.concat(trozos)));
    });
}

// Buffers mínimos válidos para pruebas de magic bytes
function pngValido() {
  return Buffer.from('iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAYAAAAfFcSJAAAADUlEQVR42mP8z8BQDwAEhQGAhKmMIQAAAABJRU5ErkJggg==', 'base64');
}
function pdfValido() { return Buffer.from('%PDF-1.4\n1 0 obj\n%%EOF\n'); }
function webpValido() { return Buffer.concat([Buffer.from('RIFF'), Buffer.from([0x24, 0x00, 0x00, 0x00]), Buffer.from('WEBPVP8 '), Buffer.alloc(16, 1)]); }
function jpegValido() { return Buffer.concat([Buffer.from([0xFF, 0xD8, 0xFF, 0xE0]), Buffer.alloc(64, 0x7F)]); }
function falsoJpg() { return Buffer.concat([Buffer.from('MZ\x90\x00'), Buffer.alloc(32, 0x41)]); } // un .exe renombrado

const VENTA_BASE = { fecha: '2026-01-15', nombre: 'Rosa Quispe', entregados: 10, sobro: 3, total: 50, metodo_pago: 'efectivo' };

afterAll(() => { try { db.close(); } catch { /* ya cerrada */ } });

module.exports = {
  app, db, request, ADMIN, CONSULTA,
  login, comoTesorero, comoConsulta, extraerCookies,
  crearRegistro, insertarDirecto, descargar,
  pngValido, pdfValido, webpValido, jpegValido, falsoJpg,
  VENTA_BASE,
};

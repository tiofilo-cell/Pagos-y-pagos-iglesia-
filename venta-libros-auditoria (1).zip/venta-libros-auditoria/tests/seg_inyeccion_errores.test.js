// tests/seg_inyeccion_errores.test.js
// Fase B-5 (SQLi), B-6 (XSS/CSP), B-9 (fórmulas Excel), B-10 (cabeceras), B-11 (errores)
'use strict';
const fs = require('fs');
const path = require('path');
const ExcelJS = require('exceljs');
const { app, db, request, comoTesorero, crearRegistro, insertarDirecto, descargar, VENTA_BASE } = require('./helpers');
const { UPLOAD_DIR } = require('../app/server');

let sesion;
beforeAll(async () => { sesion = await comoTesorero(); });

describe('Fase B-5: inyección SQL (parametrizada, no ejecuta nada)', () => {
  test("q = `' OR '1'='1` NO devuelve todas las filas", async () => {
    insertarDirecto({ fecha: '2026-07-01', nombre: 'UnicaVictima', entregados: 1, sobro: 0, total: 5, metodo_pago: 'efectivo' });
    const r = await request(app).get('/api/registros?q=' + encodeURIComponent("' OR '1'='1")).set('Cookie', sesion.cookies);
    expect(r.status).toBe(200);
    expect(r.body.registros).toHaveLength(0);
  });

  test('q con UNION SELECT no devuelve columnas ajenas', async () => {
    const r = await request(app).get('/api/registros?q=' + encodeURIComponent("' UNION SELECT 1,2,3,4,5,6,7,8,9,10,11,12,13,14--")).set('Cookie', sesion.cookies);
    expect(r.status).toBe(200);
    expect(r.body.registros).toHaveLength(0);
  });

  test('mes = `2026-01"--` se rechaza por formato', async () => {
    const r = await request(app).get('/api/registros?mes=' + encodeURIComponent("2026-01'--")).set('Cookie', sesion.cookies);
    expect(r.status).toBe(400);
  });

  test('DELETE con id = `1 OR 1=1` NO borra en masa (400)', async () => {
    const r = await request(app).delete('/api/registros/' + encodeURIComponent('1 OR 1=1')).set('Cookie', sesion.cookies).set('x-csrf-token', sesion.csrf);
    expect(r.status).toBe(400);
    const n = db.prepare('SELECT COUNT(*) AS n FROM registros').get().n;
    expect(n).toBeGreaterThan(0);
  });

  test('login con inyección no autentica (parametrizado)', async () => {
    const r = await request(app).post('/api/login').send({ usuario: "' OR '1'='1' --", password: 'x' });
    expect(r.status).toBe(401);
  });
});

describe('Fase B-6: XSS almacenado no se ejecuta + CSP estricta', () => {
  test('un nombre con <script> y <img onerror> se guarda como TEXTO y sale como texto JSON', async () => {
    const payload = '<script>alert(1)</script><img src=x onerror=alert(1)>';
    const r = await crearRegistro(sesion, { ...VENTA_BASE, fecha: '2026-07-02', nombre: payload });
    expect(r.status).toBe(201); // se guarda, pero nunca se ejecuta

    const lista = await request(app).get('/api/registros?q=' + encodeURIComponent('<script>')).set('Cookie', sesion.cookies);
    expect(lista.body.registros[0].nombre).toBe(payload);
  });

  test('el frontend no usa innerHTML con datos (inspección estática de app.js)', () => {
    const codigo = fs.readFileSync(path.join(__dirname, '..', 'app', 'public', 'app.js'), 'utf8');
    expect(codigo).not.toMatch(/\.innerHTML\s*=/);
    expect(codigo).not.toMatch(/document\.write/);
    expect(codigo).not.toMatch(/eval\(/);
  });

  test('el index.html no tiene scripts en línea (CSP)', () => {
    const html = fs.readFileSync(path.join(__dirname, '..', 'app', 'public', 'index.html'), 'utf8');
    expect(html).not.toMatch(/<script(?![^>]*src=)/i);
    expect(html).not.toMatch(/on(click|load|error)=/i);
  });
});

describe('Fase B-9: inyección de fórmulas en Excel neutralizada', () => {
  test.each([
    ['=HIPERVINCULO("http://evil.com";"clic")'],
    ['+CMD|\' /C calc\'!A0'],
    ['-2+3+cmd|\' /C calc\'!A0'],
    ['@SUM(1+1)'],
  ])('el nombre peligroso "%s" sale como TEXTO en el Excel', async (payload) => {
    insertarDirecto({ fecha: '2026-07-03', nombre: payload, entregados: 1, sobro: 0, total: 5, metodo_pago: 'efectivo' });
    const r = await descargar('/api/exportar?mes=2026-07', sesion.cookies);
    expect(r.status).toBe(200);

    const wb = new ExcelJS.Workbook();
    await wb.xlsx.load(r.body);
    const ws = wb.getWorksheet('Ventas 2026-07');
    const celdasNombre = [];
    ws.eachRow((fila, numeroFila) => {
      if (numeroFila === 1) return; // encabezado
      celdasNombre.push(String(fila.getCell(2).value));
    });
    const coincide = celdasNombre.find((v) => v.replace(/^'/, '') === payload);
    expect(coincide).toBeDefined();
    expect(coincide.startsWith("'")).toBe(true); // neutralizado: NO es fórmula
  });
});

describe('Fase B-10: cabeceras de seguridad', () => {
  test('CSP estricta, nosniff, frame deny, referrer y sin X-Powered-By', async () => {
    const r = await request(app).get('/');
    expect(r.status).toBe(200);
    expect(r.headers['content-security-policy']).toContain("default-src 'self'");
    expect(r.headers['content-security-policy']).toContain("script-src 'self'");
    expect(r.headers['content-security-policy']).toContain("frame-ancestors 'none'");
    expect(r.headers['content-security-policy']).toContain("object-src 'none'");
    expect(r.headers['x-content-type-options']).toBe('nosniff');
    expect(r.headers['x-frame-options']).toBe('DENY');
    expect(r.headers['referrer-policy']).toBe('no-referrer');
    expect(r.headers['cross-origin-resource-policy']).toBe('same-origin');
    expect(r.headers['x-powered-by']).toBeUndefined();
  });

  test('sin CORS: no hay Access-Control-Allow-Origin (app de mismo origen)', async () => {
    const r = await request(app).get('/api/registros').set('Cookie', sesion.cookies);
    expect(r.headers['access-control-allow-origin']).toBeUndefined();
  });
});

describe('Fase B-11: manejo de errores sin fugas de información', () => {
  test('JSON MALFORMADO → 400 con mensaje claro (no 500, sin stack)', async () => {
    const r = await request(app)
      .post('/api/registros')
      .set('Content-Type', 'application/json')
      .set('Cookie', sesion.cookies).set('x-csrf-token', sesion.csrf)
      .send('{"fecha": "2026-01-01", ');
    expect(r.status).toBe(400);
    expect(r.body.error).toMatch(/json/i);
    expect(JSON.stringify(r.body)).not.toMatch(/at\s+\w+\s+\(/);
  });

  test('CUERPO demasiado grande (>100 kb) → 413', async () => {
    const r = await request(app)
      .post('/api/registros')
      .set('Cookie', sesion.cookies).set('x-csrf-token', sesion.csrf)
      .set('Content-Type', 'application/json')
      .send(JSON.stringify({ fecha: '2026-01-01', nombre: 'X'.repeat(200 * 1024), entregados: 1, sobro: 0, total: 5, metodo_pago: 'efectivo' }));
    expect(r.status).toBe(413);
  });

  test('ruta API desconocida → 404 JSON (no HTML con detalles)', async () => {
    const r = await request(app).get('/api/ruta-inexistente').set('Cookie', sesion.cookies);
    expect(r.status).toBe(404);
    expect(r.headers['content-type']).toMatch(/json/);
    expect(r.body.error).toBe('Ruta no encontrada.');
  });

  test('los errores nunca incluyen stack traces ni rutas internas', async () => {
    const r = await request(app).post('/api/registros')
      .set('Content-Type', 'application/json')
      .set('Cookie', sesion.cookies).set('x-csrf-token', sesion.csrf)
      .send('{mal json');
    const texto = JSON.stringify(r.body);
    expect(texto).not.toMatch(/node_modules/);
    expect(texto).not.toMatch(/app\/server\.js/);
    expect(texto).not.toMatch(/at Object/);
  });
});

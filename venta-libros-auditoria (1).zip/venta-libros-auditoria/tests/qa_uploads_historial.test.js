// tests/qa_uploads_historial.test.js
// Fase A-4 (subidas) y A-5 (historial: filtros, búsqueda con caracteres raros, eliminar)
'use strict';
const fs = require('fs');
const path = require('path');
const { app, db, request, comoTesorero, comoConsulta, crearRegistro, insertarDirecto,
  pngValido, pdfValido, webpValido, jpegValido, falsoJpg, VENTA_BASE } = require('./helpers');
const { UPLOAD_DIR } = require('../app/server');

let tesorero, consulta;

beforeAll(async () => {
  tesorero = await comoTesorero();
  consulta = await comoConsulta();
});

describe('Fase A-4: subida de comprobantes', () => {
  test.each([
    ['JPG', jpegValido(), 'recibo.jpg'],
    ['PNG', pngValido(), 'recibo.png'],
    ['WEBP', webpValido(), 'recibo.webp'],
    ['PDF', pdfValido(), 'recibo.pdf'],
  ])('acepta archivo %s real', async (_tipo, buffer, nombre) => {
    const r = await crearRegistro(tesorero, { ...VENTA_BASE, metodo_pago: 'yape' }, { buffer, nombre, tipo: 'application/octet-stream' });
    expect(r.status).toBe(201);
    expect(r.body.registro.comprobante).toMatch(/\.(jpg|png|webp|pdf)$/);
    // B-7: el nombre en disco lo genera el servidor (UUID)
    expect(r.body.registro.comprobante).toMatch(/^[a-f0-9-]{36}\./);
    expect(fs.existsSync(path.join(UPLOAD_DIR, r.body.registro.comprobante))).toBe(true);
  });

  test('rechaza un .exe renombrado a .jpg (magic bytes)', async () => {
    const r = await crearRegistro(tesorero, { ...VENTA_BASE, metodo_pago: 'yape' }, { buffer: falsoJpg(), nombre: 'foto.jpg', tipo: 'image/jpeg' });
    expect(r.status).toBe(400);
    expect(r.body.error).toMatch(/no es válido/i);
  });

  test('rechaza archivo VACÍO (0 bytes)', async () => {
    const r = await crearRegistro(tesorero, { ...VENTA_BASE, metodo_pago: 'yape' }, { buffer: Buffer.alloc(0), nombre: 'vacio.png', tipo: 'image/png' });
    expect(r.status).toBe(400);
  });

  test('rechaza archivo mayor a 5 MB', async () => {
    const grande = Buffer.concat([pngValido(), Buffer.alloc(5 * 1024 * 1024 + 10, 7)]);
    const r = await crearRegistro(tesorero, { ...VENTA_BASE, metodo_pago: 'yape' }, { buffer: grande, nombre: 'grande.png', tipo: 'image/png' });
    expect(r.status).toBe(400);
    expect(r.body.error).toMatch(/5 MB/i);
  });

  test('nombre con caracteres extraños: se acepta la venta y el nombre original se sanea', async () => {
    const raro = 'comprobante  ⟨ñ⟩  ../../../etc/passwd .png';
    const r = await crearRegistro(tesorero, { ...VENTA_BASE, fecha: '2026-01-17', metodo_pago: 'yape' }, { buffer: pngValido(), nombre: raro, tipo: 'image/png' });
    expect(r.status).toBe(201);
    expect(r.body.registro.comprobante_nombre_original).not.toContain('/');
    expect(r.body.registro.comprobante_nombre_original).not.toContain('..');
    expect(r.body.registro.comprobante_nombre_original.length).toBeLessThanOrEqual(120);
  });

  test('sin comprobante: la venta se guarda igual (es opcional)', async () => {
    const r = await crearRegistro(tesorero, { ...VENTA_BASE, fecha: '2026-01-16', nombre: 'Hilda Torres' });
    expect(r.status).toBe(201);
    expect(r.body.registro.comprobante).toBeNull();
  });
});

describe('Fase A-5: historial, búsqueda y borrado', () => {
  beforeAll(async () => {
    insertarDirecto({ fecha: '2026-03-02', nombre: 'José Ñañez Cuéllar', entregados: 10, sobro: 2, total: 40, metodo_pago: 'efectivo' });
    insertarDirecto({ fecha: '2026-03-05', nombre: 'María García-López', entregados: 8, sobro: 1, total: 35, metodo_pago: 'yape' });
    insertarDirecto({ fecha: '2026-03-09', nombre: '100% Original_Marca', entregados: 4, sobro: 0, total: 16, metodo_pago: 'efectivo' });
  });

  test('filtro por MES devuelve solo ese mes', async () => {
    const r = await request(app).get('/api/registros?mes=2026-03').set('Cookie', tesorero.cookies);
    expect(r.status).toBe(200);
    expect(r.body.registros).toHaveLength(3);
    expect(r.body.registros.every((x) => x.fecha.startsWith('2026-03'))).toBe(true);
  });

  test('búsqueda por nombre con comillas y apóstrofes NO rompe ni altera datos', async () => {
    const r = await request(app).get('/api/registros?q=' + encodeURIComponent(`'" OR "1"="1`)).set('Cookie', tesorero.cookies);
    expect(r.status).toBe(200);
    expect(r.body.registros).toHaveLength(0);
  });

  test('búsqueda con % y _ NO actúa como comodín (está escapado)', async () => {
    const conPorcentaje = await request(app).get('/api/registros?q=' + encodeURIComponent('100%')).set('Cookie', tesorero.cookies);
    expect(conPorcentaje.status).toBe(200);
    expect(conPorcentaje.body.registros).toHaveLength(1);
    expect(conPorcentaje.body.registros[0].nombre).toContain('100% Original_Marca');

    const conGuionBajo = await request(app).get('/api/registros?q=' + encodeURIComponent('Original_')).set('Cookie', tesorero.cookies);
    expect(conGuionBajo.body.registros).toHaveLength(1);

    // 'a%' como comodín NO devuelve todo
    const comodin = await request(app).get('/api/registros?q=' + encodeURIComponent('a%')).set('Cookie', tesorero.cookies);
    expect(comodin.body.registros).toHaveLength(0);
  });

  test('búsqueda con TILDES y Ñ funciona (José Ñañez)', async () => {
    const r = await request(app).get('/api/registros?q=' + encodeURIComponent('Ñañez')).set('Cookie', tesorero.cookies);
    expect(r.status).toBe(200);
    expect(r.body.registros).toHaveLength(1);
    expect(r.body.registros[0].nombre).toBe('José Ñañez Cuéllar');

    const r2 = await request(app).get('/api/registros?q=' + encodeURIComponent('García-López')).set('Cookie', tesorero.cookies);
    expect(r2.body.registros).toHaveLength(1);
  });

  test('lista VACÍA cuando nada coincide, sin errores', async () => {
    const r = await request(app).get('/api/registros?q=zzz-inexistente').set('Cookie', tesorero.cookies);
    expect(r.status).toBe(200);
    expect(r.body.registros).toHaveLength(0);
    expect(r.body.totales.ventas).toBe(0);
  });

  test('ELIMINAR: borrado lógico → desaparece del listado normal y es recuperable', async () => {
    const id = insertarDirecto({ fecha: '2026-03-10', nombre: 'Iván Castillo', entregados: 6, sobro: 0, total: 24, metodo_pago: 'efectivo' });
    const del = await request(app).delete(`/api/registros/${id}`).set('Cookie', tesorero.cookies).set('x-csrf-token', tesorero.csrf);
    expect(del.status).toBe(200);

    const lista = await request(app).get('/api/registros?mes=2026-03').set('Cookie', tesorero.cookies);
    expect(lista.body.registros.some((x) => x.id === id)).toBe(false);

    const conEliminados = await request(app).get('/api/registros?mes=2026-03&eliminados=1').set('Cookie', tesorero.cookies);
    expect(conEliminados.body.registros.some((x) => x.id === id && x.eliminado === 1)).toBe(true);

    const res = await request(app).post(`/api/registros/${id}/restaurar`).set('Cookie', tesorero.cookies).set('x-csrf-token', tesorero.csrf);
    expect(res.status).toBe(200);
    const lista2 = await request(app).get('/api/registros?mes=2026-03').set('Cookie', tesorero.cookies);
    expect(lista2.body.registros.some((x) => x.id === id)).toBe(true);
  });

  test('AL ELIMINAR una venta con comprobante, el archivo deja de ser accesible (y se purga con scripts/purgar.js)', async () => {
    const r = await crearRegistro(tesorero, { ...VENTA_BASE, fecha: '2026-03-11', nombre: 'Julia Rojas', metodo_pago: 'yape' },
      { buffer: pngValido(), nombre: 'r.png', tipo: 'image/png' });
    const id = r.body.registro.id;
    const archivo = r.body.registro.comprobante;

    const ver = await request(app).get(`/api/comprobantes/${id}`).set('Cookie', consulta.cookies);
    expect(ver.status).toBe(200);

    await request(app).delete(`/api/registros/${id}`).set('Cookie', tesorero.cookies).set('x-csrf-token', tesorero.csrf);
    const ver2 = await request(app).get(`/api/comprobantes/${id}`).set('Cookie', consulta.cookies);
    expect(ver2.status).toBe(404);
    // El archivo físico permanece hasta la purga (borrado recuperable, B-15)
    expect(fs.existsSync(path.join(UPLOAD_DIR, archivo))).toBe(true);
  });

  test('ID inválido en DELETE se rechaza con 400 (no rompe)', async () => {
    const r = await request(app).delete('/api/registros/abc').set('Cookie', tesorero.cookies).set('x-csrf-token', tesorero.csrf);
    expect(r.status).toBe(400);
    const r2 = await request(app).delete('/api/registros/1%20OR%201=1').set('Cookie', tesorero.cookies).set('x-csrf-token', tesorero.csrf);
    expect(r2.status).toBe(400);
  });
});

// tests/qa_concurrencia_export.test.js
// Fase A-7 (50 ventas concurrentes), A-8 (doble clic) y A-6 (export 5.000 filas)
'use strict';
const ExcelJS = require('exceljs');
const { app, db, request, comoTesorero, crearRegistro, insertarDirecto, descargar, VENTA_BASE } = require('./helpers');

let sesion;
beforeAll(async () => { sesion = await comoTesorero(); });

describe('Fase A-7: 50 ventas concurrentes no se pierden ni duplican', () => {
  test('50 peticiones simultáneas → 50 registros, cada uno una sola vez', async () => {
    const respuestas = await Promise.all(
      Array.from({ length: 50 }, (_, i) =>
        crearRegistro(sesion, {
          fecha: '2026-04-01',
          nombre: `Concurrente ${i + 1}`,
          entregados: 10 + i,
          sobro: 2,
          total: 20 + i,
          metodo_pago: 'efectivo',
        })
      )
    );
    expect(respuestas.every((r) => r.status === 201)).toBe(true);

    const lista = await request(app).get('/api/registros?mes=2026-04').set('Cookie', sesion.cookies);
    const nombres = lista.body.registros.map((r) => r.nombre);
    expect(lista.body.totales.ventas).toBe(50);
    expect(new Set(nombres).size).toBe(50); // sin duplicados
    // y las sumas son correctas: total = Σ(20+i) para i=0..49 = 2225
    expect(lista.body.totales.total).toBeCloseTo(2225, 2);
  });
});

describe('Fase A-8: doble clic en "Guardar" no crea duplicados', () => {
  test('el mismo registro dos veces seguidas → la segunda es rechazada (409)', async () => {
    const campos = { fecha: '2026-04-02', nombre: 'Doble Clic Pérez', entregados: 9, sobro: 1, total: 33, metodo_pago: 'yape' };
    const [r1, r2] = await Promise.all([crearRegistro(sesion, campos), crearRegistro(sesion, campos)]);
    expect(r1.status).toBe(201);
    expect(r2.status).toBe(409);
    expect(r2.body.error).toMatch(/duplicado/i);

    const lista = await request(app).get('/api/registros?q=' + encodeURIComponent('Doble Clic Pérez')).set('Cookie', sesion.cookies);
    expect(lista.body.registros).toHaveLength(1);
  });

  test('la MISMA venta en otro día o de otro dato distinto SÍ se permite (no sobre-bloquea)', async () => {
    const r = await crearRegistro(sesion, { fecha: '2026-04-03', nombre: 'Doble Clic Pérez', entregados: 9, sobro: 1, total: 33, metodo_pago: 'yape' });
    expect(r.status).toBe(201);
  });
});

describe('Fase A-6b: exportación con 5.000 registros', () => {
  test('genera el Excel completo con 5.000 filas de datos', async () => {
    const insertarMuchos = db.transaction(() => {
      const stmt = db.prepare(`
        INSERT INTO registros (fecha, nombre, entregados, sobro, total, metodo_pago, yape_monto, efectivo_monto, creado_por)
        VALUES (?, ?, ?, ?, ?, 'efectivo', 0, ?, 'prueba')`);
      for (let i = 1; i <= 5000; i++) {
        stmt.run('2026-05-15', `Cliente Masivo ${i}`, 5, 1, 10, 10);
      }
    });
    insertarMuchos();

    const r = await descargar('/api/exportar?mes=2026-05', sesion.cookies);
    expect(r.status).toBe(200);
    expect(r.headers['content-disposition']).toContain('ventas-2026-05.xlsx');

    const wb = new ExcelJS.Workbook();
    await wb.xlsx.load(r.body);
    const ws = wb.getWorksheet('Ventas 2026-05');
    // 5000 filas de datos + encabezado + TOTAL
    expect(ws.rowCount).toBe(5002);
    expect(ws.getRow(2).getCell(2).value).toBe('Cliente Masivo 1');
    expect(ws.getRow(5001).getCell(2).value).toBe('Cliente Masivo 5000');
    // TOTAL con fórmula SUM
    expect(ws.getRow(5002).getCell(6).formula).toBe('SUM(F2:F5001)');
  }, 60000);
});

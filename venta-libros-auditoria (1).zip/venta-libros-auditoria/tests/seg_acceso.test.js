// tests/seg_acceso.test.js
// Fase B-1 (login+roles), B-2 (cookies), B-3 (anti fuerza bruta), B-4 (CSRF), B-8 (comprobantes privados)
'use strict';
const { app, db, request, comoTesorero, comoConsulta, crearRegistro, pngValido, VENTA_BASE } = require('./helpers');
const { resetLimitadoresPruebas } = require('../app/server');
const lockout = require('../app/lockout');

beforeAll(async () => {
  await comoTesorero(); // fuerza la siembra de usuarios
});

describe('Fase B-1: sin sesión no se puede hacer NADA', () => {
  test.each([
    ['GET /api/registros', (r) => r.get('/api/registros')],
    ['POST /api/registros', (r) => r.post('/api/registros')],
    ['DELETE /api/registros/1', (r) => r.delete('/api/registros/1')],
    ['GET /api/comprobantes/1', (r) => r.get('/api/comprobantes/1')],
    ['GET /api/exportar?mes=2026-01', (r) => r.get('/api/exportar?mes=2026-01')],
    ['GET /api/auditoria', (r) => r.get('/api/auditoria')],
    ['POST /api/logout', (r) => r.post('/api/logout')],
  ])('%s responde 401 sin cookie', async (_n, accion) => {
    const r = await accion(request(app));
    expect(r.status).toBe(401);
    expect(r.body.error).toMatch(/no autenticado|inicia sesión/i);
  });
});

describe('Fase B-1: roles — consulta es SOLO LECTURA', () => {
  test('consulta SÍ puede ver historial, comprobantes y exportar', async () => {
    const c = await comoConsulta();
    const r = await request(app).get('/api/registros').set('Cookie', c.cookies);
    expect(r.status).toBe(200);
  });

  test('consulta NO puede registrar ventas (403)', async () => {
    const c = await comoConsulta();
    const r = await crearRegistro(c, VENTA_BASE);
    expect(r.status).toBe(403);
    expect(r.body.error).toMatch(/rol Tesorero/i);
  });

  test('consulta NO puede eliminar ni restaurar (403)', async () => {
    const c = await comoConsulta();
    const del = await request(app).delete('/api/registros/1').set('Cookie', c.cookies).set('x-csrf-token', c.csrf);
    expect(del.status).toBe(403);
    const res = await request(app).post('/api/registros/1/restaurar').set('Cookie', c.cookies).set('x-csrf-token', c.csrf);
    expect(res.status).toBe(403);
  });
});

describe('Fase B-2: cookies de sesión seguras', () => {
  test('la cookie "sesion" es HttpOnly, SameSite=Strict, con expiración y path', async () => {
    const r = await request(app).post('/api/login').send({ usuario: process.env.ADMIN_USER, password: process.env.ADMIN_PASSWORD });
    const cookieSesion = r.headers['set-cookie'].find((c) => c.startsWith('sesion='));
    expect(cookieSesion).toContain('HttpOnly');
    expect(cookieSesion).toContain('SameSite=Strict');
    expect(cookieSesion).toContain('Max-Age=28800'); // 8 horas
    expect(cookieSesion).toContain('Path=/');
    // Nota: "Secure" se añade automáticamente sobre HTTPS (req.secure) o con
    // COOKIE_SECURE=1; en pruebas HTTP no se envía (comportamiento correcto).
  });

  test('LOGOUT invalida la sesión EN EL SERVIDOR: la cookie vieja ya no sirve', async () => {
    const s = await comoTesorero();
    const salida = await request(app).post('/api/logout').set('Cookie', s.cookies).set('x-csrf-token', s.csrf);
    expect(salida.status).toBe(200);

    const reuso = await request(app).get('/api/registros').set('Cookie', s.cookies);
    expect(reuso.status).toBe(401);
  });
});

describe('Fase B-4: protección CSRF', () => {
  test('POST sin cabecera x-csrf-token → 403 (con sesión válida)', async () => {
    const s = await comoTesorero();
    const r = await request(app).post('/api/registros')
      .set('Cookie', s.cookies)
      .field('fecha', '2026-01-20').field('nombre', 'Sin CSRF').field('entregados', '1')
      .field('sobro', '0').field('total', '5').field('metodo_pago', 'efectivo');
    expect(r.status).toBe(403);
    expect(r.body.error).toMatch(/CSRF/i);
  });

  test('POST con CSRF incorrecto → 403', async () => {
    const s = await comoTesorero();
    const r = await request(app).delete('/api/registros/99999')
      .set('Cookie', s.cookies).set('x-csrf-token', 'token-falso');
    expect(r.status).toBe(403);
  });

  test('DELETE sin CSRF → 403', async () => {
    const s = await comoTesorero();
    const r = await request(app).delete('/api/registros/99999').set('Cookie', s.cookies);
    expect(r.status).toBe(403);
  });
});

describe('Fase B-3: anti fuerza bruta', () => {
  beforeEach(() => { lockout._reset(); });
  afterAll(() => { resetLimitadoresPruebas(); }); // no contaminar otras pruebas

  test('LIMITADOR POR IP: 5 logins fallidos → el 6.º recibe 429 aunque la clave sea correcta', async () => {
    for (let i = 0; i < 5; i++) {
      const r = await request(app).post('/api/login').send({ usuario: 'admin-test', password: 'clave-incorrecta' });
      expect(r.status).toBe(401);
    }
    const r6 = await request(app).post('/api/login').send({ usuario: 'admin-test', password: process.env.ADMIN_PASSWORD });
    expect(r6.status).toBe(429);
    expect(r6.body.error).toMatch(/bloqueada|demasiados intentos/i);
  });

  test('BLOQUEO POR CUENTA (unidad): 5 fallos bloquean; se libera con limpiar() o al pasar la ventana', () => {
    for (let i = 0; i < 5; i++) lockout.registrarFallo('cuenta-prueba');
    const e = lockout.estado('cuenta-prueba');
    expect(e.bloqueado).toBe(true);
    expect(e.segundosRestantes).toBeGreaterThan(0);

    lockout.limpiar('cuenta-prueba');
    expect(lockout.estado('cuenta-prueba').bloqueado).toBe(false);
  });

  test('BLOQUEO POR CUENTA (unidad): un fallo fuera de la ventana de 15 min reinicia el conteo', () => {
    for (let i = 0; i < 4; i++) lockout.registrarFallo('cuenta-ventana');
    expect(lockout.estado('cuenta-ventana').fallos).toBe(4);
    expect(lockout.estado('cuenta-ventana').bloqueado).toBe(false); // aún no llega a 5
  });
});

describe('Fase B-8: comprobantes PRIVADOS (uploads/ no es público)', () => {
  test('la carpeta uploads/ NO se sirve como estática', async () => {
    const r = await request(app).get('/uploads/');
    expect(r.status).toBe(404);
    const r2 = await request(app).get('/uploads/cualquier.jpg');
    expect(r2.status).toBe(404);
  });

  test('ver el comprobante REQUIERE sesión; sin ella → 401', async () => {
    const t = await comoTesorero();
    const creado = await crearRegistro(t, { ...VENTA_BASE, fecha: '2026-06-01', nombre: 'Comprobante Privado', metodo_pago: 'yape' },
      { buffer: pngValido(), nombre: 'p.png', tipo: 'image/png' });
    const id = creado.body.registro.id;

    const sinSesion = await request(app).get(`/api/comprobantes/${id}`);
    expect(sinSesion.status).toBe(401);

    const conSesion = await request(app).get(`/api/comprobantes/${id}`).set('Cookie', t.cookies);
    expect(conSesion.status).toBe(200);
    expect(conSesion.headers['content-type']).toBe('image/png');
    expect(conSesion.headers['x-content-type-options']).toBe('nosniff');
  });

  test('no se puede pedir comprobante de registro inexistente (404) ni con ID inválido (400)', async () => {
    const t = await comoTesorero();
    expect((await request(app).get('/api/comprobantes/999999').set('Cookie', t.cookies)).status).toBe(404);
    expect((await request(app).get('/api/comprobantes/abc').set('Cookie', t.cookies)).status).toBe(400);
  });
});

// tests/qa_calculos.test.js
// Fase A-1 (tres métodos de pago) y A-2 (cálculos: vendidos, efectivo, totales del mes, Excel)
'use strict';
const { app, request, comoTesorero, crearRegistro, descargar } = require('./helpers');

let sesion;

beforeAll(async () => { sesion = await comoTesorero(); });

describe('Fase A-1: los tres métodos de pago se registran', () => {
  test('pago solo EFECTIVO', async () => {
    const r = await crearRegistro(sesion, { fecha: '2026-01-10', nombre: 'Ana Paredes', entregados: 10, sobro: 2, total: 40, metodo_pago: 'efectivo' });
    expect(r.status).toBe(201);
    expect(r.body.registro.yape_monto).toBe(0);
    expect(r.body.registro.efectivo_monto).toBe(40);
  });

  test('pago solo YAPE', async () => {
    const r = await crearRegistro(sesion, { fecha: '2026-01-11', nombre: 'Beto Ríos', entregados: 8, sobro: 0, total: 32, metodo_pago: 'yape' });
    expect(r.status).toBe(201);
    expect(r.body.registro.yape_monto).toBe(32);
    expect(r.body.registro.efectivo_monto).toBe(0);
  });

  test('pago MIXTO: efectivo = total − yape (automático)', async () => {
    const r = await crearRegistro(sesion, { fecha: '2026-01-12', nombre: 'Carla Díaz', entregados: 6, sobro: 1, total: 25, metodo_pago: 'mixto', yape_monto: 10 });
    expect(r.status).toBe(201);
    expect(r.body.registro.yape_monto).toBe(10);
    expect(r.body.registro.efectivo_monto).toBe(15); // 25 − 10
  });
});

describe('Fase A-2: cálculos y totales del mes', () => {
  test('vendidos = entregados − sobró se guarda correctamente', async () => {
    const r = await crearRegistro(sesion, { fecha: '2026-01-20', nombre: 'Daniel Soto', entregados: 30, sobro: 7, total: 92, metodo_pago: 'efectivo' });
    expect(r.status).toBe(201);
    expect(r.body.registro.entregados - r.body.registro.sobro).toBe(23);
  });

  test('los totales del mes suman ventas, efectivo y yape', async () => {
    const r = await request(app).get('/api/registros?mes=2026-01').set('Cookie', sesion.cookies);
    expect(r.status).toBe(200);
    // Ana 40 + Beto 32 + Carla 25 + Daniel 92 = 189 ; yape = 10+32 = 42
    expect(r.body.totales.total).toBeCloseTo(189, 2);
    expect(r.body.totales.yape).toBeCloseTo(42, 2);
    expect(r.body.totales.efectivo).toBeCloseTo(147, 2);
    expect(r.body.totales.ventas).toBe(4);
  });

  test('el mes con solo pagos mixtos calcula bien el efectivo total', async () => {
    await crearRegistro(sesion, { fecha: '2026-02-05', nombre: 'Elena Vargas', entregados: 12, sobro: 2, total: 80, metodo_pago: 'mixto', yape_monto: 30 });
    await crearRegistro(sesion, { fecha: '2026-02-06', nombre: 'Felipe Núñez', entregados: 5, sobro: 5, total: 20, metodo_pago: 'yape' });
    const r = await request(app).get('/api/registros?mes=2026-02').set('Cookie', sesion.cookies);
    expect(r.body.totales.total).toBeCloseTo(100, 2);
    expect(r.body.totales.yape).toBeCloseTo(50, 2);   // 30 + 20
    expect(r.body.totales.efectivo).toBeCloseTo(50, 2); // 50 + 0
  });
});

describe('Fase A-6: exportación a Excel (fórmulas y formatos)', () => {
  test('genera el Excel del mes con fórmulas Vendidos y TOTAL, y formato de soles', async () => {
    const r = await descargar('/api/exportar?mes=2026-01', sesion.cookies);
    expect(r.status).toBe(200);
    expect(r.headers['content-type']).toMatch(/spreadsheetml/);
    expect(r.headers['content-disposition']).toContain('ventas-2026-01.xlsx');

    const ExcelJS = require('exceljs');
    const wb = new ExcelJS.Workbook();
    await wb.xlsx.load(r.body);
    const ws = wb.getWorksheet('Ventas 2026-01');

    expect(ws.getRow(1).getCell(1).value).toBe('Fecha');
    expect(ws.getRow(1).getCell(2).value).toBe('Nombre');
    expect(ws.getRow(1).getCell(6).value).toBe('Total (S/)');
    // Fila 2: fórmula Vendidos = C2 - D2
    expect(ws.getRow(2).getCell(5).formula).toBe('C2-D2');
    // Formato de moneda en Total
    expect(ws.getRow(2).getCell(6).numFmt).toContain('"S/"');
    // Formato de fecha dd/mm/yyyy
    expect(ws.getRow(2).getCell(1).numFmt).toBe('dd/mm/yyyy');
    // Fila TOTAL (4 ventas → fila 6) con SUM
    expect(ws.getRow(6).getCell(6).formula).toBe('SUM(F2:F5)');
  });

  test('mes SIN ventas: genera Excel con encabezados y TOTAL en 0', async () => {
    const r = await descargar('/api/exportar?mes=2025-12', sesion.cookies);
    expect(r.status).toBe(200);
    const ExcelJS = require('exceljs');
    const wb = new ExcelJS.Workbook();
    await wb.xlsx.load(r.body);
    const ws = wb.getWorksheet('Ventas 2025-12');
    expect(ws.rowCount).toBe(2); // encabezado + fila TOTAL
    expect(ws.getRow(2).getCell(1).value).toBe('TOTAL');
    expect(ws.getRow(2).getCell(6).value).toBe(0);
  });
});

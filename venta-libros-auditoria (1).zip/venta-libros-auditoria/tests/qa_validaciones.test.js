// tests/qa_validaciones.test.js
// Fase A-3: datos ilegales se rechazan con mensajes en español (server-side)
'use strict';
const { app, request, comoTesorero, crearRegistro, VENTA_BASE } = require('./helpers');

let sesion;
beforeAll(async () => { sesion = await comoTesorero(); });

async function enviar(campos) {
  const r = await crearRegistro(sesion, campos);
  return { status: r.status, cuerpo: r.body };
}

describe('Fase A-3: validación de datos ilegales', () => {
  test('nombre con SOLO espacios → rechazado', async () => {
    const r = await enviar({ ...VENTA_BASE, nombre: '    ' });
    expect(r.status).toBe(400);
    expect(r.cuerpo.errores.nombre).toMatch(/obligatorio/i);
  });

  test('entregados NEGATIVO → rechazado', async () => {
    const r = await enviar({ ...VENTA_BASE, entregados: -3 });
    expect(r.status).toBe(400);
    expect(r.cuerpo.errores.entregados).toBeDefined();
  });

  test('cantidades DECIMALES (3.5 libros) → rechazadas', async () => {
    const r = await enviar({ ...VENTA_BASE, sobro: 3.5 });
    expect(r.status).toBe(400);
    expect(r.cuerpo.errores.sobro).toBeDefined();
  });

  test('campos numéricos con TEXTO ("diez") → rechazados', async () => {
    const r = await enviar({ ...VENTA_BASE, entregados: 'diez', total: 'mucho' });
    expect(r.status).toBe(400);
    expect(r.cuerpo.errores.entregados).toBeDefined();
    expect(r.cuerpo.errores.total).toBeDefined();
  });

  test('sobró > entregados → rechazado', async () => {
    const r = await enviar({ ...VENTA_BASE, entregados: 5, sobro: 9 });
    expect(r.status).toBe(400);
    expect(r.cuerpo.errores.sobro).toMatch(/mayor que Entregados/i);
  });

  test('Yape > total → rechazado', async () => {
    const r = await enviar({ ...VENTA_BASE, metodo_pago: 'mixto', yape_monto: 80, total: 50 });
    expect(r.status).toBe(400);
    expect(r.cuerpo.errores.yape_monto).toMatch(/total/i);
  });

  test('número GIGANTE (1e9) → rechazado con límite claro', async () => {
    const r = await enviar({ ...VENTA_BASE, total: 1e9 });
    expect(r.status).toBe(400);
    expect(r.cuerpo.errores.total).toBeDefined();
  });

  test('NaN → rechazado', async () => {
    const r = await enviar({ ...VENTA_BASE, total: 'NaN' });
    expect(r.status).toBe(400);
    expect(r.cuerpo.errores.total).toBeDefined();
  });

  test('Infinity → rechazado', async () => {
    const r = await enviar({ ...VENTA_BASE, total: 'Infinity' });
    expect(r.status).toBe(400);
    expect(r.cuerpo.errores.total).toBeDefined();
  });

  test('fecha IMPOSIBLE 2026-02-31 → rechazada', async () => {
    const r = await enviar({ ...VENTA_BASE, fecha: '2026-02-31' });
    expect(r.status).toBe(400);
    expect(r.cuerpo.errores.fecha).toMatch(/fecha real/i);
  });

  test('fecha con formato extraño 15/01/2026 → rechazada', async () => {
    const r = await enviar({ ...VENTA_BASE, fecha: '15/01/2026' });
    expect(r.status).toBe(400);
    expect(r.cuerpo.errores.fecha).toBeDefined();
  });

  test('fecha VACÍA → rechazada', async () => {
    const r = await enviar({ ...VENTA_BASE, fecha: '' });
    expect(r.status).toBe(400);
    expect(r.cuerpo.errores.fecha).toBeDefined();
  });

  test('método de pago inválido → rechazado', async () => {
    const r = await enviar({ ...VENTA_BASE, metodo_pago: 'paypal' });
    expect(r.status).toBe(400);
    expect(r.cuerpo.errores.metodo_pago).toBeDefined();
  });

  test('mixto SIN monto yape → rechazado', async () => {
    const r = await enviar({ ...VENTA_BASE, metodo_pago: 'mixto' });
    expect(r.status).toBe(400);
    expect(r.cuerpo.errores.yape_monto).toMatch(/monto/i);
  });

  test('nombre con 101+ caracteres → rechazado', async () => {
    const r = await enviar({ ...VENTA_BASE, nombre: 'A'.repeat(101) });
    expect(r.status).toBe(400);
    expect(r.cuerpo.errores.nombre).toBeDefined();
  });

  test('los datos CORRECTOS sí pasan (control positivo)', async () => {
    const r = await enviar({ fecha: '2026-01-18', nombre: 'Gabriela Mendoza', entregados: 20, sobro: 4, total: 64.5, metodo_pago: 'mixto', yape_monto: 30 });
    expect(r.status).toBe(201);
    expect(r.cuerpo.registro.efectivo_monto).toBe(34.5);
  });
});

// tests/setup.env.js — entorno aislado por archivo de prueba (BD temporal)
const os = require('os');
const path = require('path');
const fs = require('fs');

const dir = fs.mkdtempSync(path.join(os.tmpdir(), 'vl-test-'));
process.env.DB_PATH = path.join(dir, 'ventas.db');
process.env.UPLOAD_DIR = path.join(dir, 'uploads');
process.env.ADMIN_USER = 'admin-test';
process.env.ADMIN_PASSWORD = 'ClaveTesorero2026!';
process.env.CONSULTA_USER = 'consulta-test';
process.env.CONSULTA_PASSWORD = 'ClaveConsulta2026!';
process.env.API_LIMIT_MAX = '5000';   // alto para no interferir con las pruebas
process.env.LOGIN_LIMIT_MAX = '5';
process.env.LOCKOUT_MAX = '5';
process.env.NODE_ENV = 'test';

// jest.config.js — Configuración de la suite de pruebas automatizadas
module.exports = {
  testEnvironment: 'node',
  setupFiles: ['<rootDir>/tests/setup.env.js'],
  testTimeout: 30000,
  clearMocks: true,
  verbose: true,
};
